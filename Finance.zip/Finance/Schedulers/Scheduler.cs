﻿using GenericCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Finance
{
    /// <summary>
    /// By default, the frequency is 1Y EOM btw start and end dates
    /// </summary>
    public class Scheduler:IId
    {
        public int Id { get; set; }
        /// <summary>
        /// If endDate is null, add 5 years to startDate
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        public Scheduler(DateTime startDate,DateTime? endDate=null)
        {
            this.StartDate = startDate;
            this.EndDate = endDate??this.StartDate.AddYears(5);
        }
        /// <summary>
        /// If endYear is null, add 5 years to startDate (EOY)
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        public Scheduler(int startYear, int? endYear=null)
        {
            this.StartDate = new DateTime(startYear,1,1);
            this.EndDate = endYear == null ? this.StartDate.AddYears(5) : new DateTime(endYear.Value, 12, 31);
        }
        public DateTime StartDate;
        public DateTime EndDate;
        private DateTime? _FirstPeriodEndDate;
        public DateTime? FirstPeriodEndDate 
        {             
            get 
            { 
                if (_FirstPeriodEndDate==null)
                {
                    var curDate=new DateTime(StartDate.Year,12,31);                    
                    //switch (FrequencyPeriod)
                    //{
                    //    case Finance.FrequencyPeriod.D:
                    //        curDate=StartDate.AddDays(FrequencyPeriodMultiplier);
                    //        if (this.RollConvention == RollConvention.EOM)
                    //        {
                    //            curDate = DateHelper.EOM(curDate);
                    //        }
                    //        break;
                    //    case Finance.FrequencyPeriod.W:
                    //        curDate = StartDate.AddDays(7 * FrequencyPeriodMultiplier);
                    //        if (this.RollConvention == RollConvention.EOM)
                    //        {
                    //            curDate = DateHelper.EOM(curDate);
                    //        }
                    //        break;
                    //    case Finance.FrequencyPeriod.M:
                    //        curDate = StartDate.AddMonths(FrequencyPeriodMultiplier);
                    //        if (this.RollConvention == RollConvention.EOM)
                    //        {
                    //            curDate = DateHelper.EOM(curDate);
                    //        }
                    //        break;
                    //    case Finance.FrequencyPeriod.Y:
                    //        curDate = StartDate.AddYears(FrequencyPeriodMultiplier);
                    //        if (this.RollConvention == RollConvention.EOM)
                    //        {
                    //            curDate = DateHelper.EOM(curDate);
                    //        }
                    //        break;
                    //    case Finance.FrequencyPeriod.T:
                    //        break;
                    //}
                    return curDate;
                }
                else
                {
                    return _FirstPeriodEndDate;
                }
            } 
            set { _FirstPeriodEndDate = value; }
        }

        // Frequency:
        public int FrequencyPeriodMultiplier=1;
        public FrequencyPeriod FrequencyPeriod=FrequencyPeriod.Y;
        public RollConvention RollConvention=RollConvention.EOM;

        public BusinessDayAdjuster BusinessDayAdjuster=new BusinessDayAdjuster();

        private Schedule _Schedule;
        /// <summary>
        /// Dynamic (always recalculated, cannot be set)
        /// </summary>
        public Schedule Schedule
        {
            get
            {                
                GenerateSchedule();                
                return _Schedule;
            }
        }

        /// <summary>
        /// Generate the schedule (end Dates)
        /// </summary>
        /// <returns></returns>
        public void GenerateSchedule()
        {
           
            var res = new Schedule(); 
            var curDate = FirstPeriodEndDate;
            switch(FrequencyPeriod)
            {
                case Finance.FrequencyPeriod.D:                    
                    curDate=FirstPeriodEndDate.Value.AddDays(-FrequencyPeriodMultiplier);                    
                    break;
                case Finance.FrequencyPeriod.W:
                    curDate = FirstPeriodEndDate.Value.AddDays(-7 * FrequencyPeriodMultiplier);
                    break;
                case Finance.FrequencyPeriod.M:
                    curDate = FirstPeriodEndDate.Value.AddMonths(-FrequencyPeriodMultiplier);
                    break;
                case Finance.FrequencyPeriod.Y:
                    curDate = FirstPeriodEndDate.Value.AddYears(-FrequencyPeriodMultiplier);
                    break;
                case Finance.FrequencyPeriod.T:
                    break;
            }            
            if (this.RollConvention == RollConvention.EOM)
            {
                curDate = DateHelper.EOM(curDate.Value);
                if (curDate>=FirstPeriodEndDate.Value)
                {
                    curDate = new DateTime(FirstPeriodEndDate.Value.Year, FirstPeriodEndDate.Value.Month, 1).AddDays(-1);
                }
            }
            res.Add(curDate.Value, 0, "Revision: Initial reference date; ");
            res.Add(StartDate,0,"Start Date; ");
            curDate = FirstPeriodEndDate;
            res.Add(curDate.Value, 0, "Revision Nb.1; ");  
            var counter=1;
            switch (FrequencyPeriod)
            {
                case FrequencyPeriod.D:
                    while (curDate < EndDate)
                    {
                        counter++;
                        curDate = curDate.Value.AddDays(FrequencyPeriodMultiplier);
                        if (this.RollConvention == RollConvention.EOM)
                        {
                            curDate = DateHelper.EOM(curDate.Value);
                        }
                        if (curDate < EndDate) res.Add(curDate.Value, 0, string.Format("Revision Nb.{0}; ", counter));
                    }
                    break;
                case FrequencyPeriod.W:
                    while (curDate < EndDate)
                    {
                        counter++;
                        curDate = curDate.Value.AddDays(7 * FrequencyPeriodMultiplier);
                        if (this.RollConvention == RollConvention.EOM)
                        {
                            curDate = DateHelper.EOM(curDate.Value);
                        }
                        if (curDate < EndDate) res.Add(curDate.Value, 0, string.Format("Revision Nb.{0}; ", counter));
                    }
                    break;
                case FrequencyPeriod.M:
                    while (curDate < EndDate)
                    {
                        counter++;
                        curDate = curDate.Value.AddMonths(FrequencyPeriodMultiplier);
                        if (this.RollConvention == RollConvention.EOM)
                        {
                            curDate = DateHelper.EOM(curDate.Value);
                        }
                        if (curDate < EndDate) res.Add(curDate.Value, 0, string.Format("Revision Nb.{0}; ", counter));
                    }
                    break;
                case FrequencyPeriod.Y:
                    while (curDate < EndDate)
                    {
                        counter++;
                        curDate = curDate.Value.AddYears(FrequencyPeriodMultiplier);
                        if (this.RollConvention == RollConvention.EOM)
                        {
                            curDate = DateHelper.EOM(curDate.Value);
                        }
                        if (curDate < EndDate) res.Add(curDate.Value, 0, string.Format("Revision Nb.{0}; ", counter));
                    }
                    break;
                default:
                    break;
            }
            res.Add(EndDate,0,"End Date; ");
            BusinessDayAdjuster.AdjustForBusinessDays(res);
            res.Sort();
            _Schedule = res;
        }
       
    }


}
