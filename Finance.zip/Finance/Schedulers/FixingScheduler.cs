﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Finance
{
    /// <summary>
    /// Calculated against CalculationPeriod StartDate if InAdvance (EndDate otherwise).
    /// The Frequency cannot be less than the calculation's. Needs to be a integer multiple.
    /// </summary>
    public class FixingScheduler : PaymentScheduler
    {
    }

}
