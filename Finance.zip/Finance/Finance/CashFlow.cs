﻿using GenericCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Finance
{
    public class CashFlow:IId
    {
        public int Id { get; set; }
        public CashFlow (DateTime paymentDate,Currency currency,double amount=0.0)
        {
            this.PaymentDate = paymentDate;
            this.Currency = currency;
            this.Amount = amount;
        }
        public CashFlow(DateTime paymentDate) : this(paymentDate, new Currency("EUR")) { }        
        public DateTime PaymentDate { get; set; }
        public double Amount { get; set; }
        public Currency Currency { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
