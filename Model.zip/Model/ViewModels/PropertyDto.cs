﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Finance;

namespace eTrackModels
{
    public class PropertyDto:IEntity
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Address { get; set; }
        public Currency Currency { get; set; }// todo
        public string CurrencyName { get; set; }
        public double Capex { get; set; }
        public double NewLettingFees { get; set; }
        public double LeaseRenewalFees { get; set; }
        public Schedule NewLettingLegalFees { get; set; }
        public double FacilityManagementAnnualRate { get; set; }
        public double PropertyTaxAnnualRate { get; set; }
        public double PropertyManagementAnnualRate { get; set; }
        public double OtherServiceCharge { get; set; }
        public Schedule AcquisitionLegalCost { get; set; }
        public Schedule AcquisitionLandSurveyCost { get; set; }
        public Schedule AcquisitionBuildingSurveyCost { get; set; }
        public Schedule AcquisitionStampDuty { get; set; }
        public Schedule AcquisitionAgentCost { get; set; }
        public Schedule AcquisitionOtherCost { get; set; }
        // Could be refined at unit level:
        public double NetPurchasePrice { get; set; }
        public Schedule ExitPrice { get; set; }
        public Schedule ExitYield { get; set; }
        public Schedule ExitCosts { get; set; }
        public Schedule Vacancy { get; set; }
        public Schedule LeaseLength { get; set; }
        public Schedule DefaultRecoverability { get; set; }
        public double ErvPerAreaAnnualRate { get; set; }
        public double ErvPerParkingSpaceAnnualRate { get; set; }
        public double UtilityAnnualRate { get; set; }
        public Schedule StructuralVacancy { get; set; }
        public Schedule Collectionloss { get; set; }
        public Schedule RentFreePeriod { get; set; }
        public double TiPerAreaAnnualRate { get; set; }
        public double DilapidationsPerAreaAnnualRate { get; set; }
        public IEntity Parent { get { return null; } }
    }

}
