﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eTrackModels
{
    public class ContractualRent : AccrualsFromAnnualRates
    {
        public ContractualRent() { }
        public ContractualRent( string name, string description = "") : base( name, description) { }
       
    }
}
 