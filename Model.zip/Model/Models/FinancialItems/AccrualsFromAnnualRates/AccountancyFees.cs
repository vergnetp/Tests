﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eTrackModels
{
    public class AccountancyFees:AccrualsFromAnnualRates
    {
        public AccountancyFees():base() { }
        public AccountancyFees( string name, string description = "") : base( name, description) { }
       
    }
}
