﻿using Finance;
using GenericCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace eTrackModels
{
    public class Interest : IId
    {
        public Interest() { Debts = new List<Debt>(); }
        public int Id { get; set; }
        public string Name { get; set; }

        public FixingScheduler FixingScheduler;

        [DisplayFormat(DataFormatString = "{0:P2}", ApplyFormatInEditMode = true)]
        public double AnnualRate { get; set; }
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime StartDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime EndDate { get; set; }

        private DateTime _PaymentDate;
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime PaymentDate { get { if (_PaymentDate == DateTime.MinValue) { return this.EndDate; } else { return _PaymentDate; } } set { _PaymentDate = value; } }

        public Frequency Frequency { get; set; }
        public DayCount DayCount { get; set; }

        public virtual ICollection<Debt> Debts { get; set; }

        [Required]
        public virtual User User { get; set; }
    }
}