﻿using Finance;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace eTrackModels
{


    public class AcquisitionLegalCost : Schedule { }
    public class AcquisitionLandSurveyCost : Schedule { }
    public class AcquisitionBuildingSurveyCost : Schedule { }
    public class AcquisitionStampDuty : Schedule { }
    public class AcquisitionAgentCost : Schedule { }
    public class AcquisitionOtherCost : Schedule { }


    
}