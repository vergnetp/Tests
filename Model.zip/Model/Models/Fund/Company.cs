﻿using Finance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eTrackModels
{
    public class Company:IEntity
    {
        public Company() { this.OtherCorporateCosts = new List<AccrualsFromAnnualRates>(); }
        public Company(string name, string description = "") : this() { Name = name; Description = description; }
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public Currency Currency { get; set; }
        public AccrualsFromAnnualRates AccountancyFees { get; set; }
        public AccrualsFromAnnualRates LegalFees { get; set; }
        public AccrualsFromAnnualRates AdminFees { get; set; }
        public AccrualsFromAnnualRates AssetManagementFees { get; set; }
        public List<AccrualsFromAnnualRates> OtherCorporateCosts { get; set; }
        public Accruals Tax { get; set; }
        public Accruals TaxableIncome { get; set; }
        public Portfolio Portfolio { get; set; }
        public IEntity Parent { get { return this.Portfolio; } }
        // Equity
    }
}
