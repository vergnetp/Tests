﻿using GenericCore;
using Finance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eTrackModels
{
    public interface IEntity:IId
    {        
        DateTime StartDate { get; set; }
        DateTime EndDate { get; set; }
        Currency Currency { get; set; }
        IEntity Parent { get;  }
    }
}
