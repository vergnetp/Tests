﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Web.Mvc;
using Finance;

namespace eTrackModels
{
  
   
    public class Property : IEntity
    {
        #region Ctor
        public Property()
        {
            this.Units = new List<Unit>();
            this.Leases = new List<Lease>();
            this.OtherServiceCharge = new List<AccrualsFromAnnualRates>();
            this.Capex = new List<Schedule>();
            this.Portfolio = new Portfolio();//todo: remove (hack for test)
            this.PropertyTax = new AccrualsFromAnnualRates();        
            this.AcquisitionAgentCost = new Schedule();
        }
        public Property(string name,string description=""):this()
        {
            Name = name;
            Description = description;                        
        }
        #endregion

        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        

        #region Specifics
        public string Address { get; set; }
        public Currency Currency { get; set; }
        public Schedule NewLettingFees { get; set; }
        public Schedule LeaseRenewalFees { get; set; }
        public Schedule NewLettingLegalFees { get; set; } 
        // Could be refined at unit level:
        public double NetPurchasePrice { get; set; }  
        public double ExitPrice { get; set; }
        public Schedule ExitYield { get; set; }
        public Schedule ExitCosts { get; set; }
        public Schedule Vacancy { get; set; }
        public Schedule LeaseLegth { get; set; }
        public Schedule DefaultRecoverability { get; set; } 
        public Schedule StructuralVacancy { get; set; }
        public Schedule Collectionloss { get; set; }
        public Schedule RentFreePeriod { get; set; }        
        public AnnualRateGenerator ErvPerArea { get; set; }
        public AnnualRateGenerator ErvPerParkingSpace { get; set; }        
        public AnnualRateGenerator TiPerArea { get; set; }
        public AnnualRateGenerator DilapidationsPerArea { get; set; }
        #endregion

        #region AcquisitionCosts
        [Required]
        public Schedule AcquisitionLegalCost{get;set;}
        public Schedule AcquisitionLandSurveyCost { get; set; }
        public Schedule AcquisitionBuildingSurveyCost { get; set; }
        public Schedule AcquisitionStampDuty { get; set; }
        public Schedule AcquisitionAgentCost { get; set; }
        public Schedule AcquisitionOtherCost { get; set; }
        #endregion


        #region FinancialItems
        public AccrualsFromAnnualRates FacilityManagement { get; set; }
        [Required]
        public AccrualsFromAnnualRates PropertyTax { get; set; }
        public AccrualsFromAnnualRates PropertyManagement { get; set; }
        public List<AccrualsFromAnnualRates> OtherServiceCharge { get; set; }
        public List<Schedule> Capex { get; set; } 
        // Could be refined at unit level:
        //public List<Utility> Utilities;
        public AccrualsFromAnnualRates Utility { get; set; }
        #endregion

        #region Start/End
        private DateTime _StartDate;
        [DataType(DataType.Date)]
        [Display(Name = "Start Date")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Remote("PropertyStartDate", "Validator", HttpMethod = "Post", AdditionalFields = "Id")]
        public DateTime StartDate { get { if (_StartDate == DateTime.MinValue) { if (this.Portfolio == null) { return DateTime.Now; } else { return this.Portfolio.StartDate; } } else { return _StartDate; } } set { _StartDate = value; } }

        private DateTime _EndDate;
        [DataType(DataType.Date)]
        [Display(Name = "End Date")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Remote("PropertyEndDate", "Validator", HttpMethod = "Post", AdditionalFields = "Id")]
        public DateTime EndDate { get { if (_EndDate == DateTime.MinValue) { if (this.Portfolio == null) { return this.StartDate.AddYears(5); } else { return this.Portfolio.EndDate; } } else { return _EndDate; } } set { _EndDate = value; } }
        #endregion

        #region Parent
        //[Required]
        public virtual Portfolio Portfolio { get; set; }
        public IEntity Parent { get { return this.Portfolio; } }
        #endregion

        #region Other Objects       
        public virtual Country Country { get; set; }
        public virtual List<Unit> Units { get; set; }
        public virtual List<Lease> Leases { get; set; }
        [HiddenInput(DisplayValue = false)]
        public virtual User User { get; set; }
        #endregion
       
    }
}