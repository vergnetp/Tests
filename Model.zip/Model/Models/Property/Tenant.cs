﻿using GenericCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eTrackModels
{
    public class Tenant : IId
    {
        public Tenant() { this.Contacts = new List<Contact>(); }
        public int Id { get; set; }
        public string Name { get; set; }
        public CreditRating CreditRating { get; set; }
        public virtual List<Contact> Contacts { get; set; }

        [Required]
        public virtual User User { get; set; }
    }
}
