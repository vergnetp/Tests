﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Web.Mvc;
using Finance;

namespace eTrackModels
{

    public class Unit : IEntity
    {
        #region Ctor
        public Unit() { 
            this.Leases = new List<Lease>(); 
        }
        public Unit( string name, string description="") :this() { }
        #endregion

        #region Specifics
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public Schedule Area { get; set; }
        public enum AreaUnitType
        {
            Sqm,
            SqFoot
        }
        public Currency Currency { get; set; }
        
        public UnitType UnitType;
        public Schedule NbParkings;

        // todo: if null prorata(t) property
        public double? NetPurchasePrice { get; set; }
        public double? ExitPrice { get; set; }

        protected Schedule _ExitYield;
        protected Schedule _Vacancy;
        protected Schedule _LeaseLegth;
        protected Schedule _DefaultRecoverability;
        

        public Schedule ExitYield { get { return _ExitYield ?? this.Property.ExitYield; } set { _ExitYield = value; } }
        public Schedule Vacancy { get { return _Vacancy ?? this.Property.Vacancy; } set { _Vacancy = value; } }
        public Schedule LeaseLegth { get { return _LeaseLegth ?? this.Property.LeaseLegth; } set { _LeaseLegth = value; } }
        public Schedule DefaultRecoverability { get { return _DefaultRecoverability ?? this.Property.DefaultRecoverability; } set { _DefaultRecoverability = value; } }
         
        #endregion

        #region FinancialItems
        protected AnnualRateGenerator _ErvPerArea;
        protected AnnualRateGenerator _ErvPerParkingSpace;
        public AnnualRateGenerator ErvPerArea { get { return _ErvPerArea ?? this.Property.ErvPerArea; } set { _ErvPerArea = value; } }
        public AnnualRateGenerator ErvPerParkingSpace { get { return _ErvPerParkingSpace ?? this.Property.ErvPerParkingSpace; } set { _ErvPerParkingSpace = value; } }
        protected Accruals _Utility;
        public Accruals Utility { get { return _Utility ?? this.Property.Utility; } set { _Utility = value; } }
       
        public Accruals RecurringRefurbishment;
        public Accruals Ti; 
        #endregion

        #region Calculated Fields
        public Schedule TotalErv
        {
            get
            {
                try
                {
                    var entity = this;
                    var erv = entity.Area * entity.ErvPerArea.AnnualRates;
                    var ervParking = entity.NbParkings * entity.ErvPerParkingSpace.AnnualRates;
                    var res = erv + ervParking;
                    return res;
                }
                catch { return null; }
            }
        }
        public Schedule Fmv
        {
            get
            {
                var entity = this;
                var res = entity.TotalErv / entity.ExitYield;
                return res;
            }
        }
        public ICollection<Lease> ForecastLeases()
        {
            var res = new List<Lease>();
            var refDate = this.StartDate;
            var leases = this.Leases.OrderBy(l => l.StartDate).Where(l => l.EndDate > this.StartDate && l.StartDate <= this.EndDate.AddYears(1) && l.EndDate < this.EndDate.AddYears(1));
            // todo: Check no concomittency
            foreach(var lease in leases)
            {
                res.Concat(CreateNewCalculatedLeases(refDate, lease.StartDate));
                refDate = lease.EndDate;
            }
            res.Concat(CreateNewCalculatedLeases(refDate, this.EndDate.AddYears(1)));
            return res;
        }
        public ICollection<Lease> CreateNewCalculatedLeases(DateTime from,DateTime to)
        {
            var res=new List<Lease>();
            var refDate=from;
            if (refDate<=to) return res;
            while(refDate<to)
            {
                refDate=refDate.AddMonths(vacancy(refDate));
                if (refDate<=to) return res;
                var endDate=DateHelper.Min(to,refDate.AddMonths(length(refDate)));
                var newLease=CreateNewCalculatedLease(refDate,endDate);
                res.Add(newLease);
                refDate=endDate;
            }
            return res;
        }
        public Lease CreateNewCalculatedLease(DateTime startDate,DateTime endDate)
        {                    
            var rs = this.ErvPerArea.RevisionScheduler;
            rs.StartDate = startDate;
            rs.EndDate = endDate;
            rs.FirstPeriodEndDate = null;
            rs.GenerateSchedule();
            var tool = new AnnualRateGenerator(startDate) { Inflation = this.ErvPerArea.Inflation, AnnualRate = erv(startDate), RevisionScheduler = rs };
            var annualRates =tool.AnnualRates;
            var name = string.Format("{0} new lease ({1} to {2})", this.Name, startDate, endDate);
            var lease = new Lease(name)
                {  
                    EndDate=endDate,                    
                    StartDate=startDate,
                    ContractualRent=new ContractualRent(name){AnnualRates=annualRates},
                    Currency=this.Currency,
                    Type=Lease.LeaseType.Calculated,
                    //Units=new List<Unit>{this}            
                };
            return lease;
        }
        public int vacancy(DateTime refDate)
        {
            return (int)this.Vacancy.FindFirst(refDate).Item.Value;
        }
        public int length(DateTime refDate)
        {
            return (int)this.LeaseLegth.FindFirst(refDate).Item.Value;
        }
        public int reco(DateTime refDate)
        {
            return (int)this.DefaultRecoverability.FindFirst(refDate).Item.Value;
        }
        public double erv(DateTime refDate)
        {
            return (int)this.TotalErv.FindFirst(refDate).Item.Value;
        }

        public Accruals ServiceChargeIncome()
        {
            Schedule res = null;
            Accruals charge = this.Utility; // todo           
            var annualRates = charge.ToAnnualRates();
            foreach (var lease in this.Leases)
            {
                var reco = lease.DefaultRecoverability;// todo
                var schedule=new Schedule(lease.StartDate,lease.EndDate);
                schedule[0].Item.Value = annualRates.FindFirst(schedule[0].Date).Item.Value;
                for(var i=0;i<annualRates.Count;i++)
                {
                    if (annualRates[i].Date<lease.EndDate && annualRates[i].Date>=lease.StartDate)
                    {
                        schedule.Add(annualRates[i].Date, annualRates[i].Item.Value * reco.FindFirst(annualRates[i].Date).Item.Value);
                    }
                }
                for (var i = 0; i < reco.Count; i++)
                {
                    if (reco[i].Date < lease.EndDate && reco[i].Date >= lease.StartDate)
                    {
                        schedule.Add(reco[i].Date, reco[i].Item.Value * annualRates.FindFirst(reco[i].Date).Item.Value);
                    }
                }
                res.Merge(schedule);
            }
            res.Sort();
            var sc = new Accruals("ServiceChargeIncome");
            sc.Currency = charge.Currency;
            sc.DueAmounts = res.ToAccruals(charge.Currency);
            sc.RefreshCashflows();
            return sc;
        }
        #endregion

        #region Start/End
        private DateTime _StartDate;
        [DataType(DataType.Date)]
        [Display(Name = "Start Date")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Remote("UnitStartDate", "Validator", HttpMethod = "Post", AdditionalFields = "Id")]
        public DateTime StartDate { get { if (_StartDate == DateTime.MinValue) { if (this.Property == null) { return DateTime.Now; } else { return this.Property.StartDate; } } else { return _StartDate; } } set { _StartDate = value; } }

        private DateTime _EndDate;
        [DataType(DataType.Date)]
        [Display(Name = "End Date")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Remote("UnitEndDate", "Validator", HttpMethod = "Post", AdditionalFields = "Id")]
        public DateTime EndDate { get { if (_EndDate == DateTime.MinValue) { if (this.Property == null) { return this.StartDate.AddYears(5); } else { return this.Property.EndDate; } } else { return _EndDate; } } set { _EndDate = value; } }
        #endregion

        #region Parent
        [Required]
        public virtual Property Property { get; set; }
        public IEntity Parent { get { return this.Property; } }
        #endregion

        #region Other Objects
        [Required]
        public virtual ICollection<Lease> Leases { get; set; }
        //[Required]
        [HiddenInput(DisplayValue = false)]
        public virtual User User { get; set; }
        #endregion
                
 

        
    }
}