﻿using GenericCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace eTrackModels
{

    /// <summary>
    /// Debt Repayment. Expect a positive amount.
    /// </summary>
    public class DebtRepaymentPenalty:IId
    {
        public int Id { get; set; }
        public string Name { get; set; }

        [DisplayFormat(DataFormatString = "{0:P2}", ApplyFormatInEditMode = true)]
        public double Fee { get; set; }
        public bool RepaymentAuthorized { get; set; }

        private DateTime _StartDate;
        [DataType(DataType.Date)]
        [Display(Name = "Start Date")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Remote("UnitStartDate", "Validator", HttpMethod = "Post", AdditionalFields = "Id")]
        public DateTime StartDate { get { if (_StartDate == DateTime.MinValue) { if (this.Debt == null) { return DateTime.Now; } else { return this.Debt.StartDate; } } else { return _StartDate; } } set { _StartDate = value; } }

        private DateTime _EndDate;
        [DataType(DataType.Date)]
        [Display(Name = "End Date")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Remote("UnitEndDate", "Validator", HttpMethod = "Post", AdditionalFields = "Id")]
        public DateTime EndDate { get { if (_EndDate == DateTime.MinValue) { if (this.Debt == null) { return this.StartDate.AddYears(5); } else { return this.Debt.EndDate; } } else { return _EndDate; } } set { _EndDate = value; } }
        

        [Required]
        public virtual Debt Debt{get;set;}
        public virtual User User { get; set; }
    
    }
}