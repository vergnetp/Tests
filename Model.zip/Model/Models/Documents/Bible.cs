﻿//using GenericCore;
//using System;
//using System.Collections.Generic;
//using System.ComponentModel.DataAnnotations;
//using System.Linq;
//using System.Web;

//namespace Models
//{
//    public enum BibleCategory
//    {
//        PurchaseAgreement,
//        Valuation,
//        Insurance,
//        Rentroll,
//        Other
//    }

//    public class Document : IIdentifiable
//    {
//        public int Id { get; set; }
//        public string Name { get; set; }
//        public string Tag { get; set; }

//        private DateTime _Date;
//        [DataType(DataType.Date)]
//        [Display(Name = "Upload Time")]
//        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd hh:mm:ss}", ApplyFormatInEditMode = true)]
//        public DateTime UploadTime { get { if (_Date == DateTime.MinValue) { return DateTime.Now; } else { return _Date; } } set { _Date = value; } }

//        public string Description { get; set; }
//        public string FileName { get; set; }

//        public virtual User User { get; set; }
//    }

//    public class AcquisitionDocument : Document
//    {
//        [Display(Name = "Category")]
//        public BibleCategory BibleCategory { get; set; }
//        [Required]
//        public virtual Property Property { get; set; }
//    }

//    public class LeaseAgreement : Document
//    {
//        [Required]
//        public virtual Lease Lease { get; set; }
//    }

//    public class DebtAgreement : Document
//    {
//        [Required]
//        public virtual Debt Debt { get; set; }
//    }
//}