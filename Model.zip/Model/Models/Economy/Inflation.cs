﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using Finance;
using GenericCore;

namespace eTrackModels
{
    public class InflationGenerator
    {
        protected DateTime _StartDate; protected DateTime _EndDate; 
        public InflationGenerator()
        {
            _StartDate = new DateTime(2000, 1, 1);
            _EndDate = new DateTime(2100, 1, 1);
            IndexScheduler = new Scheduler(_StartDate, _EndDate);
            AnnualRates = new Schedule(_StartDate,0.02); 
        }
        public InflationGenerator(DateTime? startDate = null, DateTime? endDate = null, double annualRate = 0.02)
        {
            _StartDate = startDate ?? new DateTime(2000, 1, 1);
            _EndDate = endDate ?? new DateTime(2100, 1, 1);            
            IndexScheduler = new Scheduler(_StartDate, _EndDate);
            AnnualRates = new Schedule(_StartDate, annualRate);          
        }
        protected Schedule _AnnualRates;
        public Schedule AnnualRates { get { return _AnnualRates; } set { _AnnualRates = value; RefreshRates(); } }
        protected Schedule _Index;
        public Schedule Index { get { if (_Index == null) { RefreshRates(); } return _Index; } set { _Index = value; } }
        public Scheduler IndexScheduler;
        public void ChangeAnnualRate(double annualRate)
        {
            AnnualRates = new Schedule(_StartDate, annualRate);
        }
        public void RefreshRates()
        {
            _Index = IndexScheduler.Schedule;
            _Index[0].Item.Value = 100;
            for (var i = 1; i < _Index.Count; i++)
            {
                var inflation = AnnualRates.FindFirst(_Index[i].Date).Item.Value;
                var continuousInflation = Math.Log(1 + inflation);
                var yearfrac = DateHelper.Yearfrac(_Index[i - 1].Date, _Index[i].Date, DayCount.ActAct);
                _Index[i].Item.Value = _Index[i - 1].Item.Value * Math.Exp(continuousInflation * yearfrac);
            }
        }
    }

    public class Inflation :IId
    {
        public Inflation() { this.Indexer = new InflationGenerator(); }

        public Inflation(string name, string description = "") : this() { Name = name; Description = description; }               
       
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime StartDate { get { return this.Indexer.IndexScheduler.StartDate; } set { this.Indexer.IndexScheduler.StartDate = value; this.Indexer.RefreshRates(); } }
        public DateTime EndDate { get { return this.Indexer.IndexScheduler.EndDate; } set { this.Indexer.IndexScheduler.EndDate = value; this.Indexer.RefreshRates(); } }
        public Schedule AnnualRates { get { return this.Indexer.AnnualRates; } set { this.Indexer.AnnualRates = value; } }
        public Schedule Index { get { return this.Indexer.Index; } set { this.Indexer.Index = value;  } }
        
        public void ChangeAnnualRate(double annualRate) { this.Indexer.ChangeAnnualRate(annualRate); }

        // Tool (should propably be protected):
        public InflationGenerator Indexer;

        [Required]
        public virtual Country Country { get; set; }
        //[Required]
        [HiddenInput(DisplayValue = false)]
        public virtual User User { get; set; }

        #region Methods

        public static Inflation Default(DateTime? startDate = null, DateTime? endDate = null, double annualRate = 0.02)
        {
            var inf = new Inflation("Default Inflation");
            inf.Indexer = new InflationGenerator(startDate, endDate, annualRate);
            return inf;
        }  

        public double GetInflation(DateTime previous, DateTime next)
        {
            Check(this.Indexer != null);
            Check(this.Indexer.Index.Count >= 2);
            Check(next >= previous);
            Check(previous >= this.Indexer.Index.First().Date);
            Check(next <= this.Indexer.Index.Last().Date);
            double previousIndex = 1.0; double nextIndex = 1.0;
            for (var i = 0; i < this.Indexer.Index.Count - 1; i++)
            {
                if (this.Indexer.Index[i].Date <= previous && previous <= this.Indexer.Index[i + 1].Date)
                {
                    previousIndex = this.Indexer.Index[i].Item.Value;
                }
                if (this.Indexer.Index[i].Date <= next && next <= this.Indexer.Index[i + 1].Date)
                {
                    nextIndex = this.Indexer.Index[i].Item.Value;
                }
            }
            Check(previousIndex > 0);
            var res = nextIndex / previousIndex - 1.0;
            return res;
        }

        // todo: better strategy
        protected void Check(bool condition)
        {
            if (!condition) throw new Exception("Arguments not valid");
        }

        #endregion
    
    }
}
