﻿using Finance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eTrackModels
{
    /// <summary>
    /// Encapsulate a Schedule called AnnualRates. 
    /// Can be entered directly from scratch by a user.
    /// Alternatively, the user can call the Reset function to create an empty schedule and work on it.
    /// A List<Accrual> called DueAmounts and a List<CashFlow> called CashFlows are automatically calculated when a new AnnualRates Schedule is set.
    /// NB. Those CashFlows' schedule is calculated against the accruals schedule (f.e payments 3 days later)
    /// However, if the AnnualRates Schedule is modified by the user, he has the responsability to call RefreshDueAmounts (which also refresh the cashflows).
    /// The DueAmounts and the CashFlows can also be modified or populated from scratch or by using their reste functions by the user.
    /// </summary>
    public class AccrualsFromAnnualRates:Accruals
    {
        public AccrualsFromAnnualRates() { this.Reset(new DateTime(2000,1,1),new DateTime(2002,1,1),0.0,new Currency("EUR"),null); }
        public AccrualsFromAnnualRates(string name, string description = "") : base( name, description) { }
        
        /// <summary>
        /// Is fired after the reset but before due amounts and cashflows are recalculated.
        /// </summary>
        public event EventHandler OnRatesReset;

        public void Reset(DateTime startDate, DateTime endDate, double annualRate, Currency currency, Inflation inflation,// todo: =null for flat
           DateTime? asAt = null,
           bool revisionUpwardOnly = false, double? revisionCap = null, int? rateFreePeriod = null,
           DateTime? revisionFirstPeriodEndDate = null, FrequencyPeriod revisionFrequencyPeriod = FrequencyPeriod.Y,
           int revisionFrequencyPeriodMultiplier = 1, RollConvention revisionRollConvention = RollConvention.EOM,
           BusinessDayConvention revisionBusinessDayConvention = BusinessDayConvention.NONE, List<string> revisionBusinessCenters = null,
           DateTime? accrualFirstPeriodEndDate = null, FrequencyPeriod accrualFrequencyPeriod = FrequencyPeriod.Y,
           int accrualFrequencyPeriodMultiplier = 1, RollConvention accrualRollConvention = RollConvention.EOM,
           BusinessDayConvention accrualBusinessDayConvention = BusinessDayConvention.NONE, List<string> accrualBusinessCenters = null,
           int paymentOffsetPeriodMultiplier = 0, FrequencyPeriod paymentOffsetPeriod = FrequencyPeriod.D,
           BusinessDayConvention paymentBusinessDayConvention = BusinessDayConvention.NONE, List<string> paymentBusinessCenters = null,
           bool paymentInAdvance = false, int paymentNbPeriodSkipped = 0
           )
        {
            base.Reset(startDate, endDate, currency, accrualFirstPeriodEndDate, accrualFrequencyPeriod, accrualFrequencyPeriodMultiplier, accrualRollConvention, accrualBusinessDayConvention, accrualBusinessCenters, paymentOffsetPeriodMultiplier, paymentOffsetPeriod, paymentBusinessDayConvention, paymentBusinessCenters, paymentInAdvance, paymentNbPeriodSkipped);
            // Parent? public virtual Company Company{get;set;}            
            //if (revisionFirstPeriodEndDate == null) revisionFirstPeriodEndDate = new DateTime(startDate.Year + 1, 1, 1);
            //if (asAt == null) asAt = startDate;
            this._AnnualRateGenerator = new AnnualRateGenerator(startDate);
            this._AnnualRateGenerator.AnnualRate = annualRate;
            if (asAt != null) this._AnnualRateGenerator.AsAt = asAt.Value;
            this._AnnualRateGenerator.RateFreePeriod = rateFreePeriod;
            this._AnnualRateGenerator.Inflation = inflation;
            this._AnnualRateGenerator.IsRevisionUpwardOnly = revisionUpwardOnly;
            this._AnnualRateGenerator.RevisionCap = revisionCap;
            this._AnnualRateGenerator.RevisionScheduler = new Scheduler(startDate);
            this._AnnualRateGenerator.RevisionScheduler.StartDate = startDate;
            this._AnnualRateGenerator.RevisionScheduler.EndDate = endDate;
            if (revisionFirstPeriodEndDate != null) this._AnnualRateGenerator.RevisionScheduler.FirstPeriodEndDate = revisionFirstPeriodEndDate.Value;
            this._AnnualRateGenerator.RevisionScheduler.FrequencyPeriod = revisionFrequencyPeriod;
            this._AnnualRateGenerator.RevisionScheduler.FrequencyPeriodMultiplier = revisionFrequencyPeriodMultiplier;
            this._AnnualRateGenerator.RevisionScheduler.RollConvention = revisionRollConvention;
            this._AnnualRateGenerator.RevisionScheduler.BusinessDayAdjuster = new BusinessDayAdjuster();
            this._AnnualRateGenerator.RevisionScheduler.BusinessDayAdjuster.BusinessDayConvention = revisionBusinessDayConvention;
            this._AnnualRateGenerator.RevisionScheduler.BusinessDayAdjuster.BusinessCenters = revisionBusinessCenters;
            if (OnRatesReset != null) OnRatesReset(this, EventArgs.Empty);
            // Calculations:
            if (_AnnualRateGenerator.RateFreePeriod != null)
            {
                _AccrualGenerator.AccrualScheduler.StartDate = _AnnualRateGenerator.RevisionScheduler.StartDate.AddMonths(_AnnualRateGenerator.RateFreePeriod.Value);
            }            
            _AnnualRateGenerator.RefreshRates();           
            RefreshDueAmounts();
        }

        public AnnualRateGenerator _AnnualRateGenerator=new AnnualRateGenerator();

        public double AnnualRate { get { return _AnnualRateGenerator.AnnualRate; } set { _AnnualRateGenerator.AnnualRate=value; } }
               
        public Schedule AnnualRates
        {
            get
            {
                return _AnnualRateGenerator.AnnualRates;
            }
            set
            {
                _AnnualRateGenerator.AnnualRates=value;
            }
        }        

        public List<Accrual> GetCalculatedDueAmounts()
        {
            var res = Finance.Calculator.GetAccruals(_AccrualGenerator.AccrualScheduler, this._AnnualRateGenerator.AnnualRates, this.Currency);
            return res;
        }
        public void RefreshDueAmounts()
        {
            var res = GetCalculatedDueAmounts();
            this.DueAmounts = res;
            this.RefreshCashflows();
        }        
        
    }
}
