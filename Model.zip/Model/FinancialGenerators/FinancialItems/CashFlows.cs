﻿using Finance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eTrackModels
{


    /// <summary>
    /// Encapsulate a List<CashFlow> called Values.
    /// Can be entered directly from scratch by a user.
    /// Alternatively, the user can call the Reset function to create an empty schedule and work on it.
    /// </summary>
    public class CashFlows: IEntity
    {
        public CashFlows() { this._CashFlowGenerator = new StandaloneCashFlowGenerator(); }
        public CashFlows(string name, string description = "") : this() { Name = name; Description = description; }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        protected DateTime _StartDate;
        public DateTime StartDate { get { return _StartDate; } set { _StartDate = value; RefreshValues(); } }
        protected DateTime _EndDate;
        public DateTime EndDate { get { return _EndDate; } set { _EndDate = value; RefreshValues(); } }
        protected Currency _Currency;
        public Currency Currency { get { return _Currency; } set { _Currency = value; RefreshValues(); } }
        public IEntity Parent { get { return null; } }

        public void Reset(DateTime startDate,DateTime endDate,Currency currency=null,           
            DateTime? paymentFirstPeriodEndDate=null,
            int paymentPeriodMultiplier=0,FrequencyPeriod paymentPeriod=FrequencyPeriod.D,RollConvention paymentRollConvention=RollConvention.EOM,
            BusinessDayConvention paymentBusinessDayConvention = BusinessDayConvention.NONE, List<string> paymentBusinessCenters = null
            )
        {            
            // Parent? public virtual Company Company{get;set;}           
            //if (paymentFirstPeriodEndDate == null) paymentFirstPeriodEndDate = new DateTime(startDate.Year + 1, 1, 1);
            this._CashFlowGenerator = new StandaloneCashFlowGenerator();
            this._CashFlowGenerator.PaymentScheduler=new Scheduler(startDate);
            this._CashFlowGenerator.PaymentScheduler.StartDate=startDate;
            this._CashFlowGenerator.PaymentScheduler.EndDate=endDate;
            if (paymentFirstPeriodEndDate != null) this._CashFlowGenerator.PaymentScheduler.FirstPeriodEndDate = paymentFirstPeriodEndDate.Value;
            this._CashFlowGenerator.PaymentScheduler.FrequencyPeriodMultiplier=paymentPeriodMultiplier;
            this._CashFlowGenerator.PaymentScheduler.FrequencyPeriod=paymentPeriod;
            this._CashFlowGenerator.PaymentScheduler.RollConvention=paymentRollConvention;
            this._CashFlowGenerator.PaymentScheduler.BusinessDayAdjuster=new BusinessDayAdjuster();
            this._CashFlowGenerator.PaymentScheduler.BusinessDayAdjuster.BusinessDayConvention=paymentBusinessDayConvention;
            this._CashFlowGenerator.PaymentScheduler.BusinessDayAdjuster.BusinessCenters=paymentBusinessCenters;
            RefreshValues();
         }

        public void RefreshValues()
        {
             _CashFlowGenerator.PaymentScheduler.GenerateSchedule();
            this.Values = _CashFlowGenerator.PaymentScheduler.Schedule.ToCashFlows(this.Currency);
        }

        // todo: add linear split of amount, bell curve split etc.
        protected StandaloneCashFlowGenerator _CashFlowGenerator { get; private set; }
        public List<CashFlow> Values { get { return this._CashFlowGenerator.CashFlows; } set { this._CashFlowGenerator.CashFlows=value;} }
    }
}
