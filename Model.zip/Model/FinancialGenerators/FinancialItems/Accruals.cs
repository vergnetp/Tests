﻿using Finance;
using GenericCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eTrackModels
{

    /// <summary>
    /// Encapsulate a List<Accrual> called DueAmounts. 
    /// Can be entered directly from scratch by a user.
    /// Alternatively, the user can call the Reset function to create an empty schedule and work on it.
    /// A List<CashFlow> called CashFlows is automatically calculated when a new List<Accrual> is set.
    /// NB. Those CashFlows' schedule is calculated against the accruals schedule (f.e payments 3 days later)
    /// However, if the List<Accrual>is modified by the user, he has the reposnsability to call RefreshCashFlow.
    /// The CashFlows can also be modified or populated from scratch by the user.
    /// </summary>
    public class Accruals:IId
    {
        public Accruals() { }
        public Accruals(string name, string description = "") : this() { Name = name; Description = description; }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        /// <summary>
        /// Event raised after rest has been called and arguments cached, but before any CashFlows recalculation
        /// </summary>
        public event EventHandler OnAccrualReset;

        public void Reset(DateTime startDate, DateTime endDate, Currency currency, 
            DateTime? accrualFirstPeriodEndDate = null, FrequencyPeriod accrualFrequencyPeriod = FrequencyPeriod.Y,
            int accrualFrequencyPeriodMultiplier = 1, RollConvention accrualRollConvention = RollConvention.EOM,
            BusinessDayConvention accrualBusinessDayConvention = BusinessDayConvention.NONE, List<string> accrualBusinessCenters = null,
            int paymentOffsetPeriodMultiplier = 0, FrequencyPeriod paymentOffsetPeriod = FrequencyPeriod.D,
            BusinessDayConvention paymentBusinessDayConvention = BusinessDayConvention.NONE, List<string> paymentBusinessCenters = null,
            bool paymentInAdvance = false, int paymentNbPeriodSkipped = 0
            )
        {           
            // Parent? public virtual Company Company{get;set;}
            Currency = currency;
            //if (accrualFirstPeriodEndDate == null) accrualFirstPeriodEndDate = new DateTime(startDate.Year + 1, 1, 1);
            this._AccrualGenerator = new AccrualGenerator();
            this._AccrualGenerator.AccrualScheduler = new Scheduler(startDate);
            this._AccrualGenerator.AccrualScheduler.StartDate = startDate;
            this._AccrualGenerator.AccrualScheduler.EndDate = endDate;
            if(accrualFirstPeriodEndDate!=null)this._AccrualGenerator.AccrualScheduler.FirstPeriodEndDate = accrualFirstPeriodEndDate.Value;
            this._AccrualGenerator.AccrualScheduler.FrequencyPeriod = accrualFrequencyPeriod;
            this._AccrualGenerator.AccrualScheduler.FrequencyPeriodMultiplier = accrualFrequencyPeriodMultiplier;
            this._AccrualGenerator.AccrualScheduler.RollConvention = accrualRollConvention;
            this._AccrualGenerator.AccrualScheduler.BusinessDayAdjuster = new BusinessDayAdjuster();
            this._AccrualGenerator.AccrualScheduler.BusinessDayAdjuster.BusinessDayConvention = accrualBusinessDayConvention;
            this._AccrualGenerator.AccrualScheduler.BusinessDayAdjuster.BusinessCenters = accrualBusinessCenters;
            this._CashFlowGenerator = new CashFlowGenerator();
            this._CashFlowGenerator.PaymentScheduler = new PaymentScheduler();
            this._CashFlowGenerator.PaymentScheduler.CalculationScheduler = this._AccrualGenerator.AccrualScheduler;
            this._CashFlowGenerator.PaymentScheduler.BusinessDayAdjuster = new BusinessDayAdjuster();
            this._CashFlowGenerator.PaymentScheduler.BusinessDayAdjuster.BusinessDayConvention = paymentBusinessDayConvention;
            this._CashFlowGenerator.PaymentScheduler.BusinessDayAdjuster.BusinessCenters = paymentBusinessCenters;
            this._CashFlowGenerator.PaymentScheduler.OffsetPeriodMultiplier = paymentOffsetPeriodMultiplier;
            this._CashFlowGenerator.PaymentScheduler.OffsetPeriod = paymentOffsetPeriod;
            this._CashFlowGenerator.PaymentScheduler.InAdvance = paymentInAdvance;
            this._CashFlowGenerator.PaymentScheduler.NbPeriodSkipped = paymentNbPeriodSkipped;
            if (OnAccrualReset != null) OnAccrualReset(this, EventArgs.Empty);
            // Calculations:
            this.DueAmounts=_AccrualGenerator.AccrualScheduler.Schedule.ToAccruals(currency); 
        }

        /// <summary>
        /// Can be modified or directly populated by the user.
        /// If modified, the user must call RefreshCashFlows.
        /// </summary>
        public List<Accrual> DueAmounts { get { return _AccrualGenerator.Accruals; } set { _AccrualGenerator.Accruals = value; RefreshCashflows(); } }
        public List<CashFlow> CashFlows { get { return _CashFlowGenerator.CashFlows; } set { _CashFlowGenerator.CashFlows = value; } }
        public Currency Currency;

        protected AccrualGenerator _AccrualGenerator=new AccrualGenerator();
        protected CashFlowGenerator _CashFlowGenerator=new CashFlowGenerator();         

        public List<CashFlow> GetCalculatedCashflows()
        {
            var res = Finance.Calculator.GetCashFlows(this._CashFlowGenerator.PaymentScheduler, this._AccrualGenerator.Accruals, this.Currency);
            return res;
        }
        public void RefreshCashflows()
        {
            var res = GetCalculatedCashflows();
            this.CashFlows = res;
        }
        public Schedule ToAnnualRates()
        {
            var res = new Schedule(DueAmounts);
            for (var i = 0; i < res.Count;i++ )
            {
                res[i].Item.Value /= DateHelper.Yearfrac(DueAmounts[i].StartDate, DueAmounts[i].EndDate);
            }
            return res;
        }
    }
}
