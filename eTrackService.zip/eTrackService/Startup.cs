﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Owin;
using Owin;
using eTrackModels;
using Finance;
using System.IO;
using System.Web;

[assembly: OwinStartup(typeof(eTrackService.Startup))]

namespace eTrackService
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);            
        }
    }


}
