﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GenericCore;
using eTrackService.Models;
using eTrackModels;

namespace eTrackService.Controllers
{
    [Authorize] // todo remove
    [System.Web.Mvc.AllowAnonymous]
    public class PagesController : Controller
    {

        [HttpGet]
        public ActionResult Index(string targetType, string parentType = null, int? parentId = null)
        {
            var pvm = PreparePagesVm(targetType, parentType, parentId);
            return View("Pages/Pages", pvm);
        }

        public void UpdateEntity(string entity, string token)
        {
            var pop = Newtonsoft.Json.JsonConvert.DeserializeObject(entity, typeof(Property));
            var webService = new PagesApiController();
            //webService.UpdateEntity(entity);            
        }
        public void DeleteEntity(string targetType,int targetId,string token)
        {
            var webService = new PagesApiController();
            webService.DeleteEntity(targetType,targetId);           
        }

        /// <summary>
        /// Call the Webservice to request adding a default targetType to the parentType with parentId
        /// Return the last nbItemsPerPage targetTypes
        /// </summary>        
        public string AddDefaultEntity(PagesVm pagesVm,string token=null)
        {              
            var webService = new PagesApiController();
            webService.AddDefaultEntity(pagesVm.TargetType, pagesVm.ParentType, pagesVm.ParentId);            
            var pvm = PreparePagesVm(pagesVm.TargetType, pagesVm.ParentType, pagesVm.ParentId);
            var v = this.RenderViewToString("Pages/Pages", pvm);
            return v;
        }

        /// <summary>
        /// Return the page at index pageIndex with  nbItemsPerPage targetTypes, all children of parentType with parentId (all of them if parent is null)
        /// If pageIndex is negative, return the last nbItemsPerPage targetTypes (no order defined)
        /// </summary>        
        public string ShowPage(int pageId,PagesVm pagesVm)
        {
            var webService = new PagesApiController();
            var entities = webService.GetEntitiesForThePage(pageId,pagesVm.NbItemsPerPage.Value,pagesVm.TargetType,pagesVm.ParentId );
            var s = this.RenderViewToString("Pages/Page",entities);
            return s;
        }

        /// <summary>C:\Users\philippe\Desktop\Dev\eTrack\eTrackService\Controllers\PagesController.cs
        /// Display the entity using the given viewType (Thumbnails, Form etc.)
        /// </summary>
        /// <param name="targetEntity"></param>
        /// <returns></returns>
        public PartialViewResult DisplayEntity(IEntity entity,string viewType)
        {
            var typeName = entity.GetType().Name;
            var v = PartialView(string.Format("~/Views/{0}/Entity/{1}.cshtml", viewType, typeName), entity);
            return v;
        }

       
        public ActionResult ShowSingleEntity(string targetType, int? targetId = null)
        {
            var viewType = "Thumbnails";// todo
            var webService = new PagesApiController();
            var entity = webService.GetEntity(targetType, targetId.Value);
            var v = PartialView(string.Format("~/Views/{0}/Entity/{1}.cshtml", viewType, targetType), entity);
            return v;
        }


        public PagesVm PreparePagesVm(string targetType, string parentType = null, int? parentId = null)
        {
            // Prepare PagesVm           
            var webService = new PagesApiController();
            var pagesVm = new PagesVm() { TargetType = targetType, ParentType = parentType, ParentId = parentId };
            // Add NbEntities and ParentName (needs calls to db): 
            pagesVm.NbEntities = webService.GetEntities(targetType, parentId).Count();
            // Add NbItemsPerPages and NbPages:
            int nbItemsPerPage = 6;
            // todo: specialize depending of viewType
            var mapping = new Dictionary<string, int>();
            mapping["Portfolio"] = 4;
            mapping["Company"] = 4;
            mapping["Property"] = 4;
            // end todo
            if (mapping.ContainsKey(pagesVm.TargetType))
            {
                nbItemsPerPage = mapping[pagesVm.TargetType];
            }
            pagesVm.NbItemsPerPage = nbItemsPerPage;
            pagesVm.NbPages = pagesVm.NbEntities % nbItemsPerPage > 0 ? pagesVm.NbEntities / nbItemsPerPage + 1 : pagesVm.NbEntities / nbItemsPerPage;
            return pagesVm;
        }

       
    }    
}