﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using GenericCore;
using eTrackService.Models;
using System.Reflection;
using eTrackModels;
using System.Collections;

namespace eTrackService.Controllers
{
    [Authorize] // todo remove
    [System.Web.Mvc.AllowAnonymous]
    public class PagesApiController : ApiController
    {
        // todo: add user and comment

        RepoApiController _Repo = new RepoApiController();

        public IEntity GetEntity(string targetType, int targetId)
        {
            var entitiesO = _Repo.GetAll(targetType);
            var entities = new List<IEntity>();
            foreach (var o in entitiesO)
            {
                entities.Add(o as IEntity);
            }
            var res = entities.FirstOrDefault(e => e.Id == targetId);
            return res;
        }

        public List<IEntity> GetEntities(string targetType, int? parentId = null)
        {
            var entitiesO = _Repo.GetAll(targetType);
            var entities = new List<IEntity>();
            foreach (var o in entitiesO)
            {
                entities.Add(o as IEntity);
            }
            if (parentId != null) entities = entities.Where(e => e.Parent.Id == parentId.Value).ToList();
            return entities;
        }

        /// <summary>
        /// Return the page at index pageIndex with  nbItemsPerPage targetTypes, all children of parentType with parentId (all of them if parent is null)
        /// If pageIndex is negative, return the last nbItemsPerPage targetTypes (no order defined)
        /// </summary>        
        public List<IEntity> GetEntitiesForThePage(int pageId, int nbItemsPerPage, string targetType, int? parentId)
        {
            // Request the targeted entities from the webservice:
            var entities = GetEntities(targetType, parentId);
            // if error:
            // todo
            // Return:
            if (pageId < 0)
            {
                // we take the last page
                entities = entities.Skip(entities.Count - nbItemsPerPage).ToList();
            }
            else
            {
                entities = entities.Skip((pageId - 1) * nbItemsPerPage).ToList().Take(nbItemsPerPage).ToList();
            }
            return entities;
        }

        public string AddDefaultEntity(string targetType,string parentType=null,int? parentId=0,string userName="",string comment="")
        {
            Assembly assem = typeof(Property).Assembly;
            Type t = assem.GetType("eTrackModels."+targetType);
            var newEntity = Activator.CreateInstance(t);// tood factory(type) ?
            int lastId = 0;
            var entities=GetEntities(targetType);
            if (entities.Count > 0) lastId =entities.Max(e => e.Id);
            (newEntity as IId).Id = lastId + 1;
            if (parentType != null)
            {
                var parent = _Repo.Find(parentType, parentId.Value);
                var propertyInfo = parent.GetType().GetProperty(string.Format("{0}s",targetType));
                var list = propertyInfo.GetValue(parent) as IList;
                list.Add(newEntity);
                var propertyInfo2 = newEntity.GetType().GetProperty(parentType);
                propertyInfo2.SetValue(newEntity, parent);
                _Repo.Update(parent, userName,comment);
            }
            else
            {
                _Repo.Add(newEntity, userName,comment);     
            }
            return "Done";
        }

        public string UpdateEntity(IEntity entity, string userName = "", string comment = "")
        {
            _Repo.Update(entity,userName,comment);
            return "Done";
        }

        public string DeleteEntity(string targetType, int targetId, string userName = "", string comment = "")
        {
            var keepTypes = new List<Type>();
            IId parent = null;
            Assembly assem = typeof(Property).Assembly;
            Type ty = assem.GetType("eTrackModels." + targetType);
            var newEntity = Activator.CreateInstance(ty);// tood factory(type) ?
            if (typeof(IEntity).IsAssignableFrom(newEntity.GetType()))
            {
                var targetEntity = _Repo.Find(targetType, targetId);
                if (targetEntity != null && (targetEntity as IEntity) != null && (targetEntity as IEntity).Parent != null)
                {
                    var t = (targetEntity as IEntity).Parent.GetType();                    
                    keepTypes.Add(t);                   
                    parent = (targetEntity as IEntity).Parent;
                    var propertyInfo = parent.GetType().GetProperty(string.Format("{0}s", targetType));
                    var list = propertyInfo.GetValue(parent) as IList;
                    list.Remove(targetEntity);                    
                }
            }
            _Repo.Delete(targetType, targetId,keepTypes.ToArray(),userName,comment);
            if(parent!=null)_Repo.Update(parent);
            return "Done";
        }
     
    }
}
