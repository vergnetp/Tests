﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using eTrackModels;
using Tools;

namespace eTrackService.Controllers
{
    [AllowAnonymous]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Title = "Home Page";
            var prop = new eTrackModels.Property("Agra");
            PropertyDto dto = new PropertyDto();
            dto.InjectFrom<FlatLoopInjection>(prop);
            return View(prop);
        }

        [HttpPost]
        public void SetThumbnailsPref()
        {
            TempData["ViewType"] = "Thumbnails";
            //return Redirect(Request.UrlReferrer.ToString());
        }
        [HttpPost]
        public void SetListPref()
        {
            TempData["ViewType"] = "List";
            //return Redirect(Request.UrlReferrer.ToString());
        }

    }

    
}
