﻿using GenericRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Generic.Repository.Db4o;
using GenericCore;
using eTrackModels;
using System.Web;


namespace eTrackService.Controllers
{
    [Authorize] // todo remove
    [System.Web.Mvc.AllowAnonymous]
    public class RepoApiController : ApiController
    {
        IGenericRepository _Repo;

        public RepoApiController()
        {
            var root = HttpContext.Current.Server.MapPath("~/App_Data/Db4o");
            Generic.Repository.Db4o.GenericRepositoryDb4o.SetRoot(root);
            _Repo = new GenericRepositoryDb4o("Prod"); // todo inject
            _Repo.TypesToKeep.Add(typeof(Inflation));
        }

        public List<T> GetAll<T>() where T:class
        {
            var ret = _Repo.GetAll<T>();
            return ret;
        }

        public void Add(object entity, string userName = "", string comment = "")
        {
            _Repo.Add(entity, userName, comment);
        }
        public void Update(IId entity, string userName = "", string comment = "")
        {
            _Repo.Update(entity, userName, comment);
        }
        public void Delete(IId entity, Type[] keepTypes = null, string userName = "", string comment = "")
        {
            _Repo.Delete(entity, keepTypes, userName, comment);
        }
        public void Delete(string targetType, int targetId, Type[] keepTypes = null, string userName = "", string comment = "")
        {            
            _Repo.Delete(targetType, targetId,keepTypes,userName,comment);
        }
        public List<object> GetAll(Type type){return _Repo.GetAll(type);}
        public IList<object> GetAll(string type){return _Repo.GetAll(type);}
        public T Find<T>(int id) where T : class, IId{return _Repo.Find<T>(id);}
        public IId Find(Type type, int id){return _Repo.Find(type,id);}
        public IId Find(string typeName, int id) { return _Repo.Find(typeName, id); }
    }
}
