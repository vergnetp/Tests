﻿using Reporting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Html;

// thread safe?
public static class TreeScheduleViewer
{

    public static IHtmlString DisplayTreeSchedule(this HtmlHelper html, TreeSchedule treeSchedule)
    {
        var sb = new StringBuilder();
        sb.Append("<table id='TreeTable' border='0' class='Accruals'>\n");
        //sb.Append("<theader>");
        sb.Append("<tr class='AccrualsHeader'>\n");
        sb.Append(@"<td style='text-align:left' onclick='ExpandLevel(""Portfolio"")'>");
        sb.AppendFormat("{0}", ButtonHelper.SimpleButton("Portfolio"));
        sb.Append("</td>");
        sb.Append(@"<td style='text-align:left' onclick='ExpandLevel(""Property"")'>");
        sb.AppendFormat("{0}", ButtonHelper.SimpleButton("Property"));
        sb.Append("</td>");
        sb.Append(@"<td style='text-align:left' onclick='ExpandLevel(""Lease"")'>");
        sb.AppendFormat("{0}", ButtonHelper.SimpleButton("Lease"));
        sb.Append("</td>");
        foreach (var scheduleItem in treeSchedule)
        {
            sb.Append("<td>");
            sb.Append(scheduleItem.Date.ToString("dd-MMM-yy"));
            sb.Append("</td>");
        }
        sb.Append("</tr>\n");
        //sb.Append("</theader>");
        //sb.Append("<tbody>\n");
        var data = _DisplayTreeSchedule(treeSchedule);
        sb.Append(data);
        //sb.Append("</tbody>\n");
        sb.Append("</table>\n");
        sb.Append("<script>$('#TreeTable').treetable({ expandable: true }); $('#TreeTable tbody').on('mousedown', 'tr', function() { $('.selected').not(this).removeClass('selected'); $(this).toggleClass('selected');});</script>");
        return new HtmlString(sb.ToString());
    }

    private static string _DisplayTreeSchedule(TreeSchedule treeSchedule, string currentName = null)
    {
        var sb = new StringBuilder();
        var isNode = treeSchedule.Children.Any();
        if (currentName == null)
        {
            sb.Append(string.Format("<tr data-tt-id='{0}' level='{1}'>\n", CleanText(treeSchedule.Name), treeSchedule.Level));
        }
        else
        {
            sb.Append(string.Format("<tr data-tt-id='{0}' data-tt-parent-id='{1}' level='{2}'>\n", CleanText(treeSchedule.Name), CleanText(currentName), treeSchedule.Level));
        }
        sb.Append("<td style='text-align:left'>");
        sb.Append(treeSchedule.Name);
        sb.Append("</td>");
        sb.Append("<td>");
        sb.Append("</td>");
        sb.Append("<td>");
        sb.Append("</td>");
        // values
        foreach (var scheduleItem in treeSchedule)
        {
            if (scheduleItem.Item.Value < 0)
            { if (isNode) { sb.Append("<td class='negative-number'>"); } else { sb.Append("<td class='leaf-negative-number'>"); } }
            else
            { sb.Append("<td>"); }
            sb.Append(string.Format("{0:0,0}", scheduleItem.Item.Value)); // todo: color if overriden
            sb.Append("</td>");
        }
        sb.Append("\n</tr>\n");

        // recursive call on children
        foreach (var child in treeSchedule.Children)
        {
            sb.Append(_DisplayTreeSchedule(child, treeSchedule.Name));
        }


        // return
        return sb.ToString();
    }


    public static string CleanText(string s)
    {
        return s.Replace('(', ' ').Replace(')', ' ').Replace(' ', '_');
    }


    public static IHtmlString DisplayTreeSchedule0(this HtmlHelper html, TreeSchedule treeSchedule)
    {
        var sb = new StringBuilder();
        sb.Append("<table border='0' class='Accruals'>\n");
        sb.Append("<tr class='AccrualsHeader'>\n");
        sb.Append("<td>");
        sb.Append("</td>");
        foreach (var scheduleItem in treeSchedule.Skip(1))
        {
            sb.Append("<td>");
            sb.Append(scheduleItem.Date.ToString("MMM-yy"));
            sb.Append("</td>");
        }
        sb.Append("</tr>\n");
        var data = _DisplayTreeSchedule0(treeSchedule);
        sb.Append(data);
        sb.Append("</table>\n");
        return new HtmlString(sb.ToString());
    }

    private static string _DisplayTreeSchedule0(TreeSchedule treeSchedule, string currentName = null)
    {
        var sb = new StringBuilder();

        var collapsed = currentName != null ? " collapse" : string.Empty;
        var isNode = treeSchedule.Children.Any();

        // key
        if (isNode)
        {
            // node
            sb.Append(string.Format("<tr class='AccrualsWithChildren {0}{1}' data-toggle='collapse' data-target='.{2}'>\n", currentName, collapsed, treeSchedule.Name));
            sb.Append("<td style='text-align:left'>");
            var control = "<div>{0}</div>"; // add fold icon?
            sb.Append(string.Format(control, treeSchedule.Name));
            sb.Append("</td>");
        }
        else
        {
            //leaf
            sb.Append(string.Format("<tr class='LeafAccruals {0}{1}'>\n", currentName, collapsed));
            sb.Append("<td style='text-align:left'>");
            sb.Append(treeSchedule.Name);
            sb.Append("</td>");
        }

        // values
        foreach (var scheduleItem in treeSchedule.Take(treeSchedule.Count - 1))
        {
            if (scheduleItem.Item.Value < 0)
            { if (isNode) { sb.Append("<td class='negative-number'>"); } else { sb.Append("<td class='leaf-negative-number'>"); } }
            else
            { sb.Append("<td>"); }
            sb.Append(string.Format("{0:0,0}", scheduleItem.Item.Value)); // todo: color if overriden
            sb.Append("</td>");
        }
        sb.Append("\n</tr>\n");

        // recursive call
        foreach (var child in treeSchedule.Children)
        {
            sb.Append(_DisplayTreeSchedule0(child, currentName + " " + treeSchedule.Name));
        }

        // return
        return sb.ToString();
    }




}
