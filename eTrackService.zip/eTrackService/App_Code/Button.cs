﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Html;

// thread safe?
public static class ButtonHelper
{
    public static string RoundButton(string value)
    {
        var sb = new StringBuilder();
        sb.AppendLine("<div id='container'>");
        sb.AppendLine("<div id='button-container'>");
        sb.AppendLine("<div id='button' class='green'>");
        sb.AppendLine("<div id='order'><div id='order-line'></div><div id='order-line'></div></div>");
        sb.AppendFormat("<p>{0}</p>\n", value);
        sb.AppendLine("</div>");
        sb.AppendLine("</div>");
        sb.AppendLine("</div>");
        return sb.ToString();
    }

    public static IHtmlString RoundButton(this HtmlHelper html, string value)
    {
        var result = RoundButton(value);
        return new HtmlString(result);
    }

    public static string SimpleButton(string value)
    {
        var result = string.Format("<span class='label label-default'>{0}</span>", value);
        return result;
    }
    public static IHtmlString SimpleButton(this HtmlHelper html, string value)
    {
        var result = SimpleButton(value);
        return new HtmlString(result);
    }
}