﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Helpers;
using System.Web.Mvc;
using System.Web.Mvc.Html;

public static class AjaxHelper
{

    public static IHtmlString Post(this HtmlHelper html, string action, string controller, object model, string containerId = "MainContainer")
    {
        var result = string.Format(@"onclick='Post(""{0}/{1}"",{2},""{3}"")'", controller, action, html.Raw(Json.Encode(model)), containerId);
        return new HtmlString(result);
    }
    public static IHtmlString PostRedirect(this HtmlHelper html, string action, string controller, object model, string url = "Index")
    {
        var result = string.Format(@"onclick='PostRedirect(""{0}/{1}"",{2},""{3}"")'", controller, action, html.Raw(Json.Encode(model)), url);
        return new HtmlString(result);
    }
    public static IHtmlString PostReLoad(this HtmlHelper html, string action, string controller, object model)
    {
        var result = string.Format(@"onclick='PostReLoad(""{0}/{1}"",{2})'", controller, action, html.Raw(Json.Encode(model)));
        return new HtmlString(result);
    }

    public static IHtmlString Serialize(this HtmlHelper html,object model)
    {
        var result = html.Raw(Json.Encode(model));
        return result;
    }
}
