﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using GenericCore;
using Tools;

public static class Form
{

    public static IHtmlString DisplayPropertyAsForm(this HtmlHelper html, IId targetEntity, string propertyName)
    {
        object propertyValue = null;
        Type propertyType = typeof(string);
        if (targetEntity != null)
        {
            var propertyInfo = targetEntity.GetType().GetProperty(propertyName);
            propertyType = propertyInfo.PropertyType;
            propertyValue = propertyInfo.GetValue(targetEntity);
        }
        var sb = new StringBuilder();
        if (!propertyName.Equals("Id") && !propertyName.Equals("User"))
        {
            sb.Append("<div class='form-group'>\n");
            var label = html.Label(propertyName, htmlAttributes: new { @class = "control-label col-md-2" });
            sb.Append("    ");
            sb.Append(label.ToHtmlString());
            sb.Append("\n");
            sb.Append("    ");
            sb.Append("<div class='col-md-10'>\n");
            if (typeof(IId).IsAssignableFrom(propertyType))
            {
                var relatedEntity = propertyValue as IId;
                if (relatedEntity == null)
                {
                    var link = html.DisplayMissingRelatedEntityAsLink(propertyType.Name, targetEntity);
                    sb.Append(link);
                }
                else
                {
                    var link = html.DisplayExistingRelatedEntityAsLink(relatedEntity, targetEntity);
                    sb.Append(link);
                }
            }
            else
            {
                var enumeratedType = propertyType.GetEnumeratedType();
                if (typeof(IId).IsAssignableFrom(enumeratedType))
                {
                    var relatedEntities = propertyValue as IEnumerable<IId>;
                    if (relatedEntities == null)
                    {
                        var col = propertyValue as ICollection;
                        var list = new List<IId>();
                        if (col != null)
                        {
                            foreach (var item in col)
                            {
                                list.Add((IId)item);
                            }
                            relatedEntities = list;
                        }
                    }
                    if (relatedEntities != null)
                    {
                        var link = html.DisplayEntityListAsLink(relatedEntities, targetEntity);
                        sb.Append(link);
                    }
                }
                else
                {
                    if (!targetEntity.GetType().GetProperty(propertyName).CanWrite)
                    {
                        sb.AppendFormat("<span class='btn'>{0}</span>", propertyValue);
                    }
                    else
                    {
                        var edit = html.Editor(propertyName, new { htmlAttributes = new { @class = "form-control", value = propertyValue } });
                        var val = html.ValidationMessage(propertyName, new { @class = "text-danger" });
                        sb.Append("        ");
                        sb.Append(edit.ToHtmlString());
                        sb.Append("\n");
                        sb.Append("        ");
                        if (val!=null)sb.Append(val.ToHtmlString());
                        sb.Append("\n");
                        sb.Append("    ");
                    }
                }
            }
            sb.Append("</div>\n");
            sb.Append("</div>\n");
        }
        var deb = sb.ToString();
        return new HtmlString(deb);
    }

    public static IHtmlString DisplayModelAsForm(this HtmlHelper html, IId targetEntity, bool authentification = true)
    {
        var sb = new StringBuilder();
        if (authentification)
        {
            var antiForgery = html.AntiForgeryToken();
            sb.Append(antiForgery);
        }
        sb.Append("<div id='EntityForm' class='form-horizontal'>\n");
        sb.Append("<hr />\n");
        var val = html.ValidationSummary(true, "", new { @class = "text-danger" });
        sb.Append(val);
        var properties = targetEntity.GetType().GetProperties();
        foreach (var property in properties)
        {
            var p = html.DisplayPropertyAsForm(targetEntity, property.Name);
            sb.Append(p);
        }
        sb.Append("    <div class='form-group'>\n");
        sb.Append("        <div class='col-md-offset-2 col-md-10'>\n");
        sb.Append("            <input onclick='document.forms[0].submit()' type='submit' value='Submit' class='btn btn-default' />\n");
        sb.Append("        </div>\n");
        sb.Append("    </div>\n");
        sb.Append("</div>\n");
        var deb = sb.ToString();
        return new HtmlString(deb);
    }


}