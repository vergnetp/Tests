﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using GenericCore;
using Tools;

public static class NavigationLinks
{
    // Diaply of an existing Reference
    public static IHtmlString DisplayExistingRelatedEntityAsLink(this HtmlHelper html, IId targetEntity, IId parentEntity)
    {
        var targetType = targetEntity.GetType().Name;
        var link = html.ActionLink(targetEntity.Id.ToString(), "Details", "Entity", new  { targetType = targetType, targetId = targetEntity.Id }, null);
        var editLink = html.DisplayMissingRelatedEntityAsLink(targetType, parentEntity);
        return new HtmlString("<table border='0' class='btn'><tr style='border:0px'><td style='border:0px'>" + link + "</td><td style='border:0px'>" + editLink + "</td></tr></table>");
    }

    // Display of a missing Reference
    public static IHtmlString DisplayMissingRelatedEntityAsLink(this HtmlHelper html, string targetTypeName, IId parentEntity)
    {
        /*
        object htmlAttributes = new { @class = "btn" };
        if (parentEntity.Id == 0)
        {
            htmlAttributes = new
            {
                @class = "btn disabled"               
            };
        }        
         var link = html.ActionLink("Attach New", "ShowAttachForm", "Entity",
                new
                {
                    targetType = targetTypeName,
                    parentType = parentEntity.GetType().Name,
                    parentId = parentEntity.Id
                },
                htmlAttributes);
         */
        var usedClass = "";
        if (parentEntity.Id == 0) usedClass = "disabled";
        var links = "<a class='{3}' style='float:left;margin-left:5px;' href='/Entity/ShowAttachForm?targetType={0}&parentType={1}&parentId={2}'><img alt='Attach New' title='Attach New' src='/Content/Icons/Add.ico'></a> ";
        links = String.Format(links, targetTypeName, parentEntity.GetType().Name, parentEntity.Id, usedClass);
        var link = new HtmlString(links);
        // WARNING: assume reference name is the targetTypeName
        var existingEntityDisabledAttribute = "";// parentEntity.GetAttribute<ExistingEntityDisbaled>(targetTypeName);
        if (existingEntityDisabledAttribute == null)
        {
            /*
            var pickLink = html.ActionLink("Attach Existing", "ShowPickForm", "Entity",
                    new
                    {
                        targetType = targetTypeName,
                        parentType = parentEntity.GetType().Name,
                        parentId = parentEntity.Id
                    },
                    htmlAttributes);
             */
            links = "<a class='{3}' style='margin-left:5px' href='/Entity/ShowPickForm?targetType={0}&parentType={1}&parentId={2}'><img title='Attach Existing' alt='Attach Existing' src='/Content/Icons/Existing.ico'></a> ";
            links = String.Format(links, targetTypeName, parentEntity.GetType().Name, parentEntity.Id, usedClass);
            var pickLink = new HtmlString(links);
            return new HtmlString(string.Format("<div style='width:50px'>{0}{1}</div>\n", link, pickLink));
        }
        return link;
    }

    // Dispay of a collection (empty or not)
    public static IHtmlString DisplayEntityListAsLink(this HtmlHelper html, IEnumerable<IId> targetEntities, IId parentEntity)
    {
        if (targetEntities == null) return new HtmlString(string.Empty);
        object htmlAttributes = new { @class = "btn" };
        if (parentEntity.Id == 0)
        {
            htmlAttributes = new
            {
                @class = "btn disabled"
            };
        }
        if (targetEntities.Count() > 0)
        {
            var methodName = "Drilldown";
            var displayText = string.Format("{0} items", targetEntities.Count());
            var link = html.ActionLink(displayText, methodName, "Entity",
            new { targetType = targetEntities.GetType().GetEnumeratedType().Name, parentType = parentEntity.GetType().Name, parentId = parentEntity.Id }, htmlAttributes);
            return link;
        }
        else
        {
            var targetTypeName = targetEntities.GetType().GetEnumeratedType().Name;
            var methodName = "ShowAttachForm";
            var displayText = "Add New";
            var link = html.ActionLink(displayText, methodName, "Entity",
                new { targetType = targetEntities.GetType().GetEnumeratedType().Name, parentType = parentEntity.GetType().Name, parentId = parentEntity.Id }, htmlAttributes);
            // WARNING: assume list name is the target type + "s"
            var existingEntityDisabledAttribute = "";// parentEntity.GetAttribute<ExistingEntityDisbaled>(targetTypeName + "s");
            if (existingEntityDisabledAttribute == null)
            {
                var pickLink = html.ActionLink("Add Existing", "ShowPickForm", "Entity",
                    new { targetType = targetTypeName, parentType = parentEntity.GetType().Name, parentId = parentEntity.Id }, htmlAttributes);

                return new HtmlString(string.Format("{0} | {1}", link, pickLink));
            }
            return link;
        }
    }


}
