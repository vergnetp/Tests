﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using GenericCore;
using Tools;

public static class EditableLabelClass
{
    public static IHtmlString EditableLabel(this HtmlHelper html, IId targetEntity, string propertyName)
    {
        object propertyValue = null;
        Type propertyType = typeof(string);
        if (targetEntity != null)
        {
            var propertyInfo = targetEntity.GetType().GetProperty(propertyName);
            if (propertyInfo == null) return new HtmlString("");
            propertyType = propertyInfo.PropertyType;
            propertyValue = propertyInfo.GetValue(targetEntity);
        }
        var sb = new StringBuilder();
        if (!propertyName.Equals("Id") && !propertyName.Equals("User"))
        {
            if(propertyType==typeof(Finance.Schedule))
            {
                var schedule = propertyValue as Finance.Schedule;
                propertyValue = 0;
                if(schedule!=null && schedule.Count>0&&schedule[0].Item!=null){propertyValue =schedule[0].Item.Value;}
                var stringValue = PrepareFlatProperty(html, targetEntity, propertyValue, propertyName+"[0].Item.Value");
                sb.Append(stringValue);
            }
            else if (propertyType == typeof(eTrackModels.AccrualsFromAnnualRates))
            {
                propertyValue = 0;
                var accrual = propertyValue as eTrackModels.AccrualsFromAnnualRates;
                if (accrual != null) propertyValue = accrual.AnnualRate;
                var stringValue = PrepareFlatProperty(html, targetEntity, propertyValue, propertyName + ".AnnualRate");
                sb.Append(stringValue);
            }
            else if (propertyType == typeof(eTrackModels.AnnualRateGenerator))
            {
                propertyValue = 0;
                var annualRateGenerator = propertyValue as eTrackModels.AnnualRateGenerator;
                if (annualRateGenerator != null) propertyValue = annualRateGenerator.AnnualRate;
                var stringValue = PrepareFlatProperty(html, targetEntity, propertyValue, propertyName + ".AnnualRate");
                sb.Append(stringValue);
            }

            else if (typeof(IId).IsAssignableFrom(propertyType) && false)
            {
                // if child:
                var relatedEntity = propertyValue as IId;
                if (relatedEntity == null)
                {
                    var link = html.DisplayMissingRelatedEntityAsLink(propertyType.Name, targetEntity);
                    sb.Append(link);
                }
                else
                {
                    var link = html.DisplayExistingRelatedEntityAsLink(relatedEntity, targetEntity);
                    sb.Append(link);
                }
            }
            else
            {
                // if list of children
                var enumeratedType = propertyType.GetEnumeratedType();
                if (typeof(IId).IsAssignableFrom(enumeratedType))
                {
                    var relatedEntities = propertyValue as IEnumerable<IId>;
                    var link = html.DisplayEntityListAsLink(relatedEntities, targetEntity);
                    sb.Append(link);
                }
                else
                {
                    // flat:
                    var stringValue = PrepareFlatProperty(html, targetEntity, propertyValue, propertyName);
                    sb.Append(stringValue);
                }
            }
        }
        var deb = sb.ToString();
        return new HtmlString(deb);
    }

    private static string PrepareFlatProperty(this HtmlHelper html,IId targetEntity,object propertyValue,string propertyName)
    {
        var formatString = "{0}";
        var attribute = targetEntity.GetAttribute<System.ComponentModel.DataAnnotations.DisplayFormatAttribute>(propertyName);
        if (attribute != null)
        {
            var a = attribute as System.ComponentModel.DataAnnotations.DisplayFormatAttribute;
            formatString = a.DataFormatString;
        }
        var id = string.Format("item_{0}", Guid.NewGuid());
        var displayValue = propertyValue == null ? "Enter " + propertyName + "..." : propertyValue;

        var label = string.Format(@"<span class={1} style='color:#2A6496' onclick='$(this).hide();var target=$(this).siblings("".{1}"").first();target.show();target.select();'>{0}</span>", string.Format(formatString, displayValue), id);
        var edit = html.Editor(propertyName, new
        {
            htmlAttributes = new
            {
                @class = id + " form-control",
                style = "display:none;",
                value = displayValue,
                onblur = string.Format("$(this).hide();var s=$(this).siblings('.{0}');$(s).html($(this).val());$(s).show();$(this).valid();", id),
                onchange = string.Format("$(this).hide();var s=$(this).siblings('.{0}');$(s).html($(this).val());$(s).show();$(this).valid();", id),
            }
        });        

        var val = html.ValidationMessage(propertyName, new { @class = "text-danger" });
        var sb = new StringBuilder();
        sb.AppendLine(label.ToString());
        var editString = edit.ToString().Replace("value=\"\"", string.Format("value=\"{0}\"", displayValue));
        sb.AppendLine(editString);
        if (val != null) sb.AppendLine(val.ToHtmlString());
        return sb.ToString(); ;
    }
}
