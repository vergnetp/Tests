﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Html;

public static class SocialMedia
{

    public static HtmlString GetSocialLinks(this HtmlHelper html, string url, string title)
    {
        var sb = new StringBuilder();
        sb.AppendFormat("<a href='http://www.facebook.com/sharer.php?u={0}&t={1}' target='_blank' title='Share on Facebook'>\n", url, title);
        sb.Append("<img alt='Share on Facebook' src='/Content/Icons/Facebook.png' style='border:0; height:16px; width:16px; margin:0 1px;' title='Share on Facebook' />\n");
        sb.Append("</a>\n");
        sb.AppendFormat("<a href='http://twitter.com/home/?status={1}:+{0}' target='_blank' title='Share on Twitter'>\n", url, title);
        sb.Append("<img alt='Share on Twitter' src='/Content/Icons/Twitter.png' style='border:0; height:16px; width:16px; margin:0 1px;' title='Share on Twitter' />\n");
        sb.Append("</a>\n");
        sb.AppendFormat(@"<a href='https://plus.google.com/share?url={0}' onclick=""javascript:window.open(this.href,'','menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"">", url);
        sb.Append("<img src='/Content/Icons/GooglePlus.png' alt='Share on Google+' />\n");
        sb.Append("</a>\n");
        return new HtmlString(sb.ToString());
    }
}
