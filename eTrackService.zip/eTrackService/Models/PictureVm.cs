﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace eTrackService.Models
{
    public class PictureVm
    {
        public string Source { get; set; }
        public string Name { get; set; }
        public string UploadFolder { get; set; }
    }
}