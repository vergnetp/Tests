﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GenericCore;

namespace eTrackService.Models
{
    /// <summary>
    /// Info needed to display a given current page
    /// But also to be able to navigate back
    /// </summary>
    public class PageVm
    {
        public int CurrentPage { get; set; }
        public List<IId> Entities { get; set; }
        public PagesVm PagesVm { get; set; }            
    }
}
