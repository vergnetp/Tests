﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eTrackService.Models
{

    /// <summary>
    /// Hold all info needed to display a paged list of target entities
    /// Alos hold previous PagesVm such as to be able to navigate backwards (up the parental tree)
    /// </summary>
    public class PagesVm
    {
        public string TargetType { get; set; }
        public string ParentType { get; set; }
        public int? ParentId { get; set; }
        public string ParentName { get; set; } 
        public int? NbPages { get; set; }
        public int? NbEntities { get; set; }
        public int? NbItemsPerPage { get; set; }
        //public List<PagesVm> History { get; set; }
        //public List<string> PreviousUrls {get;set;}
    }
}
