﻿using GenericCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace eTrackService.Models
{
    
    /// <summary>
    /// Info needed to display a given entity
    /// </summary>
    public class EntityVm
    {        
        public IId Entity { get; set; }
        public PageVm PageVm { get; set; }
    }
    
}