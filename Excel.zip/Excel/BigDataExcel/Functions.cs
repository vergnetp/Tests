﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcelDna.Integration;
using BigData;
using BigDataExcel;
using System.Threading;


namespace BigDataExcel
{

    public class Functions
    {

        protected static ModelNeuralNetwork _Model;
        protected static ISolver _Solver;
        protected static IRegularizedCostCalculator _Cost;

        protected static MissingDataHandler _MissingDataHandler;
        protected static DataPreparator _DataPreparator;
        //protected static BigData.Encoder _Encoder;
        protected static MissingDataHandler MissingDataHandler { get { if (_MissingDataHandler == null) { _MissingDataHandler = new MissingDataAverageAndNA(DataPreparator, null, null); } return _MissingDataHandler; } }
        protected static DataPreparator DataPreparator { get { if (_DataPreparator == null) { _DataPreparator = new DataPreparator(null); } return _DataPreparator; } }
        //protected static BigData.Encoder Encoder { get { if (_Encoder == null) { _Encoder = new BigData.Encoder(MissingDataHandler,null,new LoggerNone()); } return _Encoder; } }

        protected static int _ReportStride = 100;


        [ExcelCommand(Description = "Reset the weights of the model to random values", MenuName = "Machine Learning", MenuText = "Reset Model")]
        public static void ResetModel(string reportAnchor, object[,] data, object[] outputColumns, bool hasHeader)
        {
            _Model.ResetWeights(_Model.Parameters.NbFeatures, _Model.Parameters.NbClasses);
            _Solver.Reset();
        }

        [ExcelFunction(Description = "Print the model.", Category = "Machine Learning")]
        public static void PrintModel()
        {
            if (ExcelDnaUtil.IsInFunctionWizard()) return;
            var caller = XlCall.Excel(XlCall.xlfCaller);
            var range = (ExcelReference)caller;
            var res = new ExcelReference(range.RowFirst + 1, range.ColumnFirst);
            var v = SerializeModel();
            ExcelAsyncUtil.QueueAsMacro(() =>
            { Print(v, res); });
        }

        // LoadModel

        #region Initialize

        [ExcelFunction(Description = "Initialize the network. Transfer function: Thanh or Sigmoid.", Category = "Machine Learning")]
        public static string InitializeNetwork(object[] hiddenLayers, string transferFunction)
        {
            if (ExcelDnaUtil.IsInFunctionWizard()) return null;
            var n = hiddenLayers.Length;
            var hiddenLayerSizes = new int[n];
            for (var j = 0; j < n; j++)
            {
                hiddenLayerSizes[j] = Convert.ToInt32(hiddenLayers[j]);
            }
            IActivator activator = new ActivatorTanh();
            if (transferFunction == "Sigmoid") activator = new ActivatorSigmoid();
            _Model = new ModelNeuralNetwork(1, 1, hiddenLayerSizes, _Cost, activator);
            return string.Format("{0}", DateTime.Now);
        }

        [ExcelFunction(Description = "Initialize the solver.", Category = "Machine Learning")]
        public static string InitializeSolver(string type, int maxIterations, double learningRate, double momentumRate)
        {
            if (ExcelDnaUtil.IsInFunctionWizard()) return null;
            if (type == "Momentum")
            {
                _Solver = new SolverMomentum(_Model, maxIterations: maxIterations, learningRate: (float)learningRate, momentum: (float)momentumRate, logger: new LoggerNone());
            }
            else
            {
                _Solver = new SolverGradientDescent(_Model, maxIterations: maxIterations, learningRate: (float)learningRate, logger: new LoggerNone());
            }
            return string.Format("{0}", DateTime.Now);
        }

        [ExcelFunction(Description = "Initialize the solver.", Category = "Machine Learning")]
        public static string InitializeCost(string type, string regularization, double penalty)
        {
            if (ExcelDnaUtil.IsInFunctionWizard()) return null;
            RegularizationScheme regularizationScheme;
            switch (regularization)
            {
                case "None":
                    regularizationScheme = RegularizationScheme.None;
                    break;
                case "L1Norm":
                    regularizationScheme = RegularizationScheme.L1Norm;
                    break;
                default:
                    regularizationScheme = RegularizationScheme.L2Norm;
                    break;
            }
            if (ExcelDnaUtil.IsInFunctionWizard()) return null;
            if (type == "Quadratic")
            {
                _Cost = new RegularizedCostCalculator(new CostCalculatorQuadratic(), regularizationScheme, (float)penalty);
            }
            else
            {
                _Cost = new RegularizedCostCalculator(new CostCalculatorLogistic(), regularizationScheme, (float)penalty);
            }
            return string.Format("{0}", DateTime.Now);
        }

        [ExcelFunction(Description = "Report shall be generated every {reportFrequency} iterations.", Category = "Machine Learning")]
        public static string SetReportFrequency(int reportFrequency)
        {
            if (ExcelDnaUtil.IsInFunctionWizard()) return null;
            _ReportStride = reportFrequency;
            return string.Format("{0}", DateTime.Now);
        }

        #endregion
        [ExcelFunction(Description = "Train on non encoded data.", Category = "Machine Learning")]
        public static string GetAccuracy(object[,] preds, object[,] Y)
        {
            if (ExcelDnaUtil.IsInFunctionWizard()) return null;
            var accuracy = 0F;
            accuracy = AccuracyAssessor.GetAccuracy(preds.ToStringMatrix(), Y.ToStringMatrix(), DataPreparator.YColumnTypes[0]);
            return string.Format("Accuracy: {0:P}", accuracy);
        }

        [ExcelFunction(Description = "Train on non encoded data.", Category = "Machine Learning")]
        public static string Train(object[,] data, [ExcelArgument(AllowReference = true)] object trainPredAnchor, [ExcelArgument(AllowReference = true)]object testPredAnchor, [ExcelArgument(description: "Optional column types")] object columntypes, [ExcelArgument(description: "Optional list of indexes of the output columns")] object outputColumns, [ExcelArgument(description: "Optional boolean")] object hasHeader)
        {
            if (ExcelDnaUtil.IsInFunctionWizard()) return null;

            var trainPredAnchor2 = (ExcelReference)trainPredAnchor;
            var testPredAnchor2 = (ExcelReference)testPredAnchor;

            int[] dependentColumns; bool hasHeaderB; ColumnType[] ColumnTypes;
            HandleHeader(outputColumns, hasHeader, columntypes, out ColumnTypes, out dependentColumns, out hasHeaderB);

            var subData = data.ToStringMatrix();
            MissingDataHandler.HandleTrain(subData, dependentColumns, hasHeaderB, ColumnTypes);

            var caller = XlCall.Excel(XlCall.xlfCaller);
            var callerRange = (ExcelReference)caller;
            var range = new ExcelReference(callerRange.RowFirst + 2, callerRange.ColumnFirst);

            float[,] X; float[,] Y;
            EncoderTool.Encode(subData, dependentColumns, MissingDataHandler.DataPreparator.DistinctValues, MissingDataHandler.DataPreparator.ColumnTypes,
                MissingDataHandler.DataPreparator.Means, MissingDataHandler.DataPreparator.StdDevs, MissingDataHandler.DataPreparator.Mins, MissingDataHandler.DataPreparator.Maxs,
                MinY.MinusOne,
                out X, out Y, hasHeader: hasHeaderB);
            ExcelAsyncUtil.QueueAsMacro(() =>
            {
                new ExcelReference(callerRange.RowFirst + 1, callerRange.ColumnFirst).SetValue("Running...");
                new ExcelReference(callerRange.RowFirst + 2, callerRange.RowFirst + 13, callerRange.ColumnFirst, callerRange.ColumnFirst + 200).SetValue("");
            });
            _Solver.EpochCompleted += (s, e) =>
            {
                if (_Solver.LastIteration % _ReportStride == 0)
                {
                    ExcelAsyncUtil.QueueAsMacro(() =>
                    {
                        var solver = (ISolver)s;
                        PrintSolver(solver, X, Y, range);
                        var xlApp = (Microsoft.Office.Interop.Excel.Application)ExcelDnaUtil.Application;
                        Microsoft.Office.Interop.Excel.Range cell = xlApp.Cells[trainPredAnchor2.RowFirst + 1, trainPredAnchor2.ColumnFirst + 1];
                        xlApp.ActiveSheet.Range(cell, xlApp.Cells[trainPredAnchor2.RowFirst + 2001, trainPredAnchor2.ColumnFirst + 1]).Calculate();
                        cell = xlApp.Cells[testPredAnchor2.RowFirst + 1, testPredAnchor2.ColumnFirst + 1];
                        xlApp.ActiveSheet.Range(cell, xlApp.Cells[testPredAnchor2.RowFirst + 2001, testPredAnchor2.ColumnFirst + 1]).Calculate();
                        // release Marshal app?
                    });
                }
            };
            Task.Factory.StartNew(() => _Solver.Fit(X, Y))
            .ContinueWith(t =>
                ExcelAsyncUtil.QueueAsMacro(() =>
                {
                    new ExcelReference(callerRange.RowFirst + 1, callerRange.ColumnFirst).SetValue(string.Format("Last run finished: {0}", DateTime.Now));
                    var solver = (ISolver)_Solver;
                    PrintSolver(solver, X, Y, range);
                    var xlApp = (Microsoft.Office.Interop.Excel.Application)ExcelDnaUtil.Application;
                    Microsoft.Office.Interop.Excel.Range cell = xlApp.Cells[trainPredAnchor2.RowFirst + 1, trainPredAnchor2.ColumnFirst + 1];
                    xlApp.ActiveSheet.Range(cell, xlApp.Cells[trainPredAnchor2.RowFirst + 2001, trainPredAnchor2.ColumnFirst + 1]).Calculate();
                    cell = xlApp.Cells[testPredAnchor2.RowFirst + 1, testPredAnchor2.ColumnFirst + 1];
                    xlApp.ActiveSheet.Range(cell, xlApp.Cells[testPredAnchor2.RowFirst + 2001, testPredAnchor2.ColumnFirst + 1]).Calculate();

                    xlApp.ActiveSheet.Range(cell, xlApp.Cells[trainPredAnchor2.RowFirst + 1, trainPredAnchor2.ColumnFirst + 1]).Select();
                    // release Marshal app?
                }));
            return string.Format("Last run started: {0}", DateTime.Now);
        }

        [ExcelFunction(Description = "Predict on non encoded data.", Category = "Machine Learning")]
        public static object[,] Predict(object[,] data, [ExcelArgument(description: "Optional column types")] object columntypes, [ExcelArgument(description: "Optional list of indexes of the output columns")] object outputColumns, [ExcelArgument(description: "Optional boolean")] object hasHeader)
        {
            if (ExcelDnaUtil.IsInFunctionWizard()) return null;

            int[] dependentColumns; bool hasHeaderB; ColumnType[] ColumnTypes;
            HandleHeader(outputColumns, hasHeader, columntypes, out ColumnTypes, out dependentColumns, out hasHeaderB);

            var subData = data.ToStringMatrix();
            MissingDataHandler.HandleTrain(subData, dependentColumns, hasHeaderB, ColumnTypes);

            string[] xHeader; string[] yHeader;
            BigData.Encoder.GetEncodedHeaders(dependentColumns, MissingDataHandler.DataPreparator.Header, MissingDataHandler.DataPreparator.ColumnTypes, MissingDataHandler.DataPreparator.DistinctValues, out xHeader, out yHeader);
            var nbFeatures = xHeader.Length; var nbClasses = yHeader.Length;
            if (_Model.Parameters.NbClasses != nbClasses || _Model.Parameters.NbFeatures != nbFeatures)
            {
                _Model.ResetWeights(nbFeatures, nbClasses);
                // todo: throw exception
            }

            float[,] X; float[,] Y;
            EncoderTool.Encode(subData, dependentColumns, MissingDataHandler.DataPreparator.DistinctValues, MissingDataHandler.DataPreparator.ColumnTypes,
                MissingDataHandler.DataPreparator.Means, MissingDataHandler.DataPreparator.StdDevs, MissingDataHandler.DataPreparator.Mins, MissingDataHandler.DataPreparator.Maxs,
                MinY.MinusOne,
                out X, out Y, hasHeader: hasHeaderB);
            var preds = _Model.Predict(X);
            var decodedPreds = EncoderTool.DecodeY(preds, MissingDataHandler.DataPreparator.YDistinctValues, MissingDataHandler.DataPreparator.YColumnTypes, MissingDataHandler.DataPreparator.YMeans, MissingDataHandler.DataPreparator.YStdDevs, MissingDataHandler.DataPreparator.YMins, MissingDataHandler.DataPreparator.YMaxs, MinY.MinusOne);
            var res = decodedPreds.ToObject();
            return res;
        }

        #region Encoding

        [ExcelFunction(Description = "Get the type (numerical or categorical) for each column, their average, standard deviation, min and max.", Category = "Machine Learning")]
        public static object[,] PrepareData(object[,] data, [ExcelArgument(description: "Optional column types")] object columntypes, [ExcelArgument(description: "Optional list of indexes of the output columns")] object outputColumns, [ExcelArgument(description: "Optional boolean")] object hasHeader)
        {
            if (ExcelDnaUtil.IsInFunctionWizard()) return null;

            int[] dependentColumns; bool hasHeaderB; ColumnType[] ColumnTypes;
            HandleHeader(outputColumns, hasHeader, columntypes, out ColumnTypes, out dependentColumns, out hasHeaderB);

            var n = data.GetLength(1); var m = data.GetLength(0);
            var subData = data.ToStringMatrix();
            DataPreparator.Prepare(subData, dependentColumns, hasHeaderB, ColumnTypes);
            var res = new string[6, n + 1];
            res[0, 0] = "Header:";
            res[1, 0] = "Column Type:";
            res[2, 0] = "Mean:";
            res[3, 0] = "StdDev:";
            res[4, 0] = "Min:";
            res[5, 0] = "Max";
            for (var j = 0; j < n; j++)
            {
                res[0, j + 1] = subData[0, j];
                res[1, j + 1] = DataPreparator.ColumnTypes[j].ToString();
                if (DataPreparator.ColumnTypes[j] != ColumnType.Categorical)
                {
                    res[2, j + 1] = DataPreparator.Means[j].ToString();
                    res[3, j + 1] = DataPreparator.StdDevs[j].ToString();
                    res[4, j + 1] = DataPreparator.Mins[j].ToString();
                    res[5, j + 1] = DataPreparator.Maxs[j].ToString();
                }
                else
                {
                    res[2, j + 1] = "";
                    res[3, j + 1] = "";
                    res[4, j + 1] = "";
                    res[5, j + 1] = "";
                }
            }
            return res;
        }

        [ExcelFunction(Description = "Replace missing categrorical data with 'NA' and numerical ones with the avergae of non missing data for the column.", Category = "Useful functions")]
        public static object[,] HandleMissingData(object[,] data, [ExcelArgument(description: "Optional column types")] object columntypes, [ExcelArgument(description: "Optional list of indexes of the output columns")] object outputColumns, [ExcelArgument(description: "Optional boolean")] object hasHeader)
        {
            if (ExcelDnaUtil.IsInFunctionWizard()) return null;

            int[] dependentColumns; bool hasHeaderB; ColumnType[] ColumnTypes;
            HandleHeader(outputColumns, hasHeader, columntypes, out ColumnTypes, out dependentColumns, out hasHeaderB);

            var n = data.GetLength(1); var m = data.GetLength(0);
            var subData = data.ToStringMatrix();
            MissingDataHandler.HandleTrain(subData, dependentColumns, hasHeaderB, ColumnTypes);
            return subData;
        }

        [ExcelFunction(Description = "Normalize numerical columns, projects categorical columns with n distinct values onto n binary columns (ex 0,0,1 for the first value, 0,1,0 for the second etc.)", Category = "Machine Learning")]
        public static object[,] Encode(object[,] data, [ExcelArgument(description: "Optional column types")] object columntypes, [ExcelArgument(description: "Optional list of indexes of the output columns")] object outputColumns, [ExcelArgument(description: "Optional boolean")] object hasHeader)
        {
            if (ExcelDnaUtil.IsInFunctionWizard()) return null;

            int[] dependentColumns; bool hasHeaderB; ColumnType[] ColumnTypes;
            HandleHeader(outputColumns, hasHeader, columntypes, out ColumnTypes, out dependentColumns, out hasHeaderB);

            var headerOffset = hasHeaderB ? 1 : 0;
            var n = data.GetLength(1); var m = data.GetLength(0);

            var subData = data.ToStringMatrix();
            MissingDataHandler.HandleTrain(subData, dependentColumns, hasHeaderB, ColumnTypes);
            float[,] X; float[,] Y;
            EncoderTool.Encode(subData, dependentColumns, MissingDataHandler.DataPreparator.DistinctValues, MissingDataHandler.DataPreparator.ColumnTypes,
                MissingDataHandler.DataPreparator.Means, MissingDataHandler.DataPreparator.StdDevs, MissingDataHandler.DataPreparator.Mins, MissingDataHandler.DataPreparator.Maxs,
                MinY.MinusOne,
                out X, out Y, hasHeader: hasHeaderB);
            var res = new object[m + (1 - headerOffset), X.GetLength(1) + Y.GetLength(1)];
            string[] xHeader; string[] yHeader;
            BigData.Encoder.GetEncodedHeaders(dependentColumns, MissingDataHandler.DataPreparator.Header, MissingDataHandler.DataPreparator.ColumnTypes, MissingDataHandler.DataPreparator.DistinctValues, out xHeader, out yHeader);
            for (var j = 0; j < Y.GetLength(1); j++)
            {
                res[0, j] = yHeader[j];
            }
            for (var j = 0; j < X.GetLength(1); j++)
            {
                res[0, Y.GetLength(1) + j] = xHeader[j];
            }
            for (var i = 1; i < res.GetLength(0); i++)
            {
                for (var j = 0; j < Y.GetLength(1); j++)
                {
                    res[i, j] = Y[i - 1, j];
                }
            }
            for (var i = 1; i < res.GetLength(0); i++)
            {
                for (var j = 0; j < X.GetLength(1); j++)
                {
                    res[i, Y.GetLength(1) + j] = X[i - 1, j];
                }
            }
            return res;
        }

        #endregion

        #region Tests

        [ExcelCommand(Description = "Test.", MenuName = "Machine Learning", MenuText = "Color")]
        public static void Color(string reportAnchor, object[,] data, object[] outputColumns, bool hasHeader)
        {
            Task.Factory.StartNew(() => Thread.Sleep(5000))
            .ContinueWith(t =>
                ExcelAsyncUtil.QueueAsMacro(() =>
                {
                    var xlApp = (Microsoft.Office.Interop.Excel.Application)ExcelDnaUtil.Application;
                    Microsoft.Office.Interop.Excel.Range cell = xlApp.Cells[1, 1];
                    cell.Interior.ColorIndex = 3;
                }));
        }

        #endregion


        #region Internal Tools

        private static void HandleHeader(object outputColumns, object hasHeader, object columnTypes, out ColumnType[] ColumnTypes, out int[] dependentColumns, out bool hasHeaderB)
        {
            dependentColumns = null;
            if (!(outputColumns is ExcelMissing))
            {
                if (outputColumns is Array)
                {
                    var outputs = outputColumns as object[,];
                    dependentColumns = new int[outputs.GetLength(1)];
                    for (var j = 0; j < outputs.Length; j++)
                    {
                        dependentColumns[j] = Convert.ToInt32(outputs[0, j]);
                    }
                }
                else
                {
                    dependentColumns = new int[1] { Convert.ToInt32(outputColumns) };
                }
            }
            hasHeaderB = true;
            if (!(hasHeader is ExcelMissing))
            {
                hasHeaderB = Convert.ToBoolean(hasHeader);
            }
            ColumnTypes = null;
            if (!(columnTypes is ExcelMissing))
            {
                if (columnTypes is Array)
                {
                    var objects = columnTypes as object[,];
                    ColumnTypes = new ColumnType[objects.GetLength(1)];
                    for (var j = 0; j < objects.Length; j++)
                    {
                        ColumnTypes[j] = ColumnType.Numeric;
                        if (objects[0, j].ToString() == "Categorical")
                        {
                            ColumnTypes[j] = ColumnType.Categorical;
                        }
                        if (objects[0, j].ToString() == "Ignore")
                        {
                            ColumnTypes[j] = ColumnType.Ignore;
                        }
                        if (objects[0, j].ToString() == "Binary")
                        {
                            ColumnTypes[j] = ColumnType.Binary;
                        }
                    }
                }
                else
                {
                    ColumnTypes = new ColumnType[1];
                    ColumnTypes[0] = ColumnType.Numeric;
                    if (columnTypes.ToString() == "Categorical")
                    {
                        ColumnTypes[0] = ColumnType.Categorical;
                    }
                }
            }

        }

        protected static object[,] SerializeModel()
        {
            var v = new object[6, _Model.Weights.Length + 1];
            v[0, 0] = "MODEL";
            v[1, 0] = "Layers:";
            for (var j = 0; j < _Model.ModelParameters.HiddenLayerSizes.Length; j++)
            {
                v[1, 1 + j] = _Model.ModelParameters.HiddenLayerSizes[j];
            }
            v[2, 0] = "Transfer Function:"; v[2, 1] = _Model.Activator.GetType().ToString().Replace("BigData.Activator", string.Empty);
            v[3, 0] = "Nb Features:"; v[3, 1] = _Model.Parameters.NbFeatures;
            v[4, 0] = "Nb Outputs:"; v[4, 1] = _Model.Parameters.NbClasses;
            v[5, 0] = "Weights:";
            for (var j = 0; j < _Model.Weights.Length; j++)
            {
                v[5, j + 1] = _Model.Weights[j];
            }
            return v;
        }

        protected static void PrintSolver(ISolver s, float[,] X, float[,] Y, ExcelReference range)
        {
            var predictions = s.Model.Predict(X);
            var cost = s.Model.CostCalculator.Cost(predictions, Y,_Solver.Model.Weights);
            var decodedPreds = EncoderTool.DecodeY(predictions, DataPreparator.YDistinctValues, DataPreparator.YColumnTypes, DataPreparator.YMeans, DataPreparator.YStdDevs, DataPreparator.YMins, DataPreparator.YMaxs, MinY.MinusOne);
            var decodedY = EncoderTool.DecodeY(Y, DataPreparator.YDistinctValues, DataPreparator.YColumnTypes, DataPreparator.YMeans, DataPreparator.YStdDevs, DataPreparator.YMins, DataPreparator.YMaxs, MinY.MinusOne);
            var accuracy = AccuracyAssessor.GetAccuracy(decodedPreds, decodedY, DataPreparator.YColumnTypes[0]);
            var epoch = s.LastIteration;
            var model = SerializeModel();
            var res = new object[6 + model.GetLength(0)/*+2+decodedPreds.GetLength(0)*/, Math.Max(model.GetLength(1), decodedPreds.GetLength(0))];
            res[1, 0] = "RESULTS";
            res[2, 0] = "Last Iteration:"; res[3, 0] = "Cost:"; res[4, 0] = "Accuracy";
            res[2, 1] = epoch; res[3, 1] = cost; res[4, 1] = string.Format("{0:P}", accuracy);
            res[5, 0] = "";
            for (var i = 0; i < model.GetLength(0); i++)
            {
                for (var j = 0; j < model.GetLength(1); j++)
                {

                    res[6 + i, j] = model[i, j];
                }
            }
            //res[5+model.GetLength(0)+1, 0] = "";
            //res[5 + model.GetLength(0) + 2, 0] = "Target";
            //res[5 + model.GetLength(0) + 2, decodedPreds.GetLength(1) ] = "Predictions";
            //for (var i = 0; i < decodedPreds.GetLength(0); i++)
            //{
            //    for (var j=0;j< decodedPreds.GetLength(1);j++)
            //    {
            //        res[5 + model.GetLength(0) + 3 + i,  j] = decodedY[i, j];
            //        res[5 + model.GetLength(0) + 3+i, decodedPreds.GetLength(1)+j] = decodedPreds[i, j];
            //    }
            //}          
            Print(res, range);
        }

        public static void Print(object[,] v, ExcelReference range)
        {
            for (var i = 0; i < v.GetLength(0); i++)
            {
                for (var j = 0; j < v.GetLength(1); j++)
                {
                    var res = new ExcelReference(range.RowFirst + i, range.ColumnFirst + j);
                    res.SetValue(v[i, j]);
                }
            }
        }

        #endregion

    }


    public static class Dummy
    {
        public static string[,] ToStringMatrix(this object[,] v)
        {
            var m = v.GetLength(0); var n = v.GetLength(1);
            var res = new string[m, n];
            for (var i = 0; i < m; i++)
            {
                for (var j = 0; j < n; j++)
                {
                    var val = v[i, j];
                    if (val == ExcelDna.Integration.ExcelEmpty.Value)
                    {
                        val = string.Empty;
                    }
                    res[i, j] = val.ToString();
                }
            }
            return res;
        }

        public static object[,] ToObject(this string[,] v)
        {
            var m = v.GetLength(0); var n = v.GetLength(1);
            var res = new string[m, n];
            for (var i = 0; i < m; i++)
            {
                for (var j = 0; j < n; j++)
                {
                    var val = v[i, j];
                    res[i, j] = val;
                }
            }
            return res;
        }

        public static float[,] ToFloat(this object[,] v)
        {
            var m = v.GetLength(0); var n = v.GetLength(1);
            var res = new float[m, n];
            for (var i = 0; i < m; i++)
            {
                for (var j = 0; j < n; j++)
                {
                    res[i, j] = Convert.ToSingle(v[i, j]);
                }
            }
            return res;
        }

        public static object[,] ToObject(this float[,] v)
        {
            var m = v.GetLength(0); var n = v.GetLength(1);
            var res = new object[m, n];
            for (var i = 0; i < m; i++)
            {
                for (var j = 0; j < n; j++)
                {
                    res[i, j] = (v[i, j]);
                }
            }
            return res;
        }
    }

}

