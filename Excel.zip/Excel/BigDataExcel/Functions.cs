﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcelDna.Integration;
using BigData;
using BigDataExcel;

namespace BigDataExcel
{

    public static class Dummy
    {
        public static string[,] ToStringMatrix(this object[,] v)
        {
            var m = v.GetLength(0); var n = v.GetLength(1);
            var res = new string[m, n];
            for (var i = 0; i < m; i++)
            {
                for (var j = 0; j < n; j++)
                {
                    var val = v[i, j];
                    if (val == ExcelDna.Integration.ExcelEmpty.Value)
                    {
                        val = string.Empty;
                    }
                    res[i, j] = val.ToString();
                }
            }
            return res;
        }
        public static object[,] ToObject(this string[,] v)
        {
            var m = v.GetLength(0); var n = v.GetLength(1);
            var res = new string[m, n];
            for (var i = 0; i < m; i++)
            {
                for (var j = 0; j < n; j++)
                {
                    var val = v[i, j];                    
                    res[i, j] = val;
                }
            }
            return res;
        }

        public static float[,] ToFloat(this object[,] v)
        {
            var m = v.GetLength(0); var n = v.GetLength(1);
            var res = new float[m, n];
            for (var i = 0; i < m; i++)
            {
                for (var j = 0; j < n; j++)
                {
                    res[i, j] = Convert.ToSingle(v[i, j]);
                }
            }
            return res;
        }

        public static object[,] ToObject(this float[,] v)
        {
            var m = v.GetLength(0); var n = v.GetLength(1);
            var res = new object[m, n];
            for (var i = 0; i < m; i++)
            {
                for (var j = 0; j < n; j++)
                {
                    res[i, j] = (v[i, j]);
                }
            }
            return res;
        }
    }

    public class Functions
    {

        protected static ModelNeuralNetwork _Model;
        protected static ISolver _Solver;
        protected static MissingDataHandler _MissingDataHandler;
        protected static DataPreparator _DataPreparator;

        [ExcelFunction(Description = "Initialize the network. Transfer function: Thanh or Sigmoid.", Category = "Machine Learning")]
        public static void InitializeNetwork(object[] hiddenLayers,string transferFunction)
        {
            var n = hiddenLayers.Length;
            var hiddenLayerSizes = new int[n];
            for (var j=0;j<n;j++)
            {
                hiddenLayerSizes[j] = Convert.ToInt32(hiddenLayers[j]);
            }
            IActivator activator = new ActivatorTanh();
            if (transferFunction=="Sigmoid") activator = new ActivatorSigmoid();
            _Model = new ModelNeuralNetwork(1, 1, hiddenLayerSizes, null, activator);
        }

        [ExcelFunction(Description = "Initialize the solver.", Category = "Machine Learning")]
        public static void InitializeSolver(int maxIterations,float learningRate,float momentumRate)
        {
            _Solver = new SolverMomentum(_Model, maxIterations: maxIterations, learningRate: learningRate, momentum: momentumRate);
        }

        [ExcelFunction(Description = "Predict on non encoded data.", Category = "Machine Learning")]
        public static object[,] Predict(object[,] data,object[] outputColumns,bool hasHeader)
        {
           
          
            var d = new DataPreparator(null);
            var miss = new MissingDataAverageAndNA(d, null, null);
            var encoder = new BigData.EncoderTool();
            var dependentColumns = new int[outputColumns.Length];
            for (var j = 0; j < outputColumns.Length; j++)
            {
                dependentColumns[j] = Convert.ToInt32(outputColumns[j]);
            }
            var subData = data.ToStringMatrix();
            miss.HandleTrain(subData, dependentColumns, hasHeader);

            string[] xHeader; string[] yHeader;
            BigData.Encoder.GetEncodedHeaders(dependentColumns, miss.DataPreparator.Header, miss.DataPreparator.ColumnTypes, miss.DataPreparator.DistinctValues, out xHeader, out yHeader);
            var nbFeatures = xHeader.Length;var nbClasses = yHeader.Length;
            if (_Model.Parameters.NbClasses != nbClasses || _Model.Parameters.NbFeatures != nbFeatures)
            {
                _Model.ResetWeights(nbFeatures, nbClasses);
                // todo: throw exception
            }
           
            float[,] X; float[,] Y;
            EncoderTool.Encode(subData, dependentColumns, miss.DataPreparator.DistinctValues, miss.DataPreparator.ColumnTypes,
                miss.DataPreparator.Means, miss.DataPreparator.StdDevs, miss.DataPreparator.Mins, miss.DataPreparator.Maxs,
                MinY.MinusOne,
                out X, out Y, hasHeader: hasHeader);
            var preds=_Model.Predict(X);
            var decodedPreds = EncoderTool.DecodeY(preds, miss.DataPreparator.YDistinctValues, miss.DataPreparator.YColumnTypes, miss.DataPreparator.YMeans, miss.DataPreparator.YStdDevs, miss.DataPreparator.YMins, miss.DataPreparator.YMaxs,MinY.MinusOne);
            var res = decodedPreds.ToObject();
            return res;
        }

        [ExcelFunction(Description = "Get the type (numerical or categorical) for each column, their average, standard deviation, min and max.", Category = "Machine Learning")]
        public static object[,] PrepareData( object[,] data, object[] outputColumns,object hasHeader)
        {
            var hasHeaderb = Convert.ToBoolean(hasHeader);
            var n = data.GetLength(1);var m = data.GetLength(0);
            var d = new DataPreparator(null);
            var dependentColumns = new int[outputColumns.Length];
            var subData =data.ToStringMatrix();
            for (var j = 0; j < outputColumns.Length; j++)
            {
                dependentColumns[j] = Convert.ToInt32(outputColumns[j]);
            }            
            d.Prepare(subData, dependentColumns,hasHeaderb);
            var res = new string[6, n+1];
            res[0, 0] = "Header:";
            res[1, 0] = "Column Type:";
            res[2, 0] = "Mean:";
            res[3, 0] = "StdDev:";
            res[4, 0] = "Min:";
            res[5, 0] = "Max";
            for (var j = 0; j < n; j++)
            {
                res[0, j+1] = subData[0, j];
                res[1, j+1] = d.ColumnTypes[j].ToString();
                if (d.ColumnTypes[j] != ColumnType.Categorical)
                {
                    res[2, j + 1] = d.Means[j].ToString();
                    res[3, j + 1] = d.StdDevs[j].ToString();
                    res[4, j + 1] = d.Mins[j].ToString();
                    res[5, j + 1] = d.Maxs[j].ToString();
                }
                else
                {
                    res[2, j + 1] = "";
                    res[3, j + 1] = "";
                    res[4, j + 1] = "";
                    res[5, j + 1] = "";
                }
            }
            return res;
        }

        [ExcelFunction(Description = "Replace missing categrorical data with 'NA' and numerical ones with the avergae of non missing data for the column.", Category = "Useful functions")]
        public static object[,] HandleMissingData(object[,] data, object[] outputColumns, object hasHeader)
        {
            var hasHeaderb = Convert.ToBoolean(hasHeader);
            var n = data.GetLength(1); var m = data.GetLength(0);
            var d = new DataPreparator(null);
            var miss = new MissingDataAverageAndNA(d,null,null);
            var dependentColumns = new int[outputColumns.Length];
            var subData = data.ToStringMatrix();
            for (var j = 0; j < outputColumns.Length; j++)
            {
                dependentColumns[j] = Convert.ToInt32(outputColumns[j]);
            }           
            miss.HandleTrain(subData, dependentColumns, hasHeaderb);
            return subData;
        }

        [ExcelFunction(Description = "Normalize numerical columns, projects categorical columns with n distinct values onto n binary columns (ex 0,0,1 for the first value, 0,1,0 for the second etc.)", Category = "Machine Learning")]
        public static object[,] Encode(object[,] data, object[] outputColumns, object hasHeader)
        {
            var hasHeaderb = Convert.ToBoolean(hasHeader);
            var headerOffset = hasHeaderb ? 1 : 0;
            var n = data.GetLength(1); var m = data.GetLength(0);
            var d = new DataPreparator(null);
            var miss = new MissingDataAverageAndNA(d, null, null);
            var encoder = new BigData.EncoderTool();
            var dependentColumns = new int[outputColumns.Length];            
            for (var j = 0; j < outputColumns.Length; j++)
            {
                dependentColumns[j] = Convert.ToInt32(outputColumns[j]);
            }
            var subData = data.ToStringMatrix();
            miss.HandleTrain(subData, dependentColumns, hasHeaderb);
            float[,] X;float[,] Y;
            EncoderTool.Encode(subData, dependentColumns, miss.DataPreparator.DistinctValues, miss.DataPreparator.ColumnTypes, 
                miss.DataPreparator.Means, miss.DataPreparator.StdDevs, miss.DataPreparator.Mins, miss.DataPreparator.Maxs,
                MinY.MinusOne,
                out X,out Y, hasHeader: hasHeaderb);
            var res = new object[m+(1-headerOffset), X.GetLength(1)+ Y.GetLength(1)];
            string[] xHeader;string[] yHeader;
            BigData.Encoder.GetEncodedHeaders(dependentColumns, miss.DataPreparator.Header,miss.DataPreparator.ColumnTypes, miss.DataPreparator.DistinctValues, out xHeader, out yHeader);
            for (var j = 0; j < Y.GetLength(1); j++)
            {
                res[0, j] = yHeader[j];
            }
            for (var j = 0; j < X.GetLength(1); j++)
            {
                res[0, Y.GetLength(1)+j] =xHeader[j];
            }
            for (var i=1;i<res.GetLength(0);i++)
            {
                for (var j=0;j<Y.GetLength(1);j++)
                {
                    res[i, j] = Y[i - 1, j];
                }
            }
            for (var i =1; i < res.GetLength(0); i++)
            {
                for (var j = 0; j <X.GetLength(1); j++)
                {
                    res[i, Y.GetLength(1)+j] = X[i - 1, j];
                }
            }
            return res;
        }



    }
}
