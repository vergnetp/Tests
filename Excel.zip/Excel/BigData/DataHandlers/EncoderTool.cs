﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace BigData
{
    
    public class EncoderTool 
    {

        public static string[,] DecodeY(float[,] data, List<string>[] YDistinctValues, ColumnType[] YColTypes, float[] _YMeans, float[] _YStdDevs, float[] _YMins, float[] _YMaxs, MinY minY)
        {
            var yExtraCols = NumNewCols(YDistinctValues, YColTypes);
            var result = new string[data.GetLength(0), data.GetLength(1) - yExtraCols];
            for (int row = 0; row < data.GetLength(0); ++row)
            {
                int k = 0;
                for (int col = 0; col < data.GetLength(1) - yExtraCols; ++col)
                {
                    float val = data[row, k];
                    switch (YColTypes[col])
                    {
                        case ColumnType.Binary:
                            result[row, col] = BinaryDepenFromValue(val, col, YDistinctValues, minY);
                            k++;
                            break;
                        case ColumnType.Categorical:
                            var values = new float[YDistinctValues[col].Count];
                            for (var i = 0; i < YDistinctValues[col].Count; i++)
                            {
                                values[i] = data[row, k + i];
                            }
                            string vals = CatDepenFromValues(values, col, YDistinctValues, minY);
                            k += YDistinctValues[col].Count;
                            result[row, col] = vals;
                            break;
                        default:
                            result[row, col] = NumDepenFromValue(val, col, _YMaxs, _YMins, minY);
                            k++;
                            break;
                    }
                }
            }
            return result;
        }
    
        public static string[,] DecodeX(float[,] data, List<string>[] XDistinctValues, ColumnType[] XColTypes, float[] _XMeans, float[] _XStdDevs,MinY minY)
        {
            var xExtraCols = NumNewCols(XDistinctValues, XColTypes);
            var result = new string[data.GetLength(0), data.GetLength(1) - xExtraCols];
            for (int row = 0; row < data.GetLength(0); ++row)
            {
                int k = 0;
                for (int col = 0; col < data.GetLength(1) - xExtraCols; ++col)
                {
                    float val = data[row, k];
                    switch (XColTypes[col])
                    {
                        case ColumnType.Id:
                            break;
                        case ColumnType.Ignore:
                            break;
                        case ColumnType.Binary:
                            result[row, col] = BinaryIndepenFromValue(val, col, XDistinctValues);
                            k++;
                            break;
                        case ColumnType.Categorical:
                            var values = new float[XDistinctValues[col].Count];
                            for (var i = 0; i < XDistinctValues[col].Count; i++)
                            {
                                values[i] = data[row, k + i];
                            }
                            string vals = CatIndepenFromValues(values, col, XDistinctValues,minY);
                            result[row, col] = vals;
                            k += XDistinctValues[col].Count;
                            break;
                        default:
                            result[row, col] = NumIndepenFromValue(val, col, _XMeans, _XStdDevs);
                            k++;
                            break;
                    }
                }
            }
            return result;
        }
     
        public static void Encode(string[,] rawData, int[] outputColumns,
            List<string>[] distinctValues, ColumnType[] colTypes,
            float[] means, float[] stdDevs, float[] mins, float[] maxs, MinY minY,
            out float[,] X, out float[,] Y,
            bool hasHeader
            )
        {
            var headerOffset = hasHeader ? 1 : 0;
            if (outputColumns == null) outputColumns = new int[0];
            var inputExtraCols = 0;
            var outputExtraCols = 0;
            var inputNbColToIgnore = 0;
            var outputNbColToIgnore = 0;
            for (int col = 0; col < rawData.GetLength(1); ++col)
            {
                if (outputColumns.Contains(col) && (colTypes[col] == ColumnType.Ignore || colTypes[col] == ColumnType.Id)) outputNbColToIgnore++;
                if (!outputColumns.Contains(col) && (colTypes[col] == ColumnType.Ignore || colTypes[col] == ColumnType.Id)) inputNbColToIgnore++;
                if (outputColumns.Contains(col) && (colTypes[col] == ColumnType.Categorical)) outputExtraCols += distinctValues[col].Count-1;
                if (!outputColumns.Contains(col) && (colTypes[col] == ColumnType.Categorical))
                {
                    inputExtraCols += distinctValues[col].Count - 1;
                }

            }
            var x = new float[rawData.GetLength(0)-headerOffset, rawData.GetLength(1) + inputExtraCols - inputNbColToIgnore - outputColumns.Length];
            var y = new float[rawData.GetLength(0) - headerOffset, outputColumns.Length + outputExtraCols - outputNbColToIgnore];
            for (var row =0; row < rawData.GetLength(0) - headerOffset; row++)
            //Parallel.For(0, rawData.GetLength(0) - headerOffset, row =>
            {
                int xk = 0; int yk = 0;
                for (int col = 0; col < rawData.GetLength(1); ++col)
                {
                    string val = rawData[row+headerOffset, col];
                    switch (colTypes[col])
                    {
                        case ColumnType.Id:
                            break;
                        case ColumnType.Ignore:
                            break;
                        case ColumnType.Binary:
                            if (outputColumns.Contains(col))
                            {
                                y[row, yk++] = BinaryIndepenToValue(val, col, distinctValues);
                            }
                            else
                            {
                                x[row, xk++] = BinaryDepenToValue(val, col, distinctValues);
                            }
                            break;
                        case ColumnType.Categorical:
                            if (!distinctValues[col].Contains(val)) { val = "NA"; /*add unseen val for col in cache to log*/ }
                            if (outputColumns.Contains(col))
                            {
                                var vals = CatDepenToValues(val, col, distinctValues,minY);
                                for (int j = 0; j < vals.Length; ++j)
                                    y[row, yk++] = vals[j];
                            }
                            else
                            {
                                var vals = CatIndepenToValues(val, col, distinctValues,minY);
                                for (int j = 0; j < vals.Length; ++j)
                                    x[row, xk++] = vals[j] ;// / vals.Length;// lower the values to avoid overfitting
                            }
                            break;
                        default:
                            // hack to deal with columns that were wrongly evaluated as numeric on the training set, but turn out to have string in the test/validation set:
                            if (!DataPreparator.IsNumeric(val))
                            {
                                val = means[col].ToString();
                            }
                            if (outputColumns.Contains(col))
                            {
                                y[row, yk++] = NumDepenToValue(val, col, mins, maxs, minY);
                            }
                            else
                            {
                                x[row, xk++] = NumIndepenToValue(val, col, means, stdDevs);
                            }
                            break;
                    }
                }
            }//);
            X = x;
            Y = y;
        }

     
        #region Values Encoding Functions

        static float BinaryIndepenToValue(string val, int col, List<string>[] distinctValues) // binary x value -> -1 or +1
        {
            //if (distinctValues[col].Length != 2)
            //    throw new Exception("Binary x data only 2 values allowed");
            if (distinctValues[col][0] == val)
                return -1.0F;
            else
                return +1.0F;
        }
        static string BinaryIndepenFromValue(float val, int col, List<string>[] distinctValues) // binary x value -> -1 or +1
        {
            if (distinctValues[col].Count != 2)
                throw new Exception("Binary x data only 2 values allowed");
            if (val == -1.0F)
                return distinctValues[col][0];
            else
                return distinctValues[col][1];
        }

        static float BinaryDepenToValue(string val, int col, List<string>[] distinctValues, MinY minY = MinY.Zero) // binary y value -> 0 or 1
        {
            if (distinctValues[col].Count > 2)
                throw new Exception("Binary y data only 2 values allowed");
            if (distinctValues[col][0] == val)
                return (float)minY;
            else
                return 1.0F;
        }
        static string BinaryDepenFromValue(float val, int col, List<string>[] distinctValues, MinY minY = MinY.Zero) // binary y value -> 0 or 1
        {
            if (distinctValues[col].Count > 2)
                throw new Exception("Binary y data only 2 values allowed");
            if (val < (1.0F + (float)minY) / 2.0F)
                return distinctValues[col][0];
            else
                return distinctValues[col][1];
        }




        static float[] CatIndepenToValues(string val, int col, List<string>[] distinctValues, MinY minY) // categorical x value -> 1-of-(C-1) effects encoding
        {
            //if (distinctValues[col].Length == 2) throw new Exception("Categorical x data only 1, 3+ values allowed");
            int size = distinctValues[col].Count;
            float[] result = new float[size];

            var adjuster = 1;// size;

            int idx = 0;
            for (int i = 0; i < size; ++i)
            {
                if (distinctValues[col][i] == val)
                {
                    idx = i; break;
                }
            }
            for (int i = 0; i < size; ++i) // ex: [-1.0, -1.0, -1.0]
            {
                result[i] = (float)minY / adjuster;
            }
            if (idx != size - 1) // value is not last, use dummy 
            {                        
                result[result.Length - 1 - idx] = +1.0F / adjuster; // ex: [-1.0, 1.0, -1.0]
            }
            return result;
        }
        static string CatIndepenFromValues(float[] val, int col, List<string>[] distinctValues, MinY minY) // categorical x value -> 1-of-(C-1) effects encoding
        {                  
            int size = distinctValues[col].Count;

            var adjuster = 1;// size;

            if (val[0] == (float)minY / adjuster) return distinctValues[col][size - 1];

            int idx = 0;
            for (int i = 0; i < size; ++i)
            {
                if (val[i] > (1.0F/size + (float)minY/ adjuster) / 2.0F)
                {
                    idx = i; break;
                }
            }
            return distinctValues[col][size - 1 - idx];
        }




        static float[] CatDepenToValues(string val, int col, List<string>[] distinctValues, MinY minY ) // categorical y value -> 1-of-C dummy encoding
        {            
            int size = distinctValues[col].Count;
            float[] result = new float[size];
            for (var i = 0; i < result.Length; i++)
            {
                result[i] = (float)minY;
            }
            int idx = 0;
            for (int i = 0; i < size; ++i)
            {
                if (distinctValues[col][i] == val)
                {
                    idx = i; break;
                }
            }
            result[result.Length - 1 - idx] = 1.0F ; // ex: [-1.0, 1.0, -1.0]
            return result;
        }
        static string CatDepenFromValues(float[] val, int col, List<string>[] distinctValues, MinY minY = MinY.Zero) // categorical y value -> 1-of-C dummy encoding
        {           
            int size = distinctValues[col].Count;

            int idx = 0;
            for (int i = 0; i < size; ++i)
            {
                if (val[i] > (1.0F  + (float)minY ) / 2.0F)
                {
                    idx = i; break;
                }
            }
            return distinctValues[col][size - 1 - idx];
        }




        static float NumIndepenToValue(string val, int col, float[] means, float[] stdDevs) // numeric x value -> (x - m) / s
        {
            float x = float.Parse(val);
            float m = means[col];
            float sd = stdDevs[col];
            if (sd == 0) sd = 1F;
            return (x - m) / sd;
        }
        static string NumIndepenFromValue(float val, int col, float[] means, float[] stdDevs) // numeric x value -> (x - m) / s
        {
            float m = means[col];
            float sd = stdDevs[col];
            return (val * sd + m).ToString();
        }

        //(x-min)/(max-min)	 for [0;1] or (2x-(max+min))/(max-min) for [-1;1]
        static float NumDepenToValue(string val, int col, float[] mins, float[] maxs, MinY minY)
        {
            float x = float.Parse(val);
            float min = mins[col];
            float max = maxs[col];
            if (minY == MinY.Zero)
            {
                return (x - min) / (max - min);
            }
            else
            {
                return (2.0F * x - max - min) / (max - min);
            }
        }
        static string NumDepenFromValue(float val, int col, float[] maxs, float[] mins, MinY minY)
        {
            float min = mins[col];
            float max = maxs[col];
            if (minY == MinY.Zero)
            {
                return (val * (max - min) + min).ToString();
            }
            else
            {
                return ((val * (max - min) + max + min) / 2.0F).ToString();
            }
        }

        static int NumNewCols(List<string>[] distinctValues, ColumnType[] colTypes)
        {
            // number of additional columns needed due to categorical encoding
            int result = 0;
            for (int i = 0; i < colTypes.Length; ++i)
            {
                if (colTypes[i] == ColumnType.Categorical)
                {
                    int numCatValues = distinctValues[i].Count;
                    result += numCatValues - 1;
                }
            }
            return result;
        }

        #endregion
        
        public static void Test()
        {
            var rawData = new string[,] { 
        {"male","60000.00","suburban","54","republican"}, 
        {"female","24000.00","city","28","democrat"},
        {"male","30000.00","rural","31","libertarian"},
        {"female","30000.00","suburban","48","republican"},
        {"female","18000.00","city","22","democrat"},
        {"male","56000.00","rural","39","other"}};

            var testData = new string[,] { 
        {"male","59000.00","suburban","54","republican"}, 
        {"female","24000.00","rural","28","democrat"},
        {"male","32000.00","rural","31","libertarian"}};

            Console.WriteLine("\nBegin transform");
            //var encoder = new DataNormalizer(MinY.Zero);
            //var codedData = encoder.EncodeYTrain(rawData);
            //var check = encoder.DecodeY(codedData);
            Console.WriteLine("\nTransform complete");
        }
               
    }
}
