﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigData
{
    public class MissingDataAverageAndNA : MissingDataHandler
    {
        public MissingDataAverageAndNA(DataPreparator dataPreparator, ILogger logger, IRepository repo) { DataPreparator = dataPreparator; _Logger = logger; _Repo = repo; }

        public override void HandleMissingTest(string outputName, string testName, int[] dependentColumns)
        {
            if (DataPreparator.XMeans == null) throw new Exception("Statistics like means need to be populated before Handling missing data in the training set.");
            HandleMissingTrain(outputName, testName, dependentColumns);
        }

        public override void HandleMissingTest(string[,] subData, int[] dependentColumns)
        {
            if (DataPreparator.XMeans == null) throw new Exception("Statistics like means need to be populated before Handling missing data in the training set.");
            HandleMissingTrain(subData, dependentColumns);
        }

        public override void HandleMissingTrain(string[,] subData, int[] dependentColumns)
        {
            Deal(subData, dependentColumns);
        }

        public override void HandleMissingTrain(string outputName, string trainingName, int[] dependentColumns)
        {
            if (DataPreparator.ColumnTypes == null) throw new Exception("Columptypes need to be populated before Handling missing data in training set.");
            var offset = 0L; var size = long.MaxValue;
            _Repo.Clear(outputName);           
            var lastRow = offset + size;
            var firstRow = _Repo.Header(trainingName);
            _Repo.Export(outputName, firstRow);
            var n = (long)firstRow.Length;
            var maxSize = 1000 * 1000 / n;// 1000 * 1000 / n; // We allow a 64MB array max
            var subSize = Math.Min(size, maxSize);
            var subData = _Repo.Import(trainingName, offset, subSize);          
            do
            {
                Deal(subData, dependentColumns);
                _Repo.InsertData(outputName, subData, false);
                offset += subSize;
                subSize = Math.Min(subSize, lastRow - offset);
                subData = _Repo.Import(trainingName, offset, subSize);
            } while (subData != null); 
        }

        protected void Deal(string[,] data, int[] dependentColumns)
        {
            var m = data.GetLength(0);
            var n = data.GetLength(1);
            for (var i = 0; i < m; i++)
            {
                for (var j = 0; j < n; j++)
                {
                    if (string.IsNullOrEmpty(data[i, j]))
                    {
                        if (dependentColumns == null)
                        {
                            if (DataPreparator.XColumnTypes[j] != ColumnType.Numeric)
                            {
                                data[i, j] = "NA";                                
                            }
                            else
                            {
                                data[i, j] = DataPreparator.XMeans[j].ToString();
                            }
                        }
                        else
                        {
                            if (DataPreparator.ColumnTypes[j] != ColumnType.Numeric)
                            {
                                data[i, j] = "NA";
                                if (DataPreparator.ColumnTypes[j] == ColumnType.Binary) DataPreparator.ColumnTypes[j] = ColumnType.Categorical;
                            }
                            else
                            {
                                data[i, j] = DataPreparator.Means[j].ToString();
                            }
                        }
                    }
                }
            }
        }

       

    }
}
