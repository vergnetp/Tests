﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigData
{

    public enum ColumnType
    {
        Unknown,
        Ignore,
        Id,
        Numeric,
        Binary,
        Categorical
    }

    public class DataPreparator
    {
        public string[] XHeader;
        public string[] YHeader;
        public string[] Header;
        public List<string>[] XDistinctValues;
        public ColumnType[] XColumnTypes;
        public List<string>[] YDistinctValues;
        public ColumnType[] YColumnTypes;
        public List<string>[] DistinctValues;
        public ColumnType[] ColumnTypes;
        public float[] XMeans; public float[] XStdDevs; public float[] XMins; public float[] XMaxs;
        public float[] YMeans; public float[] YStdDevs; public float[] YMins; public float[] YMaxs;
        public float[] Means; public float[] StdDevs; public float[] Mins; public float[] Maxs;

        public string OutputFile;

        protected IRepository _Repo;
        public DataPreparator(IRepository repo) { _Repo= repo; }

        public static bool IsNumeric(object Expression)
        {
            float retNum;
            if (string.IsNullOrEmpty(Convert.ToString(Expression))) { return true; }
            bool isNum = float.TryParse(Convert.ToString(Expression), System.Globalization.NumberStyles.Any, System.Globalization.NumberFormatInfo.InvariantInfo, out retNum);
            return isNum;
        }
        

        public void Prepare(string[,] subData, int[] dependentColumns,bool hasHeader=true,ColumnType[] columnTypes=null)
        {
            Header = new string[subData.GetLength(1)];
            if (hasHeader)
            {
                for (var j=0;j< subData.GetLength(1);j++)
                {
                    Header[j] = subData[0, j];
                }
            }
            else
            {
                for (var j = 0; j < subData.GetLength(1); j++)
                {
                    Header[j] ="Column"+j.ToString();
                }
            }
            var headerOffset = hasHeader ? 1 : 0;
            DistinctValues = new List<string>[subData.GetLength(1)];
            if (columnTypes == null)
            {
                ColumnTypes = new ColumnType[subData.GetLength(1)];
                for (var j = 0; j < subData.GetLength(1); j++)
                //Parallel.For (0, subData.GetLength(1), j =>
                {
                    ColumnTypes[j] = ColumnType.Numeric;
                }
            }
            else
            {
                ColumnTypes = columnTypes;
            }

            var missingIndices = new List<int>();
            for (var j = 0; j < subData.GetLength(1); j++)
            //Parallel.For (0, subData.GetLength(1), j =>
            {
                if (DistinctValues[j] == null)
                {
                    DistinctValues[j] = new List<string>();
                }
                var dico = new SortedDictionary<string, bool>();
                for (var i = headerOffset; i < subData.GetLength(0); i++)
                {
                    if (dependentColumns != null && (string.IsNullOrEmpty(subData[i, j]) && dependentColumns.Contains(j)))
                    {
                        if (!missingIndices.Contains(i)) missingIndices.Add(i);
                    }
                    else
                    {
                        if (!DistinctValues[j].Contains(subData[i, j])) DistinctValues[j].Add(subData[i, j]);
                        if (!IsNumeric(subData[i, j])) ColumnTypes[j] = ColumnType.Categorical;
                    }
                }
            }//);              
            //subData = subData.RemoveRowsAndShuffle<string>(missingIndices.ToArray()); // todo            
          
            GetStats(subData, ColumnTypes,headerOffset, out Means, out StdDevs, out Maxs, out Mins);
            for (var j = 0; j < DistinctValues.Length; j++)
            {
                if (ColumnTypes[j] == ColumnType.Numeric && Means[j] == 0 && StdDevs[j] == 0)
                {
                    DistinctValues[j] = new List<string>() { "NA" };
                    ColumnTypes[j] = ColumnType.Categorical;
                }
            }
            DispatchStats(dependentColumns);

            // Add "NA" to be able to handle unseen data
            for (var j = 0; j < DistinctValues.Length; j++)
            {
                DistinctValues[j].Remove(string.Empty);
                if ((ColumnTypes[j] == ColumnType.Categorical || ColumnTypes[j] == ColumnType.Binary))
                {
                    if (!DistinctValues[j].Contains("NA"))
                    {
                        DistinctValues[j].Add("NA");
                        ColumnTypes[j] = ColumnType.Categorical;
                    }                    
                }
            }
        }


        /// <summary>
        /// Call that before using training or test data.
        /// This should be called on the training data.
        /// Populate DistinctValues and ColumnTypes.
        /// Populate the stats (means etc.)
        /// Generate Output, a copy of the targeted subset input except for rows where all value of the dependent variables are null or empty.
        /// </summary>
        /// <param name="outputName">The output name.</param>
        /// <param name="trainingName">The input name.</param>
        /// <param name="dependentColumns">Zero based indices of the dependent variables. Null if none (f.e. on Kaggle test set)</param>
        /// <param name="offset">Zero based start of the subset.</param>
        /// <param name="size">Number of rows in the subset.</param>
        public void Prepare(string outputName, string trainingName, int[] dependentColumns, long offset, long size)
        {
            OutputFile = outputName;
            // todo: if the full column is empty then it should be deemed categorical   
            _Repo.Clear(outputName);  
            var lastRow = offset + size;
            var firstRow = _Repo.Header(trainingName);
            Header = firstRow;
            _Repo.Export(outputName, firstRow);
            var n = (long)firstRow.Length;
            var maxSize = 1000 * 1000 / n;// 1000 * 1000 / n; // We allow a 64MB array max
            var subSize = Math.Min(size, maxSize);
            var curOffset = offset;
            var subData = _Repo.Import(trainingName, curOffset, subSize);            
            DistinctValues = new List<string>[subData.GetLength(1)];
            ColumnTypes = new ColumnType[subData.GetLength(1)];
            for (var j = 0; j < subData.GetLength(1); j++)
            //Parallel.For (0, subData.GetLength(1), j =>
            {
                ColumnTypes[j] = ColumnType.Numeric;
            }
            do
            {
                var missingIndices = new List<int>();
                for (var j = 0; j < subData.GetLength(1); j++)
                //Parallel.For (0, subData.GetLength(1), j =>
                {                    
                    if (DistinctValues[j] == null)
                    {
                        DistinctValues[j] = new List<string>();
                    }
                    var dico = new SortedDictionary<string, bool>();
                    for (var i = 0; i < subData.GetLength(0); i++)
                    {
                        if (dependentColumns != null && (string.IsNullOrEmpty(subData[i, j]) && dependentColumns.Contains(j)))
                        {
                            if (!missingIndices.Contains(i)) missingIndices.Add(i);
                        }
                        else
                        {
                            if (!DistinctValues[j].Contains(subData[i, j])) DistinctValues[j].Add(subData[i, j]);
                            if (!IsNumeric(subData[i, j])) ColumnTypes[j] = ColumnType.Categorical;
                        }
                    }
                }//);              
                //subData = subData.RemoveRowsAndShuffle<string>(missingIndices.ToArray()); // todo
                _Repo.InsertData(outputName, subData,false);
                curOffset += subSize;
                subSize = Math.Min(subSize, lastRow - curOffset);
                subData = _Repo.Import(trainingName, curOffset, subSize);
            } while (subData != null);

            GetStats(trainingName, offset, size, ColumnTypes, out Means, out StdDevs, out Maxs, out Mins);
            for (var j = 0; j < DistinctValues.Length; j++)
            {
                if (ColumnTypes[j] == ColumnType.Numeric && Means[j]==0 && StdDevs[j]==0)
                {
                    DistinctValues[j]=new List<string>() { "NA" };
                    ColumnTypes[j] = ColumnType.Categorical;
                }
            }
            DispatchStats(dependentColumns);

            // Add "NA" to be able to handle unseen data
            for (var j = 0; j < DistinctValues.Length; j++)
            {
                if ((ColumnTypes[j] == ColumnType.Categorical || ColumnTypes[j] == ColumnType.Binary) && !DistinctValues[j].Contains("NA"))
                {
                    DistinctValues[j].Add("NA");
                    ColumnTypes[j] = ColumnType.Categorical;
                }
            }
           //todo: replace "" by "NA"
        }
        
        protected void DispatchStats(int[] dependentColumns)
        {
            MatrixCalculus.Extract(Means, dependentColumns,out YMeans,out XMeans);
            MatrixCalculus.Extract(StdDevs, dependentColumns, out YStdDevs, out XStdDevs);
            MatrixCalculus.Extract(Maxs, dependentColumns, out YMaxs, out XMaxs);
            MatrixCalculus.Extract(Mins, dependentColumns, out YMins, out XMins);
            MatrixCalculus.Extract(ColumnTypes, dependentColumns, out YColumnTypes, out XColumnTypes);
            MatrixCalculus.Extract(DistinctValues, dependentColumns, out YDistinctValues, out XDistinctValues);
            MatrixCalculus.Extract(Header, dependentColumns, out YHeader, out XHeader);        
        }

        public void GetStats(string[,] subData, ColumnType[] ColTypes,int headerOffset,
                                out float[] means, out float[] stdDevs, out float[] maxs, out float[] mins)
        {
            var n = subData.GetLength(1);
            var localMeans = new float[n]; var localStdDevs = new float[n]; var localMins = new float[n]; var localMaxs = new float[n];
            var nbRows = new long[n];
            Parallel.For(0, n, j =>
            {
                localMins[j] = float.MaxValue;
                if (ColTypes[j] == ColumnType.Numeric)
                {
                    for (var i = headerOffset; i < subData.GetLength(0); i++)
                    {
                        if (!string.IsNullOrEmpty(subData[i, j]))
                        {
                            float retNum;
                            float.TryParse(subData[i, j], System.Globalization.NumberStyles.Any, System.Globalization.NumberFormatInfo.InvariantInfo, out retNum);
                            localMeans[j] += retNum;
                            localMaxs[j] = localMaxs[j] > retNum ? localMaxs[j] : retNum;
                            localMins[j] = localMins[j] < retNum ? localMins[j] : retNum;
                            nbRows[j]++;
                        }
                    }
                }
            });               
            for (var j = 0; j < n; j++)
            {
                if (nbRows[j] > 1) { localMeans[j] /= (float)nbRows[j]; }
            }           
            Parallel.For(0, subData.GetLength(1), j =>
            {
                if (ColTypes[j] == ColumnType.Numeric)
                {
                    for (var i = headerOffset; i < subData.GetLength(0); i++)
                    {
                        float retNum;
                        float.TryParse(subData[i, j], System.Globalization.NumberStyles.Any, System.Globalization.NumberFormatInfo.InvariantInfo, out retNum);
                        localStdDevs[j] += (float)Math.Pow(retNum - localMeans[j], 2);
                    }
                }
            });               
            for (var j = 0; j < n; j++)
            {
                if (nbRows[j] > 1) { localStdDevs[j] /= (float)(nbRows[j] - 1); }
                localStdDevs[j] = (float)Math.Sqrt(localStdDevs[j]);
            }
            means = localMeans; stdDevs = localStdDevs; mins = localMins; maxs = localMaxs;
        }


        public void GetStats(string csvPath, long offset, long size,
                                ColumnType[] ColTypes,
                                out float[] means, out float[] stdDevs, out float[] maxs, out float[] mins)
        {
            var lastRow = offset + size;
            var firstRow = _Repo.Header(csvPath);
            var n = (long)firstRow.Length;
            var localMeans = new float[n]; var localStdDevs = new float[n]; var localMins = new float[n]; var localMaxs = new float[n];
            var maxSize = 1000 * 1000 / n;// 1000 * 1000 / n; // We allow a 64MB array max
            var subSize = Math.Min(size, maxSize);
            var curOffset = offset;
            var subData = _Repo.Import(csvPath, curOffset, subSize);
            var nbRows = new long[n];
            do
            {
                Parallel.For(0, subData.GetLength(1), j =>
                {
                    localMins[j] = float.MaxValue;
                    if (ColTypes[j] == ColumnType.Numeric)
                    {
                        for (var i = 0; i < subData.GetLength(0); i++)
                        {
                            if (!string.IsNullOrEmpty(subData[i, j]))
                            {
                                float retNum;
                                float.TryParse(subData[i, j], System.Globalization.NumberStyles.Any, System.Globalization.NumberFormatInfo.InvariantInfo, out retNum);
                                localMeans[j] += retNum;
                                localMaxs[j] = localMaxs[j] > retNum ? localMaxs[j] : retNum;
                                localMins[j] = localMins[j] < retNum ? localMins[j] : retNum;
                                nbRows[j]++;
                            }
                        }
                    }
                });
                curOffset += subSize;
                subSize = Math.Min(subSize, lastRow - curOffset);               
                subData = _Repo.Import(csvPath,  curOffset, subSize);
            } while (subData != null);
            for (var j = 0; j < n; j++)
            {
                if (nbRows[j] > 1) { localMeans[j] /= (float)nbRows[j]; }
            }
            curOffset = offset;
            subSize = Math.Min(size, maxSize);
            subData = _Repo.Import(csvPath,  curOffset, subSize);
            do
            {
                Parallel.For(0, subData.GetLength(1), j =>
                {
                    if (ColTypes[j] == ColumnType.Numeric)
                    {
                        for (var i = 0; i < subData.GetLength(0); i++)
                        {
                            float retNum;
                            float.TryParse(subData[i, j], System.Globalization.NumberStyles.Any, System.Globalization.NumberFormatInfo.InvariantInfo, out retNum);
                            localStdDevs[j] += (float)Math.Pow(retNum - localMeans[j], 2);
                        }
                    }
                });
                curOffset += subSize;
                subSize = Math.Min(subSize, lastRow - curOffset);
                subData = _Repo.Import(csvPath, curOffset, subSize);
            } while (subData != null);
            for (var j = 0; j < n; j++)
            {
                if (nbRows[j] > 1) { localStdDevs[j] /= (float)(nbRows[j] - 1); }
                localStdDevs[j] = (float)Math.Sqrt(localStdDevs[j]);
            }
            means = localMeans; stdDevs = localStdDevs; mins = localMins; maxs = localMaxs;
        }

    }
}
