﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigData
{
    public class TestSolver
    {
        public static void Test()
        {
            var repo = new RepositoryCsv(@"C:\Users\UK800386\Desktop\Bony");
            var solver = new SolverMomentum(repo: repo);
            solver.Fit("bonyTrain", new[] { 0 }, 0L, long.MaxValue);
            solver.Predict("bonyTest", "preds", null);
            solver.Predict("bonyTrain", "predsOnTrain", new[] { 0 });
            solver.Encoder.DecodeY("yTrainCheck", "YTrain", MinY.MinusOne);
            solver.Encoder.DecodeX("xTrainCheck", "XTrain", MinY.MinusOne);
            //solver.Encoder.DecodeX("predCheck", "preds", MinY.MinusOne);

            //var repo = new RepositoryCsv(@"C:\Users\philippe\Desktop");
            //var solver = new SolverMomentum(repo: repo);
            //solver.Fit("train", new[] { 0 }, 0L, long.MaxValue);
            ////solver.Predict("test", "preds", null);
            //solver.Predict("train", "predsOnTrain", new[] { 0 });
        }

    }
}
