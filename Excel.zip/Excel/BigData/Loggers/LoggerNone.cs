﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigData
{
    public class LoggerNone : ILogger
    {
        public void LogError(Exception ex)
        {
           
        }

        public void LogError(string msg, params object[] args)
        {
            
        }

        public void LogInfo(string msg, params object[] args)
        {
           
        }

        public void LogWarning(string msg, params object[] args)
        {
            
        }
    }
}
