﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigData
{
    public interface ILogger
    {
        void LogInfo(string msg, params object[] args);
        void LogWarning(string msg, params object[] args);
        void LogError(string msg, params object[] args);
        void LogError(Exception ex);
    }
}
