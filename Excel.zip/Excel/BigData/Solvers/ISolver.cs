﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigData
{
    public interface ISolver
    {
        IModel Model { get; set; }
        Encoder Encoder { get; set; }

        int MaxIterations { get; set; }
        float LearningRate { get; set; }
        float ConvergenceThreshold { get; set; }
        float[] Solution { get; }
        int LastIteration { get; }

        void UpdateModelWeights(float[,] XTrain, float[,] YTrain);
        bool Fit(float[,] XTrain, float[,] YTrain);
        Task<bool> FitAsync(float[,] XTrain, float[,] YTrain);
        void Reset();

        ISolver Clone();

        event EventHandler EpochCompleted;
        event EventHandler ResetCalled;



    }
}
