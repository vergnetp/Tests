﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.IO;

namespace BigData
{
    [DataContract]
    public abstract class Solver : ISolver
    {

        #region Members

        [DataMember]
        public IModel Model { get; set; }
        [DataMember]
        public Encoder Encoder { get; set; }
       
        [DataMember]
        public float LearningRate { get; set; }

        [DataMember]
        public int MaxIterations { get; set; }

        [DataMember]
        public float ConvergenceThreshold { get; set; }

        protected int _CurrentIteration;
        [DataMember]
        public int LastIteration
        {
            get { return _CurrentIteration; }
            protected set { _CurrentIteration = value; }
        }

        public ILogger Logger;

        public event EventHandler EpochCompleted;

        public event EventHandler ResetCalled;

        protected IRepository _Repo { get { return this.Encoder.Repo; } }       

        #endregion

        #region Ctor    

        public Solver(IModel model = null, IRepository repo=null,MissingDataHandler missingDataHandler = null,
        int maxIterations = 1000, float convergenceThreashold = 0.01F, float learningRate = 0.5F, MinY minY = MinY.MinusOne, ILogger logger = null)
        {
            Logger = logger ?? new LoggerConsole();
            Model = model ?? new ModelNeuralNetwork();
            MaxIterations = maxIterations;
            ConvergenceThreshold = convergenceThreashold;           
            if (minY == MinY.MinusOne && this.Model.GetType() == typeof(ModelNeuralNetwork) && ((ModelNeuralNetwork)this.Model).Activator.GetType() == typeof(ActivatorSigmoid))
            {
                ((ModelNeuralNetwork)this.Model).Activator = new ActivatorTanh();
                Logger.LogInfo("The Neural Network Transfer function has been replaced by Tanh one to be able to reach negative values in the predictions.");
            }
            repo = repo ?? new RepositoryCsv(@"C:\temp");
            var dataPreparator = new DataPreparator(repo);
            if (missingDataHandler == null)
            {
                Logger.LogInfo("Missing Data will be replaced by the average of the existing numerical values, and by 'NA' for categorical columns.");
                missingDataHandler = new MissingDataAverageAndNA(dataPreparator, logger, repo);
            }
            Encoder = new Encoder(missingDataHandler,repo,logger);    
            LearningRate = learningRate;
        }

        #endregion

        #region Solve
        
        /// <summary>
        /// Expect a table without dependent variables
        /// </summary>
        /// <param name="testName"></param>
        /// <param name="predName"></param>
        /// <param name="offset"></param>
        /// <param name="size"></param>
        /// <param name="minY"></param>
        public void PredictEncoded(string testName, string predName,int[] depdendentColumns, long offset = 0, long size = long.MaxValue,MinY minY=MinY.MinusOne)
        {
            if (!Encoder.IsEncoded) throw new Exception("You must encode fit on the training data before predicting.");
            var xName = "XTest";var yName = "YTest";
            Encoder.EncodeTest(testName, depdendentColumns, encodedXName: xName, encodedYName: yName, offset: offset, size: size);
            var nbFeatures = Encoder.xEncodedHeader.Length;
            var m = size;
            var nbRowsInMiniBatch = 10000 * 1000 / nbFeatures; // float, so can allow bigger array in memory
            var nbMiniBatch = (int)Math.Ceiling((float)m / nbRowsInMiniBatch);
            if (nbFeatures != this.Model.Parameters.NbFeatures)
            {
                throw new Exception(string.Format("Cannot predict as model was trained on {0} features and this file has {1} features.", nbFeatures, this.Model.Parameters.NbFeatures));
            }
            var batchOffset = offset;
                     
            _Repo.Export(predName, Encoder.yEncodedHeader);

            var subX = _Repo.ImportAsFloat(xName, batchOffset, nbRowsInMiniBatch);
            while (subX != null)
            {
                var preds = this.Model.Predict(subX);
                _Repo.InsertData(predName, preds);
                batchOffset += nbRowsInMiniBatch;
                subX = _Repo.ImportAsFloat(xName, batchOffset, nbRowsInMiniBatch);
            }            
        }

        public void Predict(string testName, string predName, int[] depdendentColumns, long offset = 0, long size = long.MaxValue, MinY minY = MinY.MinusOne)
        {
            var yName = "YTest";
            PredictEncoded(testName, yName, depdendentColumns, offset, size, minY);
            Encoder.DecodeY(predName, yName, minY);
        }

        public bool Fit(string trainingName, int[] dependentColumns, long offset, long size)
        {
            var xName = "XTrain";
            var yName = "YTrain";
            Encoder.EncodeTrain(trainingName, dependentColumns,encodedXName:xName,encodedYName:yName, offset: offset, size: size);
            var decodedYTrain="decodedYTrain";
            Encoder.DecodeY(decodedYTrain,yName,MinY.MinusOne);
            var nbFeatures = _Repo.GetNbColumns(trainingName)- dependentColumns.Length; //todo: bug!! nbClasses can be more that dependentColumns.Length (if categorical)
            var nbClasses = dependentColumns.Length;
            var nbRows = _Repo.GetNbRows(trainingName);
            var m = Math.Min(nbRows, size);
            var nbRowsInMiniBatch = 1000 * 100 / nbFeatures; // We allow a 64MB array max
            var nbMiniBatch = (int)Math.Ceiling((float)m / nbRowsInMiniBatch);
            Logger.LogInfo("Stochastic learning: {0} mini batches will be run per epoch.", nbMiniBatch);
            if (nbClasses != this.Model.Parameters.NbClasses)
            {
                Logger.LogInfo("The model will be reset to be able to deal with a diferrent number of classes ({0} instead of {1} previously)", nbClasses, this.Model.Parameters.NbClasses);
                this.Model.ResetWeights(nbFeatures, nbClasses);
                _CurrentIteration = 0;
            }
            if (nbFeatures != this.Model.Parameters.NbFeatures)
            {
                Logger.LogInfo("The model will be reset to be able to deal with a diferrent number of features ({0} instead of {1} previously)", nbFeatures, this.Model.Parameters.NbFeatures);
                this.Model.ResetWeights(nbFeatures, nbClasses);
                _CurrentIteration = 0;
            }
            var counter = 0; var distance = 0F;
            var converged = false;           
            var import = nbRowsInMiniBatch < _Repo.GetNbRows(xName) - offset;
            while (counter < MaxIterations && !converged)
            {
                var oldWeights = Model.Weights;
                var batchOffset = offset;
                
                var subX = _Repo.ImportAsFloat(xName, batchOffset, nbRowsInMiniBatch);
                var subY = _Repo.ImportAsFloat(yName, batchOffset, nbRowsInMiniBatch);
                
                while (subX != null)
                {
                    UpdateModelWeights(subX, subY);
                    batchOffset += nbRowsInMiniBatch;
                    subX = _Repo.ImportAsFloat(xName, batchOffset, nbRowsInMiniBatch);
                    subY = _Repo.ImportAsFloat(yName, batchOffset, nbRowsInMiniBatch);
                }

                // Check convergence 
                var newWeights = Model.Weights;
                if (newWeights.Length == oldWeights.Length)
                {
                    distance = newWeights.Distance(oldWeights);
                    converged = distance < this.ConvergenceThreshold;
                }
                // Raise EpochEvent
                if (this.EpochCompleted != null)
                {
                    EpochCompleted(this, EventArgs.Empty);
                }

                if (counter % 100 == 0)
                {
                    var predName = "PredEncoded";
                    PredictEncoded(trainingName, predName, dependentColumns);
                    var cost = this.Model.CostCalculator.Cost(predName, yName, this._Repo, this.Model.Weights);
                    var predDecoded = "PredDecoded";
                    this.Encoder.DecodeY(predDecoded, predName, MinY.MinusOne);
                    var accuracy = AccuracyAssessor.GetAccuracy(predDecoded, decodedYTrain, _Repo, Logger);

                    Logger.LogInfo("Epoch Nb. {0}:", counter);
                    Logger.LogInfo("   Cost: {0:0.0000}", cost);
                    Logger.LogInfo("   Accuracy: {0:P}", accuracy);
                    Logger.LogInfo("   Distance: {0:0.0000}", distance);
                }

                counter++;
                _CurrentIteration++;
            }
            Logger.LogInfo("Training stopped after {0} epochs (Total epochs since model reset: {1}).", counter, _CurrentIteration);
            Logger.LogInfo("Converged: {0} (weights are still {1:0.000} apart)", converged, distance);
             return converged;
        }       

        public bool Fit(float[,] XTrain, float[,] YTrain)
        {
            var m = XTrain.GetLength(0);
            var nbFeatures = XTrain.GetLength(1);
            var nbClasses = YTrain.GetLength(1);
            var nbRowsInMiniBatch = 1000 * 100 / nbFeatures;
            var nbMiniBatch = (int)Math.Ceiling((float)m / nbRowsInMiniBatch);
            Logger.LogInfo("Stochastic learning: {0} mini batches will be run per epoch.", nbMiniBatch);
            if (nbClasses != this.Model.Parameters.NbClasses)
            {
                Logger.LogInfo("The model will be reset to be able to deal with a different number of classes ({0} instead of {1} previously)", nbClasses, this.Model.Parameters.NbClasses);
                this.Model.ResetWeights(nbFeatures, nbClasses);
                _CurrentIteration = 0;
            }
            if (nbFeatures != this.Model.Parameters.NbFeatures)
            {
                Logger.LogInfo("The model will be reset to be able to deal with a diferrent number of features ({0} instead of {1} previously)", nbFeatures, this.Model.Parameters.NbFeatures);
                this.Model.ResetWeights(nbFeatures, nbClasses);
                _CurrentIteration = 0;
            }
            var counter = 0;
            var converged = false;
            while (counter < MaxIterations && !converged)
            {
                var oldWeights = Model.Weights;
                var partition =MatrixCalculus.KPartition(XTrain, YTrain, nbMiniBatch);
                foreach (var part in partition)
                {
                    var subX = part.Item1;
                    var subY = part.Item2;
                    UpdateModelWeights(subX, subY);
                }
                // Check convergence 
                var newWeights = Model.Weights;
                if (newWeights.Length == oldWeights.Length)
                {
                    var distance = newWeights.Distance(oldWeights);
                    converged = distance < this.ConvergenceThreshold;
                }
                // Raise EpochEvent
                if (this.EpochCompleted != null)
                {
                    EpochCompleted(this, EventArgs.Empty);
                }
                counter++;
                _CurrentIteration++;
            }
            Logger.LogInfo("Training stopped after {0} epochs (Total epochs since model reset: {1}).", counter, _CurrentIteration);
            Logger.LogInfo("Converged: {0} (weights are still {1:0.000} apart)");
            return converged;
        }

        public async Task<bool> FitAsync(float[,] XTrain, float[,] YTrain)
        {
            var res = await Task<bool>.Run(() => this.Fit(XTrain, YTrain));
            return res;
        }

        public float[] Solution
        {
            get { return Model.Weights; }
        }

        public abstract void UpdateModelWeights(float[,] XTrain, float[,] YTrain);

        #endregion

        #region Tools

        public ISolver Clone() // todo: improve or delete
        {
            var solver = Activator.CreateInstance(this.GetType()) as ISolver;
            solver.Model = this.Model.Clone();
            solver.Encoder = this.Encoder;           
            solver.MaxIterations = this.MaxIterations;
            solver.LearningRate = this.LearningRate;
            solver.ConvergenceThreshold = this.ConvergenceThreshold;
            solver.ResetCalled += this.ResetCalled;
            solver.EpochCompleted += this.EpochCompleted;
            return solver;
        }

        public void Reset()
        {
            // todo: do we reset model as well?
            LastIteration = 0;
            // Raise event
            if (this.ResetCalled != null)
            {
                ResetCalled(this, EventArgs.Empty);
            }
        }

        #endregion

        #region Checks

        public bool CheckGradient(float[,] XTrain, float[,] YTrain)
        {
            var XExtract = Accord.Math.Matrix.Submatrix(XTrain, new int[] { 0, 1, 2, 3, 4 });
            var YExtract = Accord.Math.Matrix.Submatrix(YTrain, new int[] { 0, 1, 2, 3, 4 });
            var tolerance = 0.01F;
            var distance = 0.0F;
            var normPlus = 0.0F;
            var normMinus = 0.0F;
            var backupWeights = new float[Model.Weights.Length];
            backupWeights.CopyInto(Model.Weights);
            //Array.Clear(Model.Weights, 0, Model.Weights.Length);
            var gradientsCalc = Model.GetGradients(XExtract, YExtract);
            var gradientsNum = GetNumGradient(XExtract, YExtract);
            Model.Weights.CopyInto(backupWeights);
            for (var i = 0; i < gradientsCalc.GetLength(0); i++)
            {
                var gradNum = gradientsNum[i];
                var gradCalc = gradientsCalc[i];
                normMinus += (gradNum - gradCalc) * (gradNum - gradCalc);
                normPlus += (gradNum + gradCalc) * (gradNum + gradCalc);
            }
            normMinus = (float)Math.Pow(normMinus, 0.5);
            normPlus = (float)Math.Pow(normPlus, 0.5);
            distance = normMinus / normPlus;
            return distance < tolerance;
        }

        public float[] GetNumGradient(float[,] X, float[,] Y)
        {
            var res = new float[Model.Weights.Length];
            var epsilon = 0.0001F;
            for (var i = 0; i < res.Length; i++)
            {
                Model.Weights[i] += epsilon;
                var predictionsPlus = Model.Predict(X);
                var bumpPlus = Model.CostCalculator.Cost(predictionsPlus, Y, Model.Weights);
                Model.Weights[i] -= 2.0F * epsilon;
                var predictionsMinus = Model.Predict(X);
                var bumpMinus = Model.CostCalculator.Cost(predictionsMinus, Y, Model.Weights);
                Model.Weights[i] += epsilon;
                var deb = predictionsPlus.ValueEquals(predictionsMinus);
                res[i] = (bumpPlus - bumpMinus) / (2.0F * epsilon);
            }
            return res;
        }

        #endregion

    }
}

