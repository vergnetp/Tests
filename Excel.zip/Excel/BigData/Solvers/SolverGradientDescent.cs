﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace BigData
{
    [DataContract]
    public class SolverGradientDescent : Solver
    {

        public SolverGradientDescent() { }

        public SolverGradientDescent(IModel model = null, IRepository repo = null, MissingDataHandler missingDataHandler = null, int maxIterations = 100, float convergenceThreashold = 0.000001F, float learningRate = 0.1F, MinY minY = MinY.MinusOne, ILogger logger = null)
            : base(model, repo,missingDataHandler, maxIterations, convergenceThreashold, learningRate, minY, logger)
        {
        }

        public override void UpdateModelWeights(float[,] XTrain, float[,] YTrain)
        {
            var gradient = Model.GetGradients(XTrain, YTrain);
            Model.Weights = Model.Weights.Select((value, index) => value - gradient[index] * LearningRate).ToArray();
        }

    }
}
