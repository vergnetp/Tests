﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigData
{

    public enum RegularizationScheme
    {
        None,
        L1Norm,
        L2Norm
    }

    public interface IRegularizedCostCalculator
    {
        ICostCalculator CostCalculator { get; set; }
        RegularizationScheme RegularizationScheme { get; set; }
        float RegularizationBudget { get; set; }
        float RegularizationPenalty(float[] weights, long nbSamples);
        float Cost(float[,] predictions, float[,] Y, float[] weights);
        float Cost(string predName, string yName, IRepository repo, float[] weights);
        IRegularizedCostCalculator Clone();
    }

}
