﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace BigData
{
    [DataContract]
    public class RegularizedCostCalculator : IRegularizedCostCalculator
    {
        public RegularizedCostCalculator(ICostCalculator costCalculator, RegularizationScheme regularizationScheme = RegularizationScheme.None, float regularizationBudget = 0.0F)
        {
            CostCalculator = costCalculator;
            RegularizationScheme = regularizationScheme;
            RegularizationBudget = regularizationBudget;
        }

        [DataMember]
        public ICostCalculator CostCalculator { get; set; }

        [DataMember]
        public RegularizationScheme RegularizationScheme { get; set; }

        [DataMember]
        public float RegularizationBudget { get; set; }

        public float RegularizationPenalty(float[] weights, long nbSamples)
        {
            switch (RegularizationScheme)
            {
                case RegularizationScheme.L1Norm:
                    return weights.Apply(x => Math.Abs(x)).Sum() / nbSamples * RegularizationBudget;
                case RegularizationScheme.L2Norm:
                    return weights.Apply(x => (float)Math.Pow(x, 2.0)).Sum() / (2 * nbSamples) * RegularizationBudget;
                default:
                    return 0.0F;
            }
        }

        public float Cost(string predName, string yName, IRepository repo, float[] weights)
        {
            var cost = CostCalculator.Cost(predName,yName,repo);
            var regularization = RegularizationPenalty(weights, CostCalculator.NbSamples);
            return cost + regularization;
        }

        public float Cost(float[,] predictions, float[,] Y, float[] weights)
        {
            var cost = CostCalculator.Cost(predictions, Y);
            var regularization = RegularizationPenalty(weights, Y.GetLength(0));
            return cost + regularization;
        }

        public IRegularizedCostCalculator Clone()
        {
            var costCalculator = System.Activator.CreateInstance(this.GetType(), this.CostCalculator, this.RegularizationScheme, this.RegularizationBudget) as IRegularizedCostCalculator;
            return costCalculator;
        }
    }
}
