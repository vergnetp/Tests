﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigData
{

    public interface ICostCalculator
    {
        float Cost(string predName, string yName, IRepository repo);

        float Cost(float[,] predictions, float[,] Y);

        float[,] CostDerivate(float[,] predictions, float[,] Y);

        long NbSamples { get; set; }

    }

}
