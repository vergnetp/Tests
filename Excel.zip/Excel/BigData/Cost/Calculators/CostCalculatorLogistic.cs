﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace BigData
{
    [DataContract]
    public class CostCalculatorLogistic : ICostCalculator
    {

        public long NbSamples { get; set; }

        public float Cost(string predName, string yName, IRepository repo)
        {
            var offset = 0L; var size = long.MaxValue;
            var lastRow = offset + size;
            var firstRow = repo.Header(yName);
            var n = (long)firstRow.Length;
            var maxSize = 1000 * 1000 / n;// 1000 * 1000 / n; // We allow a 64MB array max
            var subSize = Math.Min(size, maxSize);
            var ySubData = repo.ImportAsFloat(yName, offset, subSize);
            var predSubData = repo.ImportAsFloat(predName, offset, subSize);
            var m = 0L; var cost = 0F;
            do
            {
                m += ySubData.GetLength(0);

                var m2 = ySubData.GetLength(0);
                var n2 = ySubData.GetLength(1);
                var tmp = new float[m2, n2];
                Parallel.For(0, m2, i =>
                {
                    for (var j = 0; j < n2; j++)
                    {
                        tmp[i, j] = -ySubData[i, j] * (float)Math.Log(predSubData[i, j]) - (1.0F - ySubData[i, j]) * (float)Math.Log(1.0F - predSubData[i, j]);
                    }
                });
                cost += tmp.Sum();

                offset += subSize;
                subSize = Math.Min(subSize, lastRow - offset);
                ySubData = repo.ImportAsFloat(yName, offset, subSize);
                predSubData = repo.ImportAsFloat(predName, offset, subSize);
            } while (ySubData != null);
            cost = cost / ((float) m);
            NbSamples = m;
            return cost;
        }

        public float Cost(float[,] predictions, float[,] Y)
        {
            // todo check length
            // todo pointers
            var m = Y.GetLength(0);
            var n = Y.GetLength(1);
            var tmp = new float[m, n];
            Parallel.For(0, m, i =>
            {
                for (var j = 0; j < n; j++)
                {
                    tmp[i, j] = -Y[i, j] * (float)Math.Log(predictions[i, j]) - (1.0F - Y[i, j]) * (float)Math.Log(1.0F - predictions[i, j]);
                }
            });
            var cost = tmp.Sum() / ((float)m);
            return cost;
        }

        public float[,] CostDerivate(float[,] predictions, float[,] Y)
        {
            // todo check length
            // todo real function
            return predictions.Apply(Y, (x, y) => y / x + (1 - x) / (1 - y));
        }

    }
}
