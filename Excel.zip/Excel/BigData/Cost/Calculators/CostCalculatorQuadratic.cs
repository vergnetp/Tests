﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace BigData
{
    [DataContract]
    public class CostCalculatorQuadratic : ICostCalculator
    {

        public long NbSamples { get; set; }

        public float Cost(string predName,string yName,IRepository repo)
        {
            var offset = 0L; var size = long.MaxValue;
            var lastRow = offset + size;
            var firstRow = repo.Header(yName);        
            var n = (long)firstRow.Length;
            var maxSize = 1000 * 1000 / n;// 1000 * 1000 / n; // We allow a 64MB array max
            var subSize = Math.Min(size, maxSize);
            var ySubData = repo.ImportAsFloat(yName, offset, subSize);
            var predSubData = repo.ImportAsFloat(predName, offset, subSize);
            var m = 0L;var cost=0F;
            do
            {
                m += ySubData.GetLength(0);
                var diff = predSubData.Subtract(ySubData);
                var squaredDiff = diff.Apply(x => x * x);
                cost += squaredDiff.Sum();
                offset += subSize;
                subSize = Math.Min(subSize, lastRow - offset);
                ySubData = repo.ImportAsFloat(yName, offset, subSize);
                predSubData = repo.ImportAsFloat(predName, offset, subSize);
            } while (ySubData != null);
            cost = cost / ((float)2.0F * m);
            NbSamples = m;
            return cost;
        }

        public float Cost(float[,] predictions, float[,] Y)
        {
            // todo check lengths
            // todo optimize?
            var m = Y.GetLength(0);
            var diff = predictions.Subtract(Y);
            var squaredDiff = diff.Apply(x => x * x);
            var cost = squaredDiff.Sum() / ((float)2.0F * m);
            return cost;
        }

        public float[,] CostDerivate(float[,] predictions, float[,] Y)
        {
            return predictions.Subtract(Y);
        }

    }
}
