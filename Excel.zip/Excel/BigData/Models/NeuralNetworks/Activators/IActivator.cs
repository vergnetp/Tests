﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigData
{
    public interface IActivator
    {
        float Activate(float z);
        float ActivateDerivate(float z);
    }
}
