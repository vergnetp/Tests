﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace BigData
{
    [DataContract]
    public class ActivatorTanh : IActivator
    {
        public float Activate(float z)
        {
            return 1.7159F * (float)Math.Tanh(2.0F / 3.0F * z);
        }

        public float ActivateDerivate(float z)
        {
            return 1.7159F * 2.0F / 3.0F * (1.0F - (float)Math.Pow(Math.Tanh(2.0F / 3.0F * z), 2));
        }
    }
}
