﻿using Cudafy;
using Cudafy.Host;
using Cudafy.Translator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigData
{
    public class GpuMatrix
    {
        public GpuMatrix()
        {
            Initialize();
        }

        protected GPGPU _Gpu;

        protected GPGPU Gpu
        {
            get
            {
                if (_Gpu == null)
                {
                    CudafyModes.Target = eGPUType.OpenCL;
                    CudafyModes.DeviceId = 0;
                    CudafyTranslator.Language = CudafyModes.Target == eGPUType.OpenCL ? eLanguage.OpenCL : eLanguage.Cuda;
                    CudafyModule km = CudafyModule.TryDeserialize();
                    if (km == null || !km.TryVerifyChecksums())
                    {
                        km = CudafyTranslator.Cudafy();
                        km.Serialize();
                    }
                    km.SourceCode = km.SourceCode.Replace("(double)", string.Empty).Replace("(float)", string.Empty);
                    _Gpu = CudafyHost.GetDevice(CudafyModes.Target, CudafyModes.DeviceId);
                    _Gpu.LoadModule(km);
                }
                return _Gpu;
            }
        }

        protected void Initialize()
        {
            var gpu = Gpu;
        }

        const int BLOCK_SIZE = 8;

        public float[,] Multiply(float[,] a, float[,] b)
        {
            var m = a.GetLength(0);
            var o = b.GetLength(1);
            var xNbBlocks = (int)Math.Ceiling((double)m / BLOCK_SIZE);
            var yNbBlocks = (int)Math.Ceiling((double)o / BLOCK_SIZE);
            var res = new float[m, o];
            var dev_a = Gpu.CopyToDevice(a);
            var dev_b = Gpu.CopyToDevice(b);
            var dev_res = Gpu.Allocate<float>(res);
            try
            {
                Gpu.Launch(new dim3(xNbBlocks, yNbBlocks), new dim3(BLOCK_SIZE, BLOCK_SIZE)).Dev_Multiply(dev_a, dev_b, dev_res);
            }
            catch (Exception ex)
            {
                Console.WriteLine("{0} x {1} * {2} x {3}", a.GetLength(0), a.GetLength(1), b.GetLength(0), b.GetLength(1));
                Console.WriteLine(ex);
            }
            Gpu.CopyFromDevice(dev_res, res);
            Gpu.FreeAll();
            return res;
        }

        [Cudafy]
        public static void oDev_Multiply(GThread thread, float[,] a, float[,] b, float[,] res)
        {
            var targetRow = thread.blockIdx.x * BLOCK_SIZE + thread.threadIdx.x;
            var targetCol = thread.blockIdx.y * BLOCK_SIZE + thread.threadIdx.y;
            var tmp = 0F;
            if (targetRow >= a.GetLength(0) || targetCol >= b.GetLength(1)) return;

            for (var k = 0; k < a.GetLength(1); k++) tmp += a[targetRow, k] * b[k, targetCol];




            res[targetRow, targetCol] = tmp;
        }

        [Cudafy]
        public static void Dev_Multiply(GThread thread, float[,] a, float[,] b, float[,] res)
        {
            var targetRow = thread.blockIdx.x * BLOCK_SIZE + thread.threadIdx.x;
            var targetCol = thread.blockIdx.y * BLOCK_SIZE + thread.threadIdx.y;
            var tmp = 0F;
            var nbBlocks = (int)Math.Ceiling((double)a.GetLength(1) / BLOCK_SIZE);
            for (var s = 0; s < nbBlocks; s++)
            {
                var aS = thread.AllocateShared<float>("aShared", BLOCK_SIZE, BLOCK_SIZE);
                var bS = thread.AllocateShared<float>("bShared", BLOCK_SIZE, BLOCK_SIZE);

                var aCurrRow = thread.blockIdx.x * BLOCK_SIZE + thread.threadIdx.x;
                var aCurrCol = s * BLOCK_SIZE + thread.threadIdx.y;
                if (aCurrRow < a.GetLength(0) && aCurrCol < a.GetLength(1))
                { aS[thread.threadIdx.x, thread.threadIdx.y] = a[aCurrRow, aCurrCol]; }
                else { aS[thread.threadIdx.x, thread.threadIdx.y] = 0F; }

                var bCurrRow = s * BLOCK_SIZE + thread.threadIdx.x;
                var bCurrCol = thread.blockIdx.y * BLOCK_SIZE + thread.threadIdx.y;
                if (bCurrRow < b.GetLength(0) && bCurrCol < b.GetLength(1))
                { bS[thread.threadIdx.x, thread.threadIdx.y] = b[bCurrRow, bCurrCol]; }
                else { bS[thread.threadIdx.x, thread.threadIdx.y] = 0F; }

                thread.SyncThreads();

                for (var k = 0; k < BLOCK_SIZE; k++) tmp += aS[thread.threadIdx.x, k] * bS[k, thread.threadIdx.y];

                thread.SyncThreads();
            }
            if (targetRow >= a.GetLength(0) || targetCol >= b.GetLength(1)) return;
            res[targetRow, targetCol] = tmp;
        }


        public float[,] Subtract(float[,] a, float[,] b)
        {
            var m = a.GetLength(0);
            var o = b.GetLength(1);
            var xNbBlocks = (int)Math.Ceiling((double)m / 32);
            var yNbBlocks = (int)Math.Ceiling((double)o / 16);
            var res = new float[m, o];
            var dev_a = Gpu.CopyToDevice(a);
            var dev_b = Gpu.CopyToDevice(b);
            var dev_res = Gpu.Allocate<float>(res);
            Gpu.Launch(new dim3(xNbBlocks, yNbBlocks), new dim3(32, 16)).Dev_Subtract(dev_a, dev_b, dev_res);
            Gpu.CopyFromDevice(dev_res, res);
            Gpu.FreeAll();
            return res;
        }

        [Cudafy]
        public static void Dev_Subtract(GThread thread, float[,] a, float[,] b, float[,] res)
        {
            var targetRow = thread.blockIdx.x * thread.blockDim.x + thread.threadIdx.x;
            var targetCol = thread.blockIdx.y * thread.blockDim.y + thread.threadIdx.y;
            if (targetRow < a.GetLength(0) && targetCol < a.GetLength(1))
            {
                res[targetRow, targetCol] = a[targetRow, targetCol] - b[targetRow, targetCol];
            }
        }

    }
}
