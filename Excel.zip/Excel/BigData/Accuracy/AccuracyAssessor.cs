﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigData
{
    public class AccuracyAssessor
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="predName">decoded file</param>
        /// <param name="yName">decoded file</param>
        /// <param name="repo"></param>
        /// <returns></returns>
        public static float GetAccuracy(string predName, string yName, IRepository repo,ILogger logger=null)
        {
            var offset = 0L; var size = long.MaxValue;
            var lastRow = offset + size;
            var firstRow = repo.Header(yName);
            var n = (long)firstRow.Length;
            var maxSize = 1000 * 1000 / n;// 1000 * 1000 / n; // We allow a 64MB array max
            var subSize = Math.Min(size, maxSize);
            var ySubData = repo.Import(yName, offset, subSize);
            var predSubData = repo.Import(predName, offset, subSize);
            if(logger!=null)
            {
                var m2 = Math.Min(ySubData.GetLength(0),10);
                var n2 = ySubData.GetLength(1); 
                var sb = new StringBuilder();
                sb.AppendLine("Pred vs Y");
                for (var i = 0; i < m2; i++)
                {
                    var y=new string[n2];var p=new string[n2];
                    for (var j = 0; j < n2; j++)
                    {
                        p[j]= predSubData[i, j];y[j]= ySubData[i, j];
                    }
                    sb.AppendLine(string.Format("{0} vs {1}",string.Join(",",p),string.Join(",",y)));
                }  
                logger.LogInfo(sb.ToString());
            }
            var m = 0L; var accuracy = 0F;
            do
            {     
                var m2 = ySubData.GetLength(0);
                var n2 = ySubData.GetLength(1);               
                for(var i=0;i<m2;i++)
                {
                    for (var j = 0; j < n2; j++)
                    {
                        m += 1;
                        if (ySubData[i, j].Equals(predSubData[i, j])) { accuracy += 1; }
                    }
                }        
                offset += subSize;
                subSize = Math.Min(subSize, lastRow - offset);
                ySubData = repo.Import(yName, offset, subSize);
                predSubData = repo.Import(predName, offset, subSize);
            } while (ySubData != null);
            accuracy = accuracy / ((float)m);            
            return accuracy;
        }
    }
}
