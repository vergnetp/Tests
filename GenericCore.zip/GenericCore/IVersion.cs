﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericCore
{
    public enum VersionStatus
    {
        Prod,
        Archived
    }

    /// <summary>
    /// Has a VersionStatus and Can cache previous versions of itself
    /// </summary>
    public interface IVersionable
    {
        VersionStatus VersionStatus { get; set; }
        List<Version> Versions { get; set; }
    }

    

}
