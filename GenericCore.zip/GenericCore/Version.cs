﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericCore
{
    public class Version
    {
        public Version(object value, string userName = "", string comment = "")
        {
            TimeStamp = DateTime.Now;
            UserName = userName;
            Comment = comment;
            Value = value;
        }
        public DateTime TimeStamp { get; set; }
        public string Comment { get; set; }
        public string UserName { get; set; }// todo: replace by object
        public object Value { get; set; }
    }
}
