﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcelDna.Integration;
using Engine;
using Models;
using Finance;

namespace ExcelEngine
{   
    

    public static class Functions
    {
        public static object[,] Convert(List<Accrual> accruals)
        {
            var res=new object[1,accruals.Count+1];
            res[0, 0] = "From:";
            res[1, 0] = "To:";
            res[2, 0] = "Amount due:";
            res[3, 0] = "Currency:";
            res[4, 0] = "Payable:";
            for (var i = 0; i < accruals.Count;i++)
            {
                res[0, i+1] = accruals[i].StartDate.ToString();
                res[1, i + 1] = accruals[i].EndDate.ToString();
                res[2, i + 1] = accruals[i].Amount;
                res[3, i + 1] = accruals[i].Currency;
                res[4, i + 1] = accruals[i].PaymentDate.ToString();
            }
            return res;
        }

        [ExcelFunction(Description = "Return the accruals due for rent.",Category="eTrack")]
        public static object[,] GetRentAccruals(double annualRent,double startDate,double endDate,double inflation)
        {
            var engine = new DefaultEngine();
            var lease = new Lease();
            lease.Property = new Property(); lease.Property.Country = new Country(); lease.Property.Country.Inflation = new Inflation() { AnnualRate = inflation };
            lease.AnnualRent = annualRent;
            lease.StartDate = DateTime.FromOADate(startDate);
            lease.EndDate = DateTime.FromOADate(endDate);           
            var accruals=engine.GetRentAccruals(lease);
            var res = Convert(accruals);
            return res;
        }
    }



}
