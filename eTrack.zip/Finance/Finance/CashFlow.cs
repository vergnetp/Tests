﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Finance
{
    public class CashFlow
    {
        public CashFlow (DateTime paymentDate,Currency currency,double amount=0.0)
        {
            this.PaymentDate = paymentDate;
            this.Currency = currency;
            this.Amount = amount;
        }
        public CashFlow(DateTime paymentDate) : this(paymentDate, Currency.Default) { }        
        public DateTime PaymentDate { get; set; }
        public double Amount { get; set; }
        public Currency Currency { get; set; }
    }
}
