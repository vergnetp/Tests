﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Finance
{
    public enum DayCount
    {
        ActAct,
        Act365,
        Act360,
        Days360
    }
    public class DateHelper
    {
        /// <summary>
        /// Excel like yearfrac 
        /// Nb. Therefore not accurate...
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="daycount"></param>
        /// <returns></returns>
        public static double Yearfrac(DateTime startDate,DateTime endDate,DayCount daycount=DayCount.ActAct)
        {
            var nbDaysInPeriod = (double)(endDate - startDate).Days;
            
            switch(daycount)
            {
                case (DayCount.Act360):
                    return nbDaysInPeriod / (double)360;
                case (DayCount.Act365):
                    return nbDaysInPeriod / (double)365;
                case (DayCount.ActAct):
                    return nbDaysInPeriod / GetActDenominator(startDate,endDate);
                case (DayCount.Days360):
                    var result = (endDate.Year - startDate.Year) * 360.0 + (endDate.Month - startDate.Month) * 30.0 + (Math.Min(endDate.Day, 30.0) - Math.Min(startDate.Day, 30.0));
                    return result/360;
                default:
                    return nbDaysInPeriod / (double)365;
            }
        }

        public static double GetActDenominator(DateTime startDate, DateTime endDate)
        {
            if (endDate.Year!=startDate.Year)
            {
                var nbDaysInPeriod = (double)(endDate - startDate).Days;
                var nbYears = (double)(endDate.Year - startDate.Year + 1);
                return nbDaysInPeriod/nbYears;
            }
            if (!DateTime.IsLeapYear(startDate.Year))
            {
                return 365.0;
            }
            var feb = new DateTime(startDate.Year, 2, 29);
            if (startDate <= feb && endDate >= feb) return 366.0;
            return 365.0;
        }
    }



}