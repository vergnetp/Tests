﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Finance
{
    public class Currency
    {
        public Currency(string currencyName) { this.Name = currencyName; }
        public string Name { get; set; }
        public static Currency Default { get { return new Currency("EUR"); } }
    }
}
