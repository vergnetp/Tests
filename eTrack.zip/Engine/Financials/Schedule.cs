﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Engine
{

    /// <summary>
    /// Collection of SheduleItem, ordered by item's dates.
    /// NB. Maybe not ordered when accessed via extension methods (Skip(), ToList()...). To be checked.
    /// </summary>
    public class Schedule:IList<ScheduleItem>
    {        
        protected List<ScheduleItem> _Schedule;
        protected bool _IsSorted = false;

        #region ctors
        public Schedule()
        {
            _Schedule = new List<ScheduleItem>();
        }
        public Schedule(List<ScheduleItem> list)
        {
            _Schedule = list;
            _IsSorted = false;
        }
        public Schedule(params DateTime[] args):this()
        {
            foreach(var date in args)
            {
                this.Add(new ScheduleItem() { Date = date });
            }
            this.Sort();
        }
        #endregion

        #region custom methods
        public static Schedule CreateEmptySchedule(DateTime startDate, DateTime endDate, Frequency frequency = Frequency.Yearly)
        {
            var result = new Schedule();
            while (startDate < endDate)
            {
                result.Add(new ScheduleItem() { Date = startDate });
                startDate = startDate.AddMonths((int)frequency);
            }
            result.Add(new ScheduleItem() { Date = endDate });
            return result;
        }

        public void Sort()
        {
            _Schedule=this.OrderBy(s => s.Date).ToList();
        }

        public static Schedule operator +(Schedule s1, Schedule s2)
        {
            if (s1 == null) return s2;
            if (s2 == null) return s1;
            var result= new Schedule(s1.Concat(s2).ToList());
            result.Sort();
            return result;
        } 

        public List<ScheduleItem> ToListOfScheduleItem() { return _Schedule; }
        
        public void Add(DateTime date)
        {
            this.Add(new ScheduleItem() { Date = date });
        }

        public void Add(DateTime date,double amount)
        {
            this.Add(new ScheduleItem() { Date = date, Item=new Item() { Value = amount } });
        }

        public void Add(DateTime date, double amount,string comment)
        {
            this.Add(new ScheduleItem() { Date = date, Item = new Item() { Value = amount ,Comment=comment} });
        }
        #endregion

        #region ICollection

        public void Add(ScheduleItem item)
        {
            _Schedule.Add(item);
            _IsSorted = false;
        }

        public void Clear()
        {
            _Schedule.Clear();
        }

        public bool Contains(ScheduleItem item)
        {
            return _Schedule.Contains(item);
        }

        public void CopyTo(ScheduleItem[] array, int arrayIndex)
        {
            _Schedule.CopyTo(array,arrayIndex);
        }

        public int Count
        {
            get { return _Schedule.Count; }
        }

        public bool IsReadOnly
        {
            get { return false; }
        }

        public bool Remove(ScheduleItem item)
        {
            return _Schedule.Remove(item);
        }

        public IEnumerator<ScheduleItem> GetEnumerator()
        {
            if (_IsSorted == false)
            {
                _Schedule.OrderBy(s => s.Date);
                _IsSorted = true;
            }
            return _Schedule.GetEnumerator();
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            if (_IsSorted == false)
            {
                _Schedule.OrderBy(s => s.Date);
                _IsSorted = true;
            }
            return _Schedule.GetEnumerator();
        }
        #endregion

        #region IList
        public int IndexOf(ScheduleItem item)
        {
            return _Schedule.IndexOf(item);
        }

        public void Insert(int index, ScheduleItem item)
        {
            _Schedule.Insert(index,item);
        }

        public void RemoveAt(int index)
        {
            _Schedule.RemoveAt(index);
        }

        public ScheduleItem this[int index]
        {
            get
            {
                return _Schedule[index];
            }
            set
            {
                _Schedule[index]=value;
            }
        }
        #endregion
    }
}