﻿
using Finance;
using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Engine
{
    public class DefaultEngine
    {
        public List<Accrual> GetServiceChargeIncomeAccruals(ServiceCharge sc)
        {
            var baseAmount = sc.AnnualAmount;
            var inflation = sc.Property.Country.Inflation.AnnualRate;
            var startDate = sc.StartDate;
            var endDate = sc.EndDate;
            Schedule levelSchedule = null;
            var leases = GetForecastedLeases(sc.Property);
            foreach (var lease in leases)
            {
                var currentLeaseRecoverabilitySchedule = this.GetRecoverabilitySchedule(lease); ;
                levelSchedule = levelSchedule + currentLeaseRecoverabilitySchedule;
            }
            var accruals = AccrualsFactory.GenerateAnnualInflatedFlat(startDate, endDate, baseAmount, inflation);
            var result = AccrualsFactory.ApplyLevelScheduleToAccruals(levelSchedule, accruals);
            return result;
        }

        public Schedule GetRecoverabilitySchedule(Lease lease)
        {
            var result = new Schedule(lease.StartDate, lease.EndDate);
            var recoverability = 0.0;
            foreach (var unit in lease.Units)
            {
                recoverability += unit.Area / lease.Property.Area;
            }
            result.First().Item.Value = recoverability * lease.Recoverability;
            return result;
        }

        public List<Accrual> GetServiceChargeAccruals(ServiceCharge serviceCharge)
        {
            var baseAmount = -serviceCharge.AnnualAmount;
            var inflation = serviceCharge.Property.Country.Inflation.AnnualRate;
            var startDate = serviceCharge.StartDate;
            var endDate = serviceCharge.EndDate;
            var result = AccrualsFactory.GenerateAnnualInflatedFlat(startDate, endDate, baseAmount, inflation);
            return result;
        }

        public List<Accrual> GetRentAccruals(Lease lease)
        {
            var baseRent = lease.AnnualRent;
            var inflation = lease.Property.Country.Inflation.AnnualRate;
            var startDate = lease.StartDate;
            var endDate = lease.EndDate;
            var result = AccrualsFactory.GenerateAnnualInflatedFlat(startDate, endDate, baseRent, inflation);
            return result;
        }



        public List<Lease> GetForecastedLeases(Property property)
        {
            var result = new List<Lease>(property.Leases);
            var vacancyTime = property.VacancyTime;
            foreach (var lease in property.Leases)
            {
                if (lease.EndDate < property.EndDate)
                {
                    var newStartDate = lease.EndDate.AddMonths((int)vacancyTime);
                    var newBaseRent = lease.AnnualRent;// todo inflation
                    var newLease = new Lease();
                    newLease.AnnualRent = newBaseRent;
                    newLease.StartDate = newStartDate;
                    newLease.Property = property;
                    newLease.Name = "Potential Lease";
                    newLease.Recoverability = lease.Recoverability;
                    newLease.Units = lease.Units;
                    result.Add(newLease);
                }
            }
            return result;
        }


    }
}