﻿using Finance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Engine
{
    public class AccrualsFactory
    {
        public static List<Accrual> GenerateAnnualFlat(DateTime start,DateTime end,double annualAmount)
        {
            return GenerateAnnualInflatedFlat(start, end, annualAmount, 0.0);
        }

        public static List<Accrual> GenerateAnnualInflatedFlat(DateTime start, DateTime end, double annualAmount,double inflationRate)
        {
            var list = new List<Accrual>();
            var result = Schedule.CreateEmptySchedule(start,end);            
            for(var i=0;i<result.Count-1;i++)
            {               
                var amount= annualAmount * Math.Pow(1 + inflationRate, i);
                var accrual = new Accrual(result[i].Date, result[i+1].Date, amount);
                list.Add(accrual);
            }            
            return list;
        }       

        public static List<Accrual> ApplyLevelScheduleToAccruals(Schedule levelSchedule,List<Accrual> accruals)
        {
            if (levelSchedule == null) return accruals;
            if (accruals == null) return null;
            var result = new List<Accrual>();
            for (var i = 0; i < accruals.Count ; i++)
            {
                var amount = accruals[i].Amount;
                var currentDate = accruals[i].StartDate;
                var nextDate = accruals[i ].EndDate;
                var leveledAmount = 0.0;

                // no level before nextDate (all after):
                if (levelSchedule.First().Date >= nextDate)
                {
                    leveledAmount = amount;
                    result.Add(new Accrual(currentDate, nextDate,leveledAmount));
                    continue;
                }
                // no level after currentDate (all before):
                if (levelSchedule.Last().Date<=currentDate)
                {
                    leveledAmount = amount * levelSchedule.Last().Item.Value;
                    result.Add(new Accrual(currentDate, nextDate, leveledAmount));
                    continue;
                }
                // Some inbetween:
                var lastPreviousLevel = levelSchedule.Where(s => s.Date <= currentDate).LastOrDefault();                
                var inBetweenLevels = new Schedule(levelSchedule.Where(s => s.Date >= currentDate && s.Date <= nextDate).ToList());
                inBetweenLevels.Add(currentDate, lastPreviousLevel == null ? 0.0 : lastPreviousLevel.Item.Value);
                inBetweenLevels.Add(nextDate, 0.0);
                inBetweenLevels.Sort();
                var nbDays = (inBetweenLevels.Last().Date - inBetweenLevels.First().Date).Days;                
                for (var j=0;j<inBetweenLevels.Count-1;j++)
                {
                    var level = inBetweenLevels[j].Item.Value;
                    double prorata = ((double)(inBetweenLevels[j + 1].Date - inBetweenLevels[j].Date).Days) / nbDays;
                    leveledAmount = amount * level * prorata;
                    result.Add(new Accrual(inBetweenLevels[j].Date, inBetweenLevels[j + 1].Date, leveledAmount));
                }
                              
            }
            return result;
        }


    }
}