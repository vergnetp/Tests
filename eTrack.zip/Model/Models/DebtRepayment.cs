﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Models
{

    /// <summary>
    /// Debt Repayment. Expect a positive amount.
    /// </summary>
    public class DebtRepayment:IEntity
    {
        public int Id { get; set; }
        public string Name { get; set; }
        private DateTime _Date;
        public DateTime Date { get { if (_Date == DateTime.MinValue) { return DateTime.Now; } else { return _Date; } } set { _Date = value; } }
        public double Amount { get; set; }

        [Required]
        public virtual Debt Debt{get;set;}
        public virtual User User { get; set; }
    
    }
}