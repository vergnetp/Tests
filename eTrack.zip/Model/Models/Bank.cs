﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Models
{
    public class Bank:IEntity
    {
        public Bank() { Debts = new List<Debt>(); }
        public int Id { get; set; }
        public string Name { get; set; }

        public virtual List<Debt> Debts { get; set; }

        [Required]
        public virtual User User { get; set; }
    }
}