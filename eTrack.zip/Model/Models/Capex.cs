﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Models
{
    public class Capex:IEntity
    {
        public int Id { get; set; }
        public string Name { get; set;}

        private DateTime _Date;
        [DataType(DataType.Date)]
        [Display(Name = "Payment Date")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime PaymentDate { get { if (_Date == DateTime.MinValue) { return Property.StartDate; } else { return _Date; } } set { _Date = value; } }
        public double Amount { get; set; }

        [Required]
        public virtual Property Property { get; set; }
        public virtual User User { get; set; }
    }
}