﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Web.Mvc;

namespace Models
{
    public class Inflation : IEntity
    {
        public Inflation() { this.Countrys = new List<Country>(); }
      
        public int Id { get; set; }     
        public string Name { get; set; }

        [DisplayFormat(DataFormatString = "{0:P2}", ApplyFormatInEditMode = true)]   
        public double AnnualRate { get; set; }

        [Required]
        public virtual List<Country> Countrys { get; set; }
        [Required]
        [HiddenInput(DisplayValue = false)]
        public virtual User User { get; set; }
    }

    public class Country:IEntity
    {        
        [HiddenInput(DisplayValue = false)]
        public int Id { get; set; }     
        public string Name { get; set; }

        private string _FullName;
        public string FullName { get { if (_FullName == null) { return Name; } else { return _FullName; } } set { _FullName = value; } }
        
        public virtual Inflation Inflation { get; set; }
        [Required]
        [HiddenInput(DisplayValue = false)]
        public virtual User User { get; set; }
        //public virtual List<Property> Propertys { get; set; }
    }
}