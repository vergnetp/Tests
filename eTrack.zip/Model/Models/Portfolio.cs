﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Models
{
    public class Portfolio:IEntity
    {
        public Portfolio() { Propertys = new List<Property>(); }
        public int Id { get; set; }
        public string Name { get; set; }

        private DateTime _StartDate = DateTime.Now;
        [DataType(DataType.Date)]
        [Display(Name = "Start Date")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Remote("PortfolioStartDate", "Validator", HttpMethod = "Post", AdditionalFields = "Id")]
        public DateTime StartDate { get { return _StartDate; } set { _StartDate = value; } }

        private DateTime _EndDate;
        [DataType(DataType.Date)]
        [Display(Name = "End Date")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Remote("PortfolioEndDate", "Validator", HttpMethod = "Post", AdditionalFields = "Id")]
        public DateTime EndDate { get { if (_EndDate == DateTime.MinValue) { return this.StartDate.AddYears(5); } else { return _EndDate; } } set { _EndDate = value; } }
        

        public virtual List<Property> Propertys { get; set; }

        [Required]
        [HiddenInput(DisplayValue = false)]
        public virtual User User { get; set; }     
    }
}