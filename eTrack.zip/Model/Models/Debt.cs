﻿using Finance;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Models
{
    public class Debt:IEntity
    {
        public Debt() { DebtRepayments=new List<DebtRepayment>(); }
        public int Id { get; set; }
        public string Name { get; set; }

        private DateTime _StartDate;
        [DataType(DataType.Date)]
        [Display(Name = "Start Date")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Remote("UnitStartDate", "Validator", HttpMethod = "Post", AdditionalFields = "Id")]
        public DateTime StartDate { get { if (_StartDate == DateTime.MinValue) { if (this.Property == null) { return DateTime.Now; } else { return this.Property.StartDate; } } else { return _StartDate; } } set { _StartDate = value; } }

        private DateTime _EndDate;
        [DataType(DataType.Date)]
        [Display(Name = "End Date")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Remote("UnitEndDate", "Validator", HttpMethod = "Post", AdditionalFields = "Id")]
        public DateTime EndDate { get { if (_EndDate == DateTime.MinValue) { if (this.Property == null) { return this.StartDate.AddYears(5); } else { return this.Property.EndDate; } } else { return _EndDate; } } set { _EndDate = value; } }

        public DayCount Daycount { get; set; }

        public double Margin { get; set; }
        public double Notional { get; set; }

        public virtual List<DebtRepayment> DebtRepayments { get; set; }

        [Required]
        public virtual Property Property { get; set; }
        public virtual Interest Interest { get; set; }
        public virtual Bank Bank { get; set; }

        public virtual User User { get; set; }

        public double GetOutstandingDebt(DateTime date)
        {
            var result = this.Notional;
            var pastRepaymenst = this.DebtRepayments.Where(d => d.Date <= date);
            var totalRepayments = pastRepaymenst.Sum(d => d.Amount);
            result -= totalRepayments;
            return result;
        }

    }
}