﻿using Finance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Engine
{
    public interface IFxConverter
    {
        double GetFXRate(DateTime date, Currency source, Currency destination);
    }
    public class DefaultFxConverter : IFxConverter
    {
        public double GetFXRate(DateTime date, Currency source, Currency destination) { return 1.0; }
    }
    public class Reporter
    {
        private DateTime _StartDate;
        private DateTime _EndDate;
        private Frequency _Frequency;
        private Currency _Currency;
        private IFxConverter _FxConverter=new DefaultFxConverter();

        public Reporter(DateTime startDate, DateTime endDate, Currency currency, Frequency frequency = Frequency.Yearly, IFxConverter fxConverter = null)
        {
            _StartDate = startDate; _EndDate = endDate; _Frequency = frequency; _Currency = currency;
            _FxConverter = fxConverter==null?new DefaultFxConverter():fxConverter;
        }
        public Reporter(DateTime startDate, DateTime endDate, Frequency frequency = Frequency.Yearly)
        {
            _StartDate = startDate; _EndDate = endDate; _Frequency = frequency; _Currency = Currency.Default;
            _FxConverter = new DefaultFxConverter();
        }

        /// <summary>
        /// List of cashflows paid between the previous item's date and the current one.   
        /// </summary>
        /// <param name="cashFlows"></param>
        /// <returns></returns>
        public Schedule ReportCashFlows(List<CashFlow> cashFlows)
        {
            var result = Schedule.CreateEmptySchedule(_StartDate, _EndDate, _Frequency);
            cashFlows.OrderBy(c => c.PaymentDate);
            var startDate = _StartDate.AddDays(-1);
            result.RemoveAt(0);
            foreach(var endPeriodItem in result)
            {
                var cumulatedCashFlow=cashFlows.Where(c=>c.PaymentDate>startDate && c.PaymentDate<=endPeriodItem.Date).Sum(c=>c.Amount*_FxConverter.GetFXRate(c.PaymentDate,c.Currency,_Currency));
                endPeriodItem.Item = new Item() { Value = cumulatedCashFlow };
                startDate = endPeriodItem.Date;
            }
            return result;
        }

        public double CalculateAccrual(List<Accrual> accruals, DateTime start, DateTime end, DayCount dayCount)
        {
            var result = 0.0;
            // accruals null or empty
            if (accruals == null || !accruals.Any()) return 0.0;
            // accruals start after
            if (accruals.First().StartDate > end) return 0.0;
            // accruals start and finish in the middle
            if (accruals.First().StartDate > start && accruals.Last().EndDate < end) return accruals.Sum(a => a.Amount);            
            // Else:
            for (int i = 0; i < accruals.Count;i++)
            {
                var accruedAmount = 0.0;
                if (accruals[i].StartDate <= start && accruals[i ].EndDate > start && accruals[i ].EndDate<=end)
                {
                    accruedAmount = accruals[i].Amount * _FxConverter.GetFXRate(accruals[i].PaymentDate, accruals[i].Currency,_Currency) * DateHelper.Yearfrac(start, accruals[i].EndDate, dayCount);
                }
                if (accruals[i].StartDate <= start && accruals[i ].EndDate > start && accruals[i ].EndDate >end)
                {
                    accruedAmount = accruals[i].Amount * _FxConverter.GetFXRate(accruals[i].PaymentDate, accruals[i].Currency, _Currency) * DateHelper.Yearfrac(start, end, dayCount);
                }
                if (accruals[i].StartDate>start && accruals[i].EndDate<=end)
                {
                    accruedAmount = accruals[i].Amount * _FxConverter.GetFXRate(accruals[i].PaymentDate, accruals[i].Currency, _Currency);
                }
                if (accruals[i].StartDate > start && accruals[i].StartDate <=end && accruals[i].EndDate > end)
                {
                    accruedAmount = accruals[i].Amount * _FxConverter.GetFXRate(accruals[i].PaymentDate, accruals[i].Currency, _Currency) * DateHelper.Yearfrac(accruals[i].StartDate, end, dayCount);
                }
                result += accruedAmount;
            }       
            return result;
        }

        /// <summary>
        /// List of amounts accrued.
         /// </summary>
        /// <param name="accruals"></param>
        /// <param name="start"></param>
        /// <param name="end"></param>
        /// <param name="dayCount"></param>
        /// <returns></returns>
        public Schedule ReportAccruals(List<Accrual> accruals, DayCount dayCount)
        {            
            var result = Schedule.CreateEmptySchedule(_StartDate, _EndDate, _Frequency);
            accruals.OrderBy(a => a.StartDate);
            for(var i=0;i<result.Count-1;i++)
            {
                var accruedAmount = this.CalculateAccrual(accruals, result[i].Date, result[i+1].Date, dayCount);  
                result[i].Item = new Item() { Value = accruedAmount };                
            }
            result.RemoveAt(result.Count-1);
            return result;
        }
    }
}