﻿
//using Finance;
//using Models;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Web;

//namespace Engine
//{
//    /// <summary>
//    /// Generate list of accruals or cashflows
//    /// </summary>
//    public class DefaultEngine
//    {
//        public List<CashFlow> GetDebtChange(Debt debt)
//        {
//            var startDate = debt.StartDate;
//            var endDate = debt.EndDate;
//            var cfs = new List<CashFlow>();
//            foreach (var rep in debt.DebtDrawdowns)
//            {
//                var cf = new CashFlow(rep.PaymentDate, rep.Currency, rep.Amount);
//                cfs.Add(cf);
//            }
//            var outstandingDebt = debt.GetOutstandingDebt(endDate);
//            cfs.Add(new CashFlow(endDate, debt.Currency, -outstandingDebt));
//            cfs.OrderBy(s => s.PaymentDate).ToList();
//            return cfs;
//        }

//        public List<CashFlow> GetDebtAmortiation(Debt debt)
//        {
//            var startDate = debt.StartDate;
//            var endDate = debt.EndDate;
//            var cfs = new List<CashFlow>();
//            foreach (var amo in debt.DebtAmortizations)
//            {
//                var cf = new CashFlow(amo.PaymentDate, amo.Currency, amo.Amount);
//                cfs.Add(cf);
//            }           
//            cfs.OrderBy(s => s.PaymentDate).ToList();
//            return cfs;
//        }

//        public List<Accrual> GetDebtInterest(Debt debt)
//        {
//            var interestsDue = new Schedule();
//            foreach(var interest in debt.Interests)
//            {
//                var accruals = new List<Accrual>();
//                accruals.Add(new Accrual(interest.StartDate, interest.EndDate, interest.AnnualRate) { PaymentDate = interest.PaymentDate, Currency = debt.Currency });
//                var reporter = new Reporter(interest.StartDate, interest.EndDate, interest.Frequency);
//                interestsDue+=reporter.ReportAccruals(accruals, interest.DayCount);
//            }
//            foreach(var interest in interestsDue)
//            {
//                var notional=debt.GetOutstandingDebt(interest.Date);
//                var rate = interest.Item.Value;
//                interest.Item.Value = notional * rate;
//            }
//            return interestsDue.ToList();
//        }

//        public List<Accrual> GetServiceChargeIncomeAccruals(ServiceCharge sc)
//        {
//            var baseAmount = sc.AnnualAmount;
//            var inflation = sc.Property.Country.Inflations.First().AnnualRate;
//            var startDate = sc.StartDate;
//            var endDate = sc.EndDate;
//            Schedule levelSchedule = null;
//            var leases = GetForecastedLeases(sc.Property);
//            foreach (var lease in leases)
//            {
//                var currentLeaseRecoverabilitySchedule = this.GetRecoverabilitySchedule(lease); ;
//                levelSchedule = levelSchedule + currentLeaseRecoverabilitySchedule;
//            }
//            var accruals = AccrualsFactory.GenerateAnnualInflatedFlat(startDate, endDate, baseAmount, inflation, sc.Currency);
//            var result = AccrualsFactory.ApplyLevelScheduleToAccruals(levelSchedule, accruals, sc.Currency);
//            return result;
//        }

//        public Schedule GetRecoverabilitySchedule(Lease lease)
//        {
//            var result = new Schedule(lease.StartDate, lease.EndDate);
//            var recoverability = 0.0;
//            foreach (var unit in lease.Units)
//            {
//                recoverability += unit.Area / lease.Property.Area;
//            }
//            result.First().Item.Value = recoverability * lease.Recoverability;
//            return result;
//        }

//        public List<Accrual> GetServiceChargeAccruals(ServiceCharge serviceCharge)
//        {
//            var baseAmount = -serviceCharge.AnnualAmount;
//            var inflation = serviceCharge.Property.Country.Inflations.First().AnnualRate;
//            var startDate = serviceCharge.StartDate;
//            var endDate = serviceCharge.EndDate;
//            var result = AccrualsFactory.GenerateAnnualInflatedFlat(startDate, endDate, baseAmount, inflation, serviceCharge.Currency);
//            return result;
//        }

//        public List<Accrual> GetRentAccruals(Lease lease)
//        {
//            var baseRent = lease.AnnualRent;
//            var inflation = lease.Property.Country.Inflations.First().AnnualRate;
//            var startDate = lease.StartDate;
//            var endDate = lease.EndDate;
//            var currency = lease.Currency;
//            var result = AccrualsFactory.GenerateAnnualInflatedFlat(startDate, endDate, baseRent, inflation, currency);
//            return result;
//        }

//        public List<Accrual> GetOtherIncomeAccruals(OtherIncome otherIncome)
//        {
//            var baseAmount = otherIncome.Amount;
//            var inflation = otherIncome.Property.Country.Inflations.First().AnnualRate;
//            var startDate = otherIncome.StartDate;
//            var endDate = otherIncome.EndDate;
//            var result = AccrualsFactory.GenerateAnnualInflatedFlat(startDate, endDate, baseAmount, inflation,otherIncome.Currency);
//            return result;
//        }

//        public List<Accrual> GetCorporateCostAccruals(CorporateCost corporateCost)
//        {
//            var baseAmount = -corporateCost.Amount;
//            var inflation = corporateCost.Property.Country.Inflations.First().AnnualRate;
//            var startDate = corporateCost.StartDate;
//            var endDate = corporateCost.EndDate;
//            var result = AccrualsFactory.GenerateAnnualInflatedFlat(startDate, endDate, baseAmount, inflation,corporateCost.Currency);
//            return result;
//        }

//        public List<Lease> GetForecastedLeases(Property property)
//        {
//            var result = new List<Lease>(property.Leases);
//            var vacancyTime = property.VacancyTime;
//            foreach (var lease in property.Leases)
//            {
//                if (lease.EndDate < property.EndDate)
//                {
//                    var newStartDate = lease.EndDate.AddMonths((int)vacancyTime);
//                    var newBaseRent = lease.AnnualRent;// todo inflation
//                    var newLease = new Lease();
//                    newLease.AnnualRent = newBaseRent;
//                    newLease.StartDate = newStartDate;
//                    newLease.Property = property;
//                    newLease.Name = "Potential Lease";
//                    newLease.Recoverability = lease.Recoverability;
//                    newLease.Units = lease.Units;
//                    result.Add(newLease);
//                }
//            }
//            return result;
//        }

//        public double GetExitPrice(Property property, IFxConverter fxConverter, Currency destinationCurrency)
//        {
//            var res = 0.0;
//            foreach (var u in property.Units)
//            {
//                var accruals = AccrualsFactory.GenerateAnnualInflatedFlat(u.StartDate, u.EndDate, u.MarketRent * u.Area, property.Country.Inflations.First().AnnualRate,property.ExitPriceCurrency);
//                var inflatedMarketRent = u.MarketRent * u.Area;
//                if (accruals.Count > 1)
//                {
//                    inflatedMarketRent = accruals[accruals.Count - 2].Amount;
//                }
//                res += inflatedMarketRent * fxConverter.GetFXRate(u.EndDate, u.Currency, destinationCurrency);
//            }
//            res /= property.ExitYield;
//            return res;
//        }
//        public double GetExitYield(Property property, IFxConverter fxConverter, Currency destinationCurrency)
//        {
//            var res = 0.0;
//            foreach (var u in property.Units)
//            {
//                var accruals = AccrualsFactory.GenerateAnnualInflatedFlat(u.StartDate, u.EndDate, u.MarketRent * u.Area, property.Country.Inflations.First().AnnualRate,property.ExitPriceCurrency);
//                var inflatedMarketRent = u.MarketRent * u.Area;
//                if (accruals.Count > 1)
//                {
//                    inflatedMarketRent = accruals[accruals.Count - 2].Amount;
//                }
//                res += inflatedMarketRent * fxConverter.GetFXRate(u.EndDate, u.Currency, destinationCurrency);
//            }
//            res /= property.ExitPrice;
//            return res;
//        }
//    }
//}