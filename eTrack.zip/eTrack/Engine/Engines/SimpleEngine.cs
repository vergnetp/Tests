﻿using Finance;
using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine
{
    public class SimpleEngine : DefaultEngine
    {

        public List<Accrual> GetServiceChargeIncomeAccruals(ServiceCharge serviceCharge, double rec)
        {
            var baseAmount = serviceCharge.AnnualAmount * rec;
            var inflation = serviceCharge.Property.Country.Inflation.AnnualRate;
            var startDate = serviceCharge.StartDate;
            var endDate = serviceCharge.EndDate;
            var result = AccrualsFactory.GenerateAnnualInflatedFlat(startDate, endDate, baseAmount, inflation, serviceCharge.Currency);
            return result;
        }
    }


}
