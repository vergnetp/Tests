﻿using Finance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    public class AnnualRateGenerator
    {
        public double AnnualRate;
        public DateTime AsAt;
        public int? RateFreePeriod; // todo: make it daily basis and check model can evolve
        public Inflation Inflation;
        public Scheduler RevisionScheduler;
        public bool IsRevisionUpwardOnly;
        public double? RevisionCap;
        public Schedule AnnualRates;

        public void RefreshRates()
        {
            var entity = this;
            var schedule = entity.RevisionScheduler.Schedule;
            var endRateFreePeriod = entity.RevisionScheduler.StartDate;
            if (entity.RateFreePeriod != null)
            {
                endRateFreePeriod = entity.RevisionScheduler.StartDate.AddMonths(entity.RateFreePeriod.Value);
                for (var i = 0; i < schedule.Count - 1; i++)
                {
                    if (schedule[i].Date <= endRateFreePeriod && schedule[i + 1].Date >= endRateFreePeriod)
                    {
                        var item = new ScheduleItem(endRateFreePeriod, 0.0);
                        item.Item.IsOverriden = true;
                        item.Item.Comment += "End of rate free period; ";
                        // We insert only if not already inserted:
                        if (schedule[i + 1].Date != endRateFreePeriod)
                        {
                            schedule.Insert(i + 1, item);
                        }
                        break;
                    }
                }
            }
            var nearestIndex = schedule.FindFirstIndex(entity.AsAt);
            schedule[nearestIndex].Item.Value = entity.AnnualRate;
            // Pass forward:
            for (var i = nearestIndex + 1; i < schedule.Count; i++)
            {               
                if (schedule[i].Date >= entity.RevisionScheduler.FirstPeriodEndDate && schedule[i].Item.Comment.StartsWith("Revision"))
                {
                    var j = i;
                    for (j = i - 1; j >= 0; j--)
                    {
                        if (schedule[j].Item.Comment.StartsWith("Revision")) break;
                    }
                    var inflationRate = Inflation == null ? 0.0 : Inflation.GetInflation(schedule[j].Date, schedule[i].Date);
                    if (inflationRate < 0 && entity.IsRevisionUpwardOnly) inflationRate = 0.0;
                    if (entity.RevisionCap != null && inflationRate > entity.RevisionCap.Value) inflationRate = entity.RevisionCap.Value;
                    schedule[i].Item.Value = schedule[i - 1].Item.Value * (1.0 + inflationRate);
                    schedule[i].Item.Comment += string.Format("Inflation ({0:#,##0.00} * {1:0.0000}); ", schedule[i - 1].Item.Value, 1.0 + inflationRate);
                }
                else
                {
                    schedule[i].Item.Value = schedule[i - 1].Item.Value;
                    schedule[i].Item.Comment += string.Format("No rate change (still {0:#,##0.00}); ", schedule[i - 1].Item.Value);
                }
            }            
            // Pass backward:
            for (var i = nearestIndex; i > 0; i--)
            {                
                if (schedule[i].Date >= entity.RevisionScheduler.FirstPeriodEndDate && schedule[i].Item.Comment.StartsWith("Revision"))
                {
                    var j = i;
                    for (j = i + 1; j >= schedule.Count; j++)
                    {
                        if (schedule[j].Item.Comment.StartsWith("Revision")) break;
                    }
                    var inflationRate = Inflation == null ? 0.0 : Inflation.GetInflation(schedule[i - 1].Date, schedule[j].Date);
                    if (inflationRate < 0 && entity.IsRevisionUpwardOnly) inflationRate = 0.0;
                    if (entity.RevisionCap != null && inflationRate > entity.RevisionCap.Value) inflationRate = entity.RevisionCap.Value;
                    schedule[i - 1].Item.Value = schedule[i].Item.Value * (1.0 - inflationRate);
                    schedule[i].Item.Comment += string.Format("Inflation ({0:#,##0.00} * {1:0.0000}); ", schedule[i].Item.Value, 1.0 - inflationRate);
                }
                else
                {
                    schedule[i - 1].Item.Value = schedule[i].Item.Value;
                    schedule[i].Item.Comment += string.Format("No rate change (still {0:#,##0.00}); ", schedule[i].Item.Value);

                }                
            }
            for (var i = 0; i < schedule.Count; i++)
            {
                if (schedule[i].Date >= entity.RevisionScheduler.StartDate && schedule[i].Date < endRateFreePeriod)
                {
                    schedule[i].Item.Value = 0.0;
                    schedule[i].Item.Comment += "Within rate free period so rate of 0; ";
                }
            }            
            AnnualRates = schedule;
        }
     

    }
}
