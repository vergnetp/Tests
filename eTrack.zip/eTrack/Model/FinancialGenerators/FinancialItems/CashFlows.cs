﻿using Finance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{


    /// <summary>
    /// Encapsulate a List<CashFlow> called Values.
    /// Can be entered directly from scratch by a user.
    /// Alternatively, the user can call the Reset function to create an empty schedule and work on it.
    /// </summary>
    public class CashFlows: Entity
    {
        public CashFlows(int id, string name, string description = "") : base(id, name, description) { }

        public void Reset(DateTime startDate,DateTime endDate,Currency currency=null,           
            DateTime? paymentFirstPeriodEndDate=null,
            int paymentPeriodMultiplier=0,FrequencyPeriod paymentPeriod=FrequencyPeriod.D,RollConvention paymentRollConvention=RollConvention.EOM,
            BusinessDayConvention paymentBusinessDayConvention = BusinessDayConvention.NONE, List<string> paymentBusinessCenters = null
            )
        {            
            // Parent? public virtual Company Company{get;set;}           
            if (paymentFirstPeriodEndDate == null) paymentFirstPeriodEndDate = new DateTime(startDate.Year + 1, 1, 1);
            this._CashFlowGenerator = new StandaloneCashFlowGenerator();
            this._CashFlowGenerator.PaymentScheduler=new Scheduler();
            this._CashFlowGenerator.PaymentScheduler.StartDate=startDate;
            this._CashFlowGenerator.PaymentScheduler.EndDate=endDate;
            this._CashFlowGenerator.PaymentScheduler.FirstPeriodEndDate=paymentFirstPeriodEndDate.Value;
            this._CashFlowGenerator.PaymentScheduler.FrequencyPeriodMultiplier=paymentPeriodMultiplier;
            this._CashFlowGenerator.PaymentScheduler.FrequencyPeriod=paymentPeriod;
            this._CashFlowGenerator.PaymentScheduler.RollConvention=paymentRollConvention;
            this._CashFlowGenerator.PaymentScheduler.BusinessDayAdjuster=new BusinessDayAdjuster();
            this._CashFlowGenerator.PaymentScheduler.BusinessDayAdjuster.BusinessDayConvention=paymentBusinessDayConvention;
            this._CashFlowGenerator.PaymentScheduler.BusinessDayAdjuster.BusinessCenters=paymentBusinessCenters;
            _CashFlowGenerator.PaymentScheduler.GenerateSchedule();
            this.Values = _CashFlowGenerator.PaymentScheduler.Schedule.ToCashFlows(currency);
         }

        protected StandaloneCashFlowGenerator _CashFlowGenerator { get; private set; }
        public List<CashFlow> Values { get { return this._CashFlowGenerator.CashFlows; } set { this._CashFlowGenerator.CashFlows=value;} }
    }
}
