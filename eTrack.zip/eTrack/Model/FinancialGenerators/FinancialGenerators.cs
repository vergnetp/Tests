﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Finance;
using Models;

namespace Models
{       
    
    #region EntityWithXXX

    public class AccrualGeneration
    {
        public static Accruals Choose(bool directPopulation = false, bool recurring = true, bool annualRates = true, bool perSqm = false, bool percent = false, bool onLevels = false, bool onAccruals = false)
        {
            //if (directPopulation) return new Accruals();
            //if (!recurring) return new Accruals();
            //if (annualRates && !perSqm) return new AccrualsFromAnnualRates();
            //if (annualRates && perSqm) return new EntityWithAnnualRatePerSqm();
            //if (!annualRates && perSqm) return new Accruals(); // todo: fees per sqm
            //if (percent && onLevels) return new EntityWithReccuringFeesOnLevelsGenerator();
            //if (percent && onAccruals) return new EntityWithReccuringFeesOnAccrualsGenerator();
            //return new Accruals();
            return null;
        }
    }

    public class EntityWithAnnualRatePerSqm : Accruals
    {
        public EntityWithAnnualRatePerSqm(int id, string name, string description = "") : base(id, name, description) { }
        
        public AnnualRatePerSqmGenerator AnnualRatePerSqmGenerator;
    }

    public class EntityWithReccuringFeesOnLevelsGenerator : Accruals
    {
        public EntityWithReccuringFeesOnLevelsGenerator(int id, string name, string description = "") : base(id, name, description) { }
       
        public ReccuringFeesOnLevelsGenerator ReccuringFeesOnLevelsGenerator;
    }

    public class EntityWithReccuringFeesOnAccrualsGenerator : Accruals
    {
        public EntityWithReccuringFeesOnAccrualsGenerator(int id, string name, string description = "") : base(id, name, description) { }
       
        public RecurringFeesOnAccrualsGenerator RecurringFeesOnAccrualsGenerator;
    }

    #endregion
  

    #region Different fees/charge/income/cashflow Generators

    // Legal, refurbishment, rediger fiscal
    // Late payment penalty, prepayment penalty...
    public class ContingentGenerator
    {
        // todo
    }

    // Utilities
    public class AnnualRatePerSqmGenerator : AnnualRateGenerator
    {
        public double AnnualRatePerSqm;
        public Unit Unit;        
    }    

    // Admin fees, Asset Management fees, interest?
    public class ReccuringFeesOnLevelsGenerator
    {
        public Scheduler AccrualScheduler;
        public Schedule Fees;
        // Propert Value, Outstanding Equity
        public Schedule Base;
        public List<Accrual> Accruals; 
    }

    // Turnover rent, tax, property management fees
    public class RecurringFeesOnAccrualsGenerator
    {
        public Scheduler AccrualScheduler;
        public Schedule Fees;
        // Turnover, Taxable profit...
        public List<Accrual> Base;
        public List<Accrual> Accruals;
    }

    #endregion

}
