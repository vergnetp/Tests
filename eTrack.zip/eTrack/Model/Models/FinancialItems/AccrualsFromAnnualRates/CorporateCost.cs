﻿using Finance;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Models
{
    public class CorporateCost : IEntity
    {
        public int Id { get; set; }
        public string Name { get; set; }

        private DateTime _StartDate;
        [DataType(DataType.Date)]
        [Display(Name = "Start Date")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Remote("UnitStartDate", "Validator", HttpMethod = "Post", AdditionalFields = "Id")]
        public DateTime StartDate
        {
            get
            {
                if (_StartDate == DateTime.MinValue)
                {
                    if (this.Property == null)
                    { return DateTime.Now; }
                    else
                    {
                        return this.Property.StartDate;
                    }
                }
                else { return _StartDate; }
            }
            set { _StartDate = value; }
        }

        private DateTime _EndDate;
        [DataType(DataType.Date)]
        [Display(Name = "End Date")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Remote("UnitEndDate", "Validator", HttpMethod = "Post", AdditionalFields = "Id")]
        public DateTime EndDate { get { if (_EndDate == DateTime.MinValue) { if (this.Property == null) { return this.StartDate.AddYears(5); } else { return this.Property.EndDate; } } else { return _EndDate; } } set { _EndDate = value; } }

        private DateTime _PaymentDate;
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime PaymentDate { get { if (_EndDate == DateTime.MinValue) { return this.EndDate; } else { return _PaymentDate; } } set { _PaymentDate = value; } }


        [DisplayFormat(DataFormatString = "{0:0,0}", ApplyFormatInEditMode = true)]
        public double Amount { get; set; }
        public Currency Currency { get; set; }
        public string Comment { get; set; }

        [Required]
        public virtual Property Property { get; set; }
        public virtual User User { get; set; }
    }
}