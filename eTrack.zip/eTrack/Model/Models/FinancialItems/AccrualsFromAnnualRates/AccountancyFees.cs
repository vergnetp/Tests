﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    public class AccountancyFees:AccrualsFromAnnualRates
    {
        public AccountancyFees(int id, string name, string description = "") : base(id, name, description) { }
       
    }
}
