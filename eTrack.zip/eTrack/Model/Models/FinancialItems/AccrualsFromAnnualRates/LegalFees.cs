﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    public class LegalFees : AccrualsFromAnnualRates
    {
        public LegalFees(int id, string name, string description = "") : base(id, name, description) { }
       
    }
}
