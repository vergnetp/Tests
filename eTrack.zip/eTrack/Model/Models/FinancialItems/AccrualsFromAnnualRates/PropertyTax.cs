﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    public class PropertyTax : AccrualsFromAnnualRates
    {
        public PropertyTax(int id, string name, string description = "") : base(id, name, description) { }
       
    }
}
