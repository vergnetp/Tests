﻿using Finance;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Models
{
    public enum AcquistionCostType
    {
        Legal,
        LandSurvey,
        BuildingSurvey,
        RegistrationFees,
        AgentFees,
        Other
    }
    public class AcquisitionCost : IEntity
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Comment { get; set; }

        [DisplayFormat(DataFormatString = "{0:0,0}", ApplyFormatInEditMode = true)]
        public double Amount { get; set; }

        private DateTime _PaymentDate;
        [DataType(DataType.Date)]
        [Display(Name = "Payment Date")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Remote("UnitStartDate", "Validator", HttpMethod = "Post", AdditionalFields = "Id")]
        public DateTime PaymentDate { get { if (_PaymentDate == DateTime.MinValue) { if (this.Property == null) { return DateTime.Now; } else { return this.Property.StartDate; } } else { return _PaymentDate; } } set { _PaymentDate = value; } }


        public Currency Currency { get; set; }

        public virtual AcquistionCostType AcquisitionCostType { get; set; }

        [Required]
        public virtual Property Property { get; set; }

        [HiddenInput(DisplayValue = false)]
        public virtual User User { get; set; }
    }
}