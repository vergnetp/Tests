﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    public class Company:Entity
    {
        public Company(int id, string name, string description = "") : base(id, name, description) { }
        public DateTime StartDate;
        public DateTime EndDate;
        public Accruals AccountancyFees;
        public Accruals LegalFees;
        public Accruals AdminFees;
        public Accruals AssetManagementFees;
        public List<Accruals> OtherCorporateCosts;
        public Accruals Tax;
        public Accruals TaxableIncome;
        // Equity
    }
}
