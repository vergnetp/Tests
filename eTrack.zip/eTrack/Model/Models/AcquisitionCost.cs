﻿using Finance;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Models
{
    public class AcquisitionCost:IEntity
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Comment { get; set; }

        [DisplayFormat(DataFormatString = "{0:0,0}", ApplyFormatInEditMode = true)]
        public double Amount { get; set; }
        public Currency Currency { get; set; }

        [Required]
        public virtual Property Property { get; set; }

        [HiddenInput(DisplayValue = false)]
        public virtual User User { get; set; }
    }
}