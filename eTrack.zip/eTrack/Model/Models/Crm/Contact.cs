﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Web.Mvc;

namespace Models
{
    //public class FormArgs
    //{
    //    public string PropertyName { get; set; }
    //    public string PropertyNameDisplay { get; set; }
    //    public object PropertyValue { get; set; }
    //}

    public class Contact : IEntity
    {
        [HiddenInput(DisplayValue = false)]
        public int Id { get; set; }

        //[StringLength(50, MinimumLength = 1)]
        [Display(Name = "First Name")]
        public string Name { get; set; }

        //[StringLength(50, MinimumLength = 1)]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        //[Required]
        //[RegularExpression(@"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*")]
        //[StringLength(50, MinimumLength = 3)]
        [Display(Name = "eMail")]
        public string Email { get; set; }

        public string Telephone { get; set; }

        //[StringLength(100, MinimumLength = 0)]
        public string Message { get; set; }

        [Required]
        public virtual User User { get; set; }
    }
}