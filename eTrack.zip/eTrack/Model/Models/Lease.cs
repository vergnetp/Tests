﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Web.Mvc;
using Finance;

namespace Models
{   
    /// <summary>
    /// On delete: do nothing
    /// </summary>
    public class Lease:IEntity
    {
        public Lease() { this.Units = new List<Unit>(); }

      
        public int Id { get; set; } 
        public string Name { get; set; }        

        [DisplayFormat(DataFormatString = "{0:0,0}", ApplyFormatInEditMode = true)]
        public double AnnualRent { get; set; }

        public Currency Currency { get; set; }

        [DisplayFormat(DataFormatString = "{0:P2}", ApplyFormatInEditMode = true)]       
        public double Recoverability { get; set; }

        private DateTime _StartDate;
        [DataType(DataType.Date)]
        [Display(Name = "Start Date")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Remote("LeaseStartDate", "Validator", HttpMethod = "Post", AdditionalFields = "Id")]
        public DateTime StartDate { get { if (_StartDate == DateTime.MinValue) { if (this.Property == null) { return DateTime.Now; } else { return this.Property.StartDate; } } else { return _StartDate; } } set { _StartDate = value; } }

        private DateTime _EndDate;
        [DataType(DataType.Date)]
        [Display(Name = "End Date")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Remote("LeaseEndDate", "Validator", HttpMethod = "Post")]
        public DateTime EndDate { get { if (_EndDate == DateTime.MinValue) { if (this.Property == null) { return this.StartDate.AddYears(5); } else { return this.Property.EndDate; } } else { return _EndDate; } } set { _EndDate = value; } }
        

        [Required]
        public virtual Property Property { get; set; }

        // Add Existing: Unit in property
        [ExistingEntityFilter("Property")]
        [Dettach]
        public virtual List<Unit> Units { get; set; }

        //[Required]
        [HiddenInput(DisplayValue=false)]
        public virtual User User { get; set; }

      
    }
}