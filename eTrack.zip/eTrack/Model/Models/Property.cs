﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Web.Mvc;
using Finance;

namespace Models
{

    [AttributeUsage(AttributeTargets.Property)]
    public class  ExistingEntityFilter: System.Attribute
    {
        public List<string> Navigation;
        public ExistingEntityFilter(params string[] navigation)
        {
            this.Navigation = new List<string>(navigation);
        }
    }
    [AttributeUsage(AttributeTargets.Property)]
    public class ExistingEntityDisbaled : System.Attribute
    {
        public ExistingEntityDisbaled() {  }
    }
    [AttributeUsage(AttributeTargets.Property)]
    public class Dettach : System.Attribute
    {
        public Dettach() { }
    }

    /// <summary>
    /// on delete: delete all units and leases belonging to it
    /// </summary>
    public class Property:IEntity
    {
        public Property() { Debts = new List<Debt>(); Capexs = new List<Capex>(); AcquisitionCosts = new List<AcquisitionCost>(); Units = new List<Unit>(); Leases = new List<Lease>(); ServiceCharges = new List<ServiceCharge>(); }

       
        public int Id { get; set; } 
        public string Name { get; set; }
       
        public string Address { get; set; }

        private DateTime _StartDate ;
        [DataType(DataType.Date)]
        [Display(Name = "Start Date")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Remote("PropertyStartDate", "Validator", HttpMethod = "Post",AdditionalFields="Id")]
        public DateTime StartDate { get { if (_StartDate == DateTime.MinValue) { if (this.Portfolio == null) { return DateTime.Now; } else { return this.Portfolio.StartDate; } } else { return _StartDate; } } set { _StartDate = value; } }

        private DateTime _EndDate;
        [DataType(DataType.Date)]
        [Display(Name = "End Date")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Remote("PropertyEndDate", "Validator", HttpMethod = "Post", AdditionalFields = "Id")]
        public DateTime EndDate { get { if (_EndDate == DateTime.MinValue) { if (this.Portfolio == null) { return this.StartDate.AddYears(5); } else { return this.Portfolio.EndDate; } } else { return _EndDate; } } set { _EndDate = value; } }

        [Display(Name="Area (sqm)")]
        [DisplayFormat(DataFormatString = "{0:0,0}", ApplyFormatInEditMode = true)]
        public double Area { get { return this.Units.Sum(u => u.Area); } }

        [DisplayFormat(DataFormatString = "{0:0,0}", ApplyFormatInEditMode = true)]
        public virtual List<ServiceCharge> ServiceCharges { get; set; }

        // todo: transfer to a new class:
        [Display(Name = "Net Purchase Price")]
        [DisplayFormat(DataFormatString = "{0:0,0}", ApplyFormatInEditMode = true)]
        public double NetPurchasePrice { get; set; }
        public Currency NetPurchasePriceCurrency { get; set; } 

        [DisplayFormat(DataFormatString = "{0:0,0}", ApplyFormatInEditMode = true)]
        public virtual List<AcquisitionCost> AcquisitionCosts { get; set; }

        // todo: transfer to a new class:
        private double _ExitPrice;
        [Display(Name = "Exit Price")]
        [DisplayFormat(DataFormatString = "{0:0,0}", ApplyFormatInEditMode = true)]
        public double ExitPrice { get;set;}
        public Currency ExitPriceCurrency { get; set; } 
        private double _ExitYield;
        [Display(Name = "Exit Yield")]
        public double ExitYield { get; set; }

        [Display(Name = "Letting Fees (%)")]
        public double LettingFees { get; set; }

        private int? _VacancyTime;
        [Display(Name = "Vacancy (months)")]
        [DisplayFormat(DataFormatString = "{0:0,0}", ApplyFormatInEditMode = true)]
        public int? VacancyTime { get { if (_VacancyTime == null) { return 3; } else { return _VacancyTime; } } set { _VacancyTime = value; } }

        public virtual List<Capex> Capexs { get; set; }

        public virtual List<Debt> Debts { get; set; }

        public virtual Country Country { get; set; }

        // Dependent
        [ExistingEntityDisbaled]
        public virtual List<Unit> Units { get; set; } 

        // Dependent
        [ExistingEntityDisbaled]
        public virtual List<Lease> Leases { get; set; }

        [Required]
        public virtual Portfolio Portfolio { get; set; }

        //[Required]
        [HiddenInput(DisplayValue = false)]
        public virtual User User { get; set; }

        //public virtual int? UserId { get; set; }

    }
}