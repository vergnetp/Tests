﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Web.Mvc;
using Finance;

namespace Models
{

    public class Unit : Entity
    {
        #region Ctor
        public Unit(int id, string name, string description="") : base(id, name, description) { }
        #endregion

        #region Specifics
        public Schedule Area { get; set; }
        public enum AreaUnitType
        {
            Sqm,
            SqFoot
        }
        public Schedule ExitYield;
        public UnitType UnitType;
        public Schedule NbParkings;
        public Currency Currency { get; set; }
        #endregion

        #region FinancialItems
        public AnnualRateGenerator ErvPerAreaUnitType;
        public AnnualRateGenerator ErvPerParkingSpace;
        public Accruals  Utility; // or list?
        public Accruals RecurringRefurbishment;
        public Accruals Ti; 
        #endregion

        #region Calculated Fields
        public Schedule TotalErv
        {
            get
            {
                var entity=this;               
                var erv = entity.Area * entity. ErvPerAreaUnitType.AnnualRates;        
                var ervParking = entity.NbParkings * entity.ErvPerParkingSpace.AnnualRates;
                var res = erv + ervParking;
                return res;                
            }
        }
        public Schedule Fmv
        {
            get
            {
                var entity = this;
                var res = entity.TotalErv / entity.ExitYield;
                return res;
            }
        }
        #endregion

        #region Start/End
        private DateTime _StartDate;
        [DataType(DataType.Date)]
        [Display(Name = "Start Date")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Remote("UnitStartDate", "Validator", HttpMethod = "Post", AdditionalFields = "Id")]
        public DateTime StartDate { get { if (_StartDate == DateTime.MinValue) { if (this.Property == null) { return DateTime.Now; } else { return this.Property.StartDate; } } else { return _StartDate; } } set { _StartDate = value; } }

        private DateTime _EndDate;
        [DataType(DataType.Date)]
        [Display(Name = "End Date")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Remote("UnitEndDate", "Validator", HttpMethod = "Post", AdditionalFields = "Id")]
        public DateTime EndDate { get { if (_EndDate == DateTime.MinValue) { if (this.Property == null) { return this.StartDate.AddYears(5); } else { return this.Property.EndDate; } } else { return _EndDate; } } set { _EndDate = value; } }
        #endregion

        #region Parent
        [Required]
        public virtual Property Property { get; set; }       
        #endregion

        #region Other Objects
        public virtual Lease Lease { get; set; }
        //[Required]
        [HiddenInput(DisplayValue = false)]
        public virtual User User { get; set; }
        #endregion
                
 

        
    }
}