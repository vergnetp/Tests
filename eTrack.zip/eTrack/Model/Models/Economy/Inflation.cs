﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using Finance;

namespace Models
{
    public class Inflation : IEntity
    {
        public Inflation() { }

        public int Id { get; set; }
        [Display(Name = "Index")]
        public string Name { get; set; }

        private DateTime _StartDate;
        [DataType(DataType.Date)]
        [Display(Name = "Start Date")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Remote("UnitStartDate", "Validator", HttpMethod = "Post", AdditionalFields = "Id")]
        public DateTime StartDate { get { if (_StartDate == DateTime.MinValue) { return DateTime.Now; } else { return _StartDate; } } set { _StartDate = value; } }


        [DisplayFormat(DataFormatString = "{0:P2}", ApplyFormatInEditMode = true)]
        public double AnnualRate { get; set; }

        [Required]
        public virtual Country Country { get; set; }
        //[Required]
        [HiddenInput(DisplayValue = false)]
        public virtual User User { get; set; }


        public string Description;
        public Schedule Index;

        // todo: btter strategy
        public void Check(bool condition)
        {
            if (!condition) throw new Exception("Arguments not valid");
        }

        public double GetInflation(DateTime previous, DateTime next)
        {
            Check(this.Index != null);
            Check(this.Index.Count >= 2);
            Check(next >= previous);
            Check(previous >= this.Index.First().Date);
            Check(next <= this.Index.Last().Date);
            double previousIndex = 1.0; double nextIndex = 1.0;
            for (var i = 0; i < this.Index.Count - 1; i++)
            {
                if (this.Index[i].Date <= previous && previous <= this.Index[i + 1].Date)
                {
                    previousIndex = this.Index[i].Item.Value;
                }
                if (this.Index[i].Date <= next && next <= this.Index[i + 1].Date)
                {
                    nextIndex = this.Index[i].Item.Value;
                }
            }
            Check(previousIndex > 0);
            var res = nextIndex / previousIndex - 1.0;
            return res;
        }
    }
}
