﻿using Finance;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Models
{

    /// <summary>
    /// Debt Amortization. Expect a positive amount.
    /// </summary>
    public class DebtAmortization:IEntity
    {
        public int Id { get; set; }
        public string Name { get; set; }
        private DateTime _Date;
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime PaymentDate { get { if (_Date == DateTime.MinValue) { return DateTime.Now; } else { return _Date; } } set { _Date = value; } }
        [DisplayFormat(DataFormatString = "{0:0,0}", ApplyFormatInEditMode = true)]
        public double Amount { get; set; }

        public Currency Currency { get; set; }
        public string Comment { get; set; }

        [Required]
        public virtual Debt Debt{get;set;}
        public virtual User User { get; set; }
    
    }
}