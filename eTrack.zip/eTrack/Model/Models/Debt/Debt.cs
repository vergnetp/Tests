﻿using Finance;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Models
{
    public class Debt : IEntity
    {
        public Debt() { Interests = new List<Interest>(); DebtAmortizations = new List<DebtAmortization>(); this.DebtDrawdowns = new List<DebtDrawdown>(); this.DebtRepaymentPenaltys = new List<DebtRepaymentPenalty>(); this.DebtSetupCosts = new List<DebtSetupCost>(); this.DebtAgreements = new List<DebtAgreement>(); }
        public int Id { get; set; }
        public string Name { get; set; }

        private DateTime _StartDate;
        [DataType(DataType.Date)]
        [Display(Name = "Start Date")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Remote("UnitStartDate", "Validator", HttpMethod = "Post", AdditionalFields = "Id")]
        public DateTime StartDate { get { if (_StartDate == DateTime.MinValue) { if (this.Property == null) { return DateTime.Now; } else { return this.Property.StartDate; } } else { return _StartDate; } } set { _StartDate = value; } }

        private DateTime _EndDate;
        [DataType(DataType.Date)]
        [Display(Name = "End Date")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [Remote("UnitEndDate", "Validator", HttpMethod = "Post", AdditionalFields = "Id")]
        public DateTime EndDate { get { if (_EndDate == DateTime.MinValue) { if (this.Property == null) { return this.StartDate.AddYears(5); } else { return this.Property.EndDate; } } else { return _EndDate; } } set { _EndDate = value; } }

        [DisplayFormat(DataFormatString = "{0:P2}", ApplyFormatInEditMode = true)]
        public double Margin { get; set; }

        [DisplayFormat(DataFormatString = "{0:0,0}", ApplyFormatInEditMode = true)]
        public double SetupFees { get; set; }
        public Currency Currency { get; set; }

        public virtual ICollection<DebtSetupCost> DebtSetupCosts { get; set; }
        public virtual ICollection<DebtRepaymentPenalty> DebtRepaymentPenaltys { get; set; }
        public virtual ICollection<DebtDrawdown> DebtDrawdowns { get; set; }
        public virtual ICollection<DebtAmortization> DebtAmortizations { get; set; }
        public virtual ICollection<DebtAgreement> DebtAgreements { get; set; }
        public virtual ICollection<Interest> Interests { get; set; }

        [Required]
        public virtual Property Property { get; set; }

        public virtual Bank Bank { get; set; }

        public virtual User User { get; set; }

        public double GetOutstandingDebt(DateTime date)
        {
            var result = this.DebtDrawdowns.Sum(d => d.Amount);// todo: what if drawdown after first amortization?
            var pastRepaymenst = this.DebtAmortizations.Where(d => d.PaymentDate <= date);
            var totalRepayments = pastRepaymenst.Sum(d => d.Amount);
            result -= totalRepayments;
            return result;
        }

    }
}