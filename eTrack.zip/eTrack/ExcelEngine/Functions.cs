﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcelDna.Integration;
using Engine;
using Models;
using Finance;

namespace ExcelEngine
{


    public static class Functions
    {

        [ExcelFunction(Description = "Forecast the Rent due in each reporting period.", Category = "eTrack")]
        public static object[,] ForecastRent(double annualRent, double startDate, double endDate, string currency,double inflation,  string reportingCurrency, string frequency, string dayCount)
        {
            var accruals = GetRentAccruals(annualRent, startDate, endDate, inflation, currency);
            var res = ReportAccruals(accruals, startDate, endDate, reportingCurrency, frequency, dayCount);
            return res;
        }

        [ExcelFunction(Description = "Return the annual Rent levels.", Category = "eTrack")]
        public static object[,] GetRentAccruals(double annualRent, double startDate, double endDate, double inflation,string currency)
        {
            var engine = new DefaultEngine();
            var lease = new Lease();
            lease.Property = new Property(); lease.Property.Country = new Country(); lease.Property.Country.Inflation = new Inflation() { AnnualRate = inflation };
            lease.AnnualRent = annualRent;
            lease.StartDate = DateTime.FromOADate(startDate);
            lease.EndDate = DateTime.FromOADate(endDate);
            lease.Currency = new Currency(currency);
            var accruals = engine.GetRentAccruals(lease);
            var res = Convert(accruals);
            return res;
        }

        [ExcelFunction(Description = "Forecast the Service Charge due in each reporting period.", Category = "eTrack")]
        public static object[,] ForecastServiceCharge(double annualRent, double startDate, double endDate, string currency, double inflation, string reportingCurrency, string frequency, string dayCount)
        {
            var accruals = GetServiceChargeAccruals(annualRent, startDate, endDate, inflation, currency);
            var res = ReportAccruals(accruals, startDate, endDate, reportingCurrency, frequency, dayCount);
            return res;
        }

        [ExcelFunction(Description = "Return the annual Service Charge levels.", Category = "eTrack")]
        public static object[,] GetServiceChargeAccruals(double annualAmount, double startDate, double endDate, double inflation, string currency)
        {
            var engine = new DefaultEngine();
            var serviceCharge = new ServiceCharge();
            serviceCharge.Property = new Property(); serviceCharge.Property.Country = new Country(); serviceCharge.Property.Country.Inflation = new Inflation() { AnnualRate = inflation };
            serviceCharge.AnnualAmount = annualAmount;
            serviceCharge.StartDate = DateTime.FromOADate(startDate);
            serviceCharge.EndDate = DateTime.FromOADate(endDate);
            serviceCharge.Currency = new Currency(currency);
            var accruals = engine.GetServiceChargeAccruals(serviceCharge);
            var res = Convert(accruals);
            return res;
        }

        [ExcelFunction(Description = "Forecast the Service Charge Income due in each reporting period.", Category = "eTrack")]
        public static object[,] ForecastServiceChargeIncome(double rec, double annualAmount, double startDate, double endDate, string currency, double inflation, string reportingCurrency, string frequency, string dayCount)
        {
            var accruals = GetServiceChargeIncomeAccruals(rec,annualAmount, startDate, endDate, inflation, currency);
            var res = ReportAccruals(accruals, startDate, endDate, reportingCurrency, frequency, dayCount);
            return res;
        }

        [ExcelFunction(Description = "Return the annual Service Charge Income levels.", Category = "eTrack")]
        public static object[,] GetServiceChargeIncomeAccruals(double rec, double annualAmount,double startDate, double endDate, double inflation, string currency)
        {
            var engine = new SimpleEngine();
            var serviceCharge = new ServiceCharge();
            serviceCharge.Property = new Property(); serviceCharge.Property.Country = new Country(); serviceCharge.Property.Country.Inflation = new Inflation() { AnnualRate = inflation };
            serviceCharge.AnnualAmount = annualAmount;
            serviceCharge.StartDate = DateTime.FromOADate(startDate);
            serviceCharge.EndDate = DateTime.FromOADate(endDate);
            serviceCharge.Currency = new Currency(currency);            
            var accruals = engine.GetServiceChargeIncomeAccruals(serviceCharge,rec);
            var res = Convert(accruals);
            return res;
        }


        [ExcelFunction(Description = "Report the due accruals.", Category = "eTrack")]
        public static object[,] ReportAccruals(object[,] accruals, double startDate, double endDate, string reportingCurrency, string frequency, string dayCount)
        {
            var convertedAccruals = Convert(accruals);
            var reporter = new Reporter(DateTime.FromOADate(startDate), DateTime.FromOADate(endDate), new Currency(reportingCurrency), GetFrequency(frequency), null);
            var schedule = reporter.ReportAccruals(convertedAccruals, GetDayCount(dayCount));
            var res = Convert(schedule);
            return res;
        }

        [ExcelFunction(Description = "Yearfrac.", Category = "eTrack")]
        public static double YearFracXll(double startDate,double endDate,string dayCount)
        {
            var res = DateHelper.Yearfrac(DateTime.FromOADate(startDate), DateTime.FromOADate(endDate), GetDayCount(dayCount));
            return res;
        }


        #region Tools

        public static object[,] Convert(List<Accrual> accruals)
        {
            var res = new object[5, accruals.Count + 1];
            res[0, 0] = "From:";
            res[1, 0] = "To:";
            res[2, 0] = "Amount due:";
            res[3, 0] = "Currency:";
            res[4, 0] = "Payable:";
            for (var i = 0; i < accruals.Count; i++)
            {
                res[0, i + 1] = accruals[i].StartDate.ToOADate();
                res[1, i + 1] = accruals[i].EndDate.ToOADate();
                res[2, i + 1] = accruals[i].Amount;
                res[3, i + 1] = accruals[i].Currency.Name;
                res[4, i + 1] = accruals[i].PaymentDate.ToOADate();
            }
            return res;
        }

        public static List<Accrual> Convert(object[,] accruals)
        {
            var res = new List<Accrual>();
            for (var i = 1; i < accruals.GetLength(1); i++)
            {
                var accrual = new Accrual(DateTime.Now);
                accrual.StartDate = DateTime.FromOADate(System.Convert.ToDouble(accruals[0, i]));
                accrual.EndDate = DateTime.FromOADate(System.Convert.ToDouble(accruals[1, i]));
                accrual.Amount = System.Convert.ToDouble(accruals[2, i]);
                accrual.Currency = new Currency(accruals[3, i].ToString());
                accrual.PaymentDate = DateTime.FromOADate(System.Convert.ToDouble(accruals[4, i]));
                res.Add(accrual);
            }
            return res;
        }

        public static object[,] Convert(Schedule schedule)
        {
            var res = new object[4, schedule.Count + 1];
            res[0, 0] = "From:";
            res[1, 0] = "Amount due:";
            res[2, 0] = "Comment:";
            res[3, 0] = "Is Overriden:";
            for (var i = 0; i < schedule.Count; i++)
            {
                res[0, i + 1] = schedule[i].Date.ToOADate();
                res[1, i + 1] = schedule[i].Item.Value;
                res[2, i + 1] = schedule[i].Item.Comment;
                res[3, i + 1] = schedule[i].Item.IsOverriden;
            }
            return res;
        }

        public static Frequency GetFrequency(string frequency)
        {
            switch (frequency)
            {
                case ("Yearly"):
                    return Frequency.Yearly;
                case ("Monthly"):
                    return Frequency.Monthly;
                default:
                    return Frequency.Quarterly;
            }
        }

        public static DayCount GetDayCount(string dc)
        {
            switch (dc)
            {
                case ("30/360"):
                    return DayCount.Days360;
                case ("Act/360"):
                    return DayCount.Act360;
                case ("Act/365"):
                    return DayCount.Act365;
                default:
                    return DayCount.ActAct;
            }
        }
        
        #endregion

    }


}
