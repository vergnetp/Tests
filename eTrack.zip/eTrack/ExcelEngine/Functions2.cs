﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engine;
using Finance;
using ExcelDna.Integration;
using Models;
using Reporting;

namespace ExcelEngine
{
    public static class Functions2
    {

        #region Inflation

        public static Inflation _Inflation;

        [ExcelFunction(Description = "Create an Inflation schedule in memory.", Category = "eTrack")]
        public static object CreateInflation(string name, string description, object[,] levels)
        {
            if (ExcelDnaUtil.IsInFunctionWizard()) return null;
            try
            {
                var schedule = ConvertSchedule(levels);
                var inflation = new Inflation() { Name = name, Description = description, Index = schedule };
                _Inflation = inflation;
                var res = DateTime.Now.ToOADate();
                return res;
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }

        #endregion

        #region AccrualsFromAnnualRates

        public static AccrualsFromAnnualRates _AnnualRates;

        [ExcelFunction(Description = "Create annual rates, accruals and cashflows schedules in memory.", Category = "eTrack")]
        public static object CreateAnnualRates(double startDate, double endDate, double annualRate, string currency,
            object inflationIndex, object asAt,
            object firstRevision, object revisionFrequencyPeriodMultiplier, object revisionFrequencyPeriod, object revisionRollConvention, object revisionBusinessDayConvention, object revisionBusinessCenter,
            object RentFreePeriod, object IsRevisionUpwardOnly, object RevisionCap,
            object firstAccrual, object accrualFrequencyPeriodMultiplier, object accrualFrequencyPeriod, object accrualRollConvention, object accrualBusinessDayConvention, object accrualBusinessCenter,
            object paymentInAdvance, object paymentNbPeriodSkipped, object OffsetPeriodMultiplier, object OffsetPeriod, object paymentBusinessDayConvention, object paymentBusinessCenter
            )
        {
            if (ExcelDnaUtil.IsInFunctionWizard()) return null;
            try
            {
                var rFP = Convert<FrequencyPeriod>(revisionFrequencyPeriod, FrequencyPeriod.Y);
                var rRC = Convert<RollConvention>(revisionRollConvention, RollConvention.EOM);
                var rDC = Convert<BusinessDayConvention>(revisionBusinessDayConvention, BusinessDayConvention.NONE);
                var aFP = Convert<FrequencyPeriod>(accrualFrequencyPeriod, FrequencyPeriod.Y);
                var aRC = Convert<RollConvention>(accrualRollConvention, RollConvention.EOM);
                var aDC = Convert<BusinessDayConvention>(accrualBusinessDayConvention, BusinessDayConvention.NONE);
                var oP = Convert<FrequencyPeriod>(OffsetPeriod, FrequencyPeriod.D);
                var pDC = Convert<BusinessDayConvention>(paymentBusinessDayConvention, BusinessDayConvention.NONE);
                var accrualsFromAnnualRates = new AccrualsFromAnnualRates(1, "");               
                accrualsFromAnnualRates.Reset(DateTime.FromOADate(startDate), DateTime.FromOADate(endDate), annualRate, new Currency(currency), _Inflation, ConvertToDate(asAt, null),
                    Convert<bool>(IsRevisionUpwardOnly, false), Convert<double?>(RevisionCap, null), ConvertNullable(RentFreePeriod),
                    ConvertToDate(firstRevision, null), rFP, ConvertToInt(revisionFrequencyPeriodMultiplier, 1), rRC, rDC, new List<string>() { Convert<string>(revisionBusinessCenter, null) },
                    ConvertToDate(firstAccrual, null), aFP, ConvertToInt(accrualFrequencyPeriodMultiplier, 1), aRC, aDC, new List<string>() { Convert<string>(accrualBusinessCenter, null) },
                    ConvertToInt(OffsetPeriodMultiplier, 0), oP, pDC, new List<string>() { Convert<string>(paymentBusinessCenter, null) }, Convert<bool>(paymentInAdvance, false), ConvertToInt(paymentNbPeriodSkipped, 0)
                    );
                _AnnualRates = accrualsFromAnnualRates;
                var res = DateTime.Now.ToOADate();
                return res;
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }

        [ExcelFunction(Description = "Get Annual rates.", Category = "eTrack")]
        public static object[,] GetRates()
        {
            if (ExcelDnaUtil.IsInFunctionWizard()) return null;
            var schedule = _AnnualRates.AnnualRates;
            var res = Convert(schedule);
            return res;
        }

        [ExcelFunction(Description = "Get Accruals.", Category = "eTrack")]
        public static object[,] GetAccruals()
        {
            if (ExcelDnaUtil.IsInFunctionWizard()) return null;
            var schedule = _AnnualRates.DueAmounts; 
            var res = Convert(schedule);
            return res;
        }

        [ExcelFunction(Description = "Get Payments.", Category = "eTrack")]
        public static object[,] GetPayments()
        {
            if (ExcelDnaUtil.IsInFunctionWizard()) return null;
            var schedule = _AnnualRates.CashFlows;
            var res = Convert(schedule);
            return res;
        }        

        #endregion

        #region Reporting

        [ExcelFunction(Description = "Report accruals.", Category = "eTrack")]
        public static object[,] ReportAccruals(double startDate,double endDate,object frequency,object dayCount,object reportingCurrency)
        {
            var freq = Convert<Frequency>(frequency, Frequency.Yearly);
            var dc = Convert<DayCount>(dayCount, DayCount.ActAct);
            var ccy = Convert<string>(reportingCurrency, null);
            Currency usedCcy = null;
            if (ccy != null) usedCcy = new Currency(ccy);
            var reporter = new Reporter(DateTime.FromOADate(startDate),DateTime.FromOADate(endDate),usedCcy,freq,null);
            var accruals=reporter.ReportAccruals(_AnnualRates.DueAmounts,dc);
            var res = Convert(accruals);
            return res;
        }

        #endregion

        #region Scheduler
        [ExcelFunction(Description = "Scheduler", Category = "eTrack")]
        public static object[,] GenerateSchedule(double startDate, double endDate,
             object firstRevision, object revisionFrequencyPeriodMultiplier, object revisionFrequencyPeriod, object revisionRollConvention, object revisionBusinessDayConvention, object revisionBusinessCenter,
            object RentFreePeriod, object IsRevisionUpwardOnly, object RevisionCap)
        {
            if (ExcelDnaUtil.IsInFunctionWizard()) return null;
            try
            {
                var rFP = Convert<FrequencyPeriod>(revisionFrequencyPeriod, FrequencyPeriod.Y);
                var rRC = Convert<RollConvention>(revisionRollConvention, RollConvention.EOM);
                var rDC = Convert<BusinessDayConvention>(revisionBusinessDayConvention, BusinessDayConvention.NONE);
                var scheduler = new Scheduler();
                scheduler.StartDate = DateTime.FromOADate(startDate);
                scheduler.EndDate = DateTime.FromOADate(endDate);
                scheduler.FirstPeriodEndDate=ConvertToDate(firstRevision, null);
                scheduler.FrequencyPeriod=rFP;
                scheduler.FrequencyPeriodMultiplier=ConvertToInt(revisionFrequencyPeriodMultiplier, 1);
                scheduler.RollConvention=rRC;
                scheduler.BusinessDayAdjuster.BusinessDayConvention=rDC;
                scheduler.BusinessDayAdjuster.BusinessCenters = new List<string>() { Convert<string>(revisionBusinessCenter,null) };
                var schedule=scheduler.Schedule;
                var res=Convert(schedule);
                return res;
            }            
            catch (Exception ex)
            {
                return new object[1,1]{{ex.ToString()}};
            }
        }
        #endregion

        #region Misc

        [ExcelFunction(Description = "Merge", Category = "eTrack")]
        public static object[,] Merge(object[,] o1,object[,] o2)
        {
            if (ExcelDnaUtil.IsInFunctionWizard()) return null;
            var s1 = ConvertSchedule(o1);
            var s2 = ConvertSchedule(o2);
            var res = ScheduleExtensions.Merge(s1,s2);
            return Convert(res);
        }

        [ExcelFunction(Description = "Off", Category = "eTrack")]
        public static object[,] Off(object[,] o1, int offset)
        {
            if (ExcelDnaUtil.IsInFunctionWizard()) return null;
            var s1 = ConvertSchedule(o1);
            var res = ScheduleExtensions.Offset(s1,offset);
            return Convert(res);
        }


        [ExcelFunction(Description = "GetLevelsInside", Category = "eTrack")]
        public static object[,] GetLevelsInside(object[,] o1, object[,] o2)
        {
            if (ExcelDnaUtil.IsInFunctionWizard()) return null;
            var s1 = ConvertSchedule(o1);
            var s2 = ConvertSchedule(o2);
            var res = ScheduleExtensions.GetLevelsInside(s1, s2);
            return Convert(res);
        }

        [ExcelFunction(Description = "GetLevels", Category = "eTrack")]
        public static object[,] GetLevels(object[,] o1, object[,] o2)
        {
            if (ExcelDnaUtil.IsInFunctionWizard()) return null;
            var s1 = ConvertSchedule(o1);
            var s2 = ConvertSchedule(o2);
            var res = ScheduleExtensions.GetLevels(s1, s2);
            return Convert(res);
        }

        [ExcelFunction(Description = "Add", Category = "eTrack")]
        public static object[,] Add(object[,] o1, object[,] o2)
        {
            if (ExcelDnaUtil.IsInFunctionWizard()) return null;
            var s1 = ConvertSchedule(o1);
            var s2 = ConvertSchedule(o2);
            var res = s1+s2;
            return Convert(res);
        }

        [ExcelFunction(Description = "Subtract", Category = "eTrack")]
        public static object[,] Subtract(object[,] o1, object[,] o2)
        {
            if (ExcelDnaUtil.IsInFunctionWizard()) return null;
            var s1 = ConvertSchedule(o1);
            var s2 = ConvertSchedule(o2);
            var res = s1 - s2;
            return Convert(res);
        }

        [ExcelFunction(Description = "Divide", Category = "eTrack")]
        public static object[,] Divide(object[,] o1, object[,] o2)
        {
            if (ExcelDnaUtil.IsInFunctionWizard()) return null;
            var s1 = ConvertSchedule(o1);
            var s2 = ConvertSchedule(o2);
            var res = s1 / s2;
            return Convert(res);
        }

        [ExcelFunction(Description = "Divide", Category = "eTrack")]
        public static object[,] Multiply(object[,] o1, object[,] o2)
        {
            if (ExcelDnaUtil.IsInFunctionWizard()) return null;
            var s1 = ConvertSchedule(o1);
            var s2 = ConvertSchedule(o2);
            var res = s1 * s2;
            return Convert(res);
        }

        [ExcelFunction(Description = "Yearfrac", Category = "eTrack")]
        public static double YearFracXll(double startDate, double endDate, string dayCount)
        {
            if (ExcelDnaUtil.IsInFunctionWizard()) return 0.0;
            var res = DateHelper.Yearfrac(DateTime.FromOADate(startDate), DateTime.FromOADate(endDate), GetDayCount(dayCount));
            return res;
        }

        #endregion
        
        #region Tools

        public static T Convert<T>(object arg, T defaultValue)
        {
            if ((arg is ExcelMissing) || (arg is ExcelEmpty))
            {
                return defaultValue;
            }
            else
            {
                if (defaultValue is Enum)
                {
                    var res = (T)Enum.Parse(typeof(T), arg.ToString());
                    return res;
                }
                else
                {
                    var res = (T)arg;
                    return res;
                }
            }
        }
        public static int? ConvertNullable(object arg)
        {
            if ((arg is ExcelMissing) || (arg is ExcelEmpty))
            {
                return null;
            }
            else
            {
                var res = (double)arg;
                return (int?)res;
            }
        }
        public static int ConvertToInt(object arg, int defaultValue)
        {
            if ((arg is ExcelMissing) || (arg is ExcelEmpty))
            {
                return defaultValue;
            }
            else
            {
                var res = (double)arg;
                return (int)res;
            }
        }
        public static DateTime? ConvertToDate(object arg, DateTime? defaultValue)
        {
            if ((arg is ExcelMissing) || (arg is ExcelEmpty))
            {
                return defaultValue;
            }
            else
            {
                var res = (double)arg;
                return DateTime.FromOADate(res);
            }
        }
 

        public static object[,] Convert(List<Accrual> accruals)
        {
            var res = new object[4, accruals.Count + 1];
            res[0, 0] = "From:";
            res[1, 0] = "To:";
            res[2, 0] = "Amount due:";
            res[3, 0] = "Currency:";           
            for (var i = 0; i < accruals.Count; i++)
            {
                res[0, i + 1] = accruals[i].StartDate.ToOADate();
                res[1, i + 1] = accruals[i].EndDate.ToOADate();
                res[2, i + 1] = accruals[i].Amount;
                res[3, i + 1] = accruals[i].Currency.Name;                
            }
            return res;
        }

        public static object[,] Convert(List<CashFlow> cf)
        {
            var res = new object[2, cf.Count + 1];
            res[0, 0] = "Payment Date:";
            res[1, 0] = "Amount:";            
            for (var i = 0; i < cf.Count; i++)
            {
                res[0, i + 1] = cf[i].PaymentDate.ToOADate();                
                res[1, i + 1] = cf[i].Amount;              
            }
            return res;
        }

        public static List<Accrual> Convert(object[,] accruals)
        {
            var res = new List<Accrual>();
            for (var i = 1; i < accruals.GetLength(1); i++)
            {
                var accrual = new Accrual(DateTime.Now);
                accrual.StartDate = DateTime.FromOADate(System.Convert.ToDouble(accruals[0, i]));
                accrual.EndDate = DateTime.FromOADate(System.Convert.ToDouble(accruals[1, i]));
                accrual.Amount = System.Convert.ToDouble(accruals[2, i]);
                accrual.Currency = new Currency(accruals[3, i].ToString());
                if (accruals.GetLength(0)>4) accrual.PaymentDate = DateTime.FromOADate(System.Convert.ToDouble(accruals[4, i]));
                res.Add(accrual);
            }
            return res;
        }
        public static Schedule ConvertSchedule(object[,] schedule)
        {
            var res = new Schedule();
            for (var i = 1; i < schedule.GetLength(1); i++)
            {
                var item = new ScheduleItem();
                item.Date = DateTime.FromOADate(System.Convert.ToDouble(schedule[0, i]));
                if (schedule[1, i] is string && Convert<string>(schedule[1, i], "") == "null")
                {
                    item.Item = null;
                }
                else
                {
                    item.Item.Value = Convert<double>(schedule[1, i], 0.0);
                }
                res.Add(item);
            }
            return res;
        }

        public static object[,] Convert(Schedule schedule)
        {
            var res = new object[4, schedule.Count + 1];
            res[0, 0] = "From:";
            res[1, 0] = "Amount due:";
            res[2, 0] = "Comment:";
            res[3, 0] = "Is Overriden:";
            for (var i = 0; i < schedule.Count; i++)
            {
                res[0, i + 1] = schedule[i].Date.ToOADate();
                if (schedule[i].Item == null)
                {
                    res[1, i + 1] = "null";                   
                }
                else
                {
                    res[1, i + 1] = schedule[i].Item.Value;
                    res[2, i + 1] = schedule[i].Item.Comment;
                    res[3, i + 1] = schedule[i].Item.IsOverriden;
                }
            }
            return res;
        }

        public static Frequency GetFrequency(string frequency)
        {
            switch (frequency)
            {
                case ("Yearly"):
                    return Frequency.Yearly;
                case ("Monthly"):
                    return Frequency.Monthly;
                default:
                    return Frequency.Quarterly;
            }
        }

        public static DayCount GetDayCount(string dc)
        {
            switch (dc)
            {
                case ("30/360"):
                    return DayCount.Days360;
                case ("Act/360"):
                    return DayCount.Act360;
                case ("Act/365"):
                    return DayCount.Act365;
                default:
                    return DayCount.ActAct;
            }
        }

        #endregion

    }
}
