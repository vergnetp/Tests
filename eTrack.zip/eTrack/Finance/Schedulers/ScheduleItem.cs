﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Finance
{
    public class Item
    {
        public double Value { get; set; }
        public bool IsOverriden { get; set; }
        public string Comment { get; set; }
        public string Formula { get; set; }
        public Item Clone()
        {
            return new Item() { Value = Value, IsOverriden = IsOverriden, Comment = Comment, Formula = Formula };
        }
    }
    public class ScheduleItem
    {
        public ScheduleItem() { Item = new Item(); }
        public ScheduleItem(DateTime date, double value)
            : this()
        {
            this.Date = date; this.Item.Value = value;
        }
        public DateTime Date { get; set; }
        public Item Item { get; set; }        
    }
}