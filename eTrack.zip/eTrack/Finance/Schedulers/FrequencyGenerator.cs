﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Finance
{
    public enum FrequencyPeriod
    {
        D,
        W,
        M,
        Y,
        T
    }

    public enum BusinessDayConvention
    {
        NONE,
        FOLLOWING,
        FRN,
        MODFOLLOWING,
        PRECEDING,
        MOPRECEDING,
        NEAREST,
        NotApplicable
        /*
        Source:	http://www.fpml.org/spec/fpml-5-5-4-tr-1/html/reporting/schemaDocumentation/schemas/fpml-shared-5-5_xsd/complexTypes/BusinessDayAdjustments/businessDayConvention.html
        The date will not be adjusted if it falls on a day that is not a business day
        The non-business date will be adjusted to the first following day that is a business day
        Per 2000 ISDA Definitions, Section 4.11. FRN Convention; Eurodollar Convention
        The non-business date will be adjusted to the first following day that is a business day unless that day falls in the next calendar month, in which case that date will be the first preceding day that is a business day.
        The non-business day will be adjusted to the first preceding day that is a business day
        The non-business date will be adjusted to the first preceding day that is a business day unless that day falls in the previous calendar month, in which case that date will be the first following day that us a business day
        The non-business date will be adjusted to the nearest day that is a business day - i.e. if the non-business day falls on any day other than a Sunday or a Monday, it will be the first preceding day that is a business day, and will be the first following business day if it falls on a Sunday or a Monday
        The date adjustments conventions are defined elsewhere, so it is not required to specify them here
        */
    }

    public enum RollConvention
    {
        EOM,
        FRN,
        IMM,
        IMMCAD,
        IMMAUD,
        IMMNZD,
        SFE,
        NONE,
        TBILL,
        D1,
        D2,
        D3,
        D4,
        D5,
        D6,
        D7,
        D8,
        D9,
        D10,
        D11,
        D12,
        D13,
        D14,
        D15,
        D16,
        D17,
        D18,
        D19,
        D20,
        D21,
        D22,
        D23,
        D24,
        D25,
        D26,
        D27,
        D28,
        D29,
        D30,
        MON,
        TUE,
        WED,
        THU,
        FRI,
        SAT,
        SUN
        /*
         Source:	http://www.fpml.org/spec/fpml-5-5-4-tr-1/html/reporting/schemaDocumentation/schemas/fpml-shared-5-5_xsd/complexTypes/CalculationPeriodFrequency/rollConvention.html
        Rolls on month end dates irrespective of the length of the month and the previous roll day
        Roll days are determined according to the FRN Convention or Eurodollar Convention as described in ISDA 2000 definitions
        IMM Settlement Dates. The third Wednesday of the (delivery) month
        The last trading day/expiration day of the Canadian Derivatives Exchange (Bourse de Montreal Inc) Three-month Canadian Bankers' Acceptance Futures (Ticker Symbol BAX). The second London banking day prior to the third Wednesday of the contract month. If the determined day is a Bourse or bank holiday in Montreal or Toronto, the last trading day shall be the previous bank business day. Per Canadian Derivatives Exchange BAX contract specification
        The last trading day of the Sydney Futures Exchange 90 Day Bank Accepted Bills Futures contract (see http://www.sfe.com.au/content/sfe/trading/con_specs.pdf). One Sydney business day preceding the second Friday of the relevant settlement month
        The last trading day of the Sydney Futures Exchange NZ 90 Day Bank Bill Futures contract (see http://www.sfe.com.au/content/sfe/trading/con_specs.pdf). The first Wednesday after the ninth day of the relevant settlement month
        Sydney Futures Exchange 90-Day Bank Accepted Bill Futures Settlement Dates. The second Friday of the (delivery) month
        The roll convention is not required. For example, in the case of a daily calculation frequency
        13-week and 26-week U.S. Treasury Bill Auction Dates. Each Monday except for U.S. (New York) holidays when it will occur on a Tuesday
        */
    }

}
