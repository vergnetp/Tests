﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Finance
{
    public class BusinessDayAdjuster
    {
        public BusinessDayConvention BusinessDayConvention;
        public List<string> BusinessCenters;
        public void AdjustForBusinessDays(Schedule schedule)
        {
            // todo: deal with potential null BusinessCenters (or list of null, or list of "")
            switch (BusinessDayConvention)
            {
                case BusinessDayConvention.FOLLOWING: // todo                   
                    break;
                case BusinessDayConvention.MODFOLLOWING:// todo
                    break;
                case BusinessDayConvention.PRECEDING:// todo
                    break;
                case BusinessDayConvention.MOPRECEDING:// todo
                    break;
                case BusinessDayConvention.NEAREST:// todo
                    break;
                case BusinessDayConvention.FRN:// todo
                    break;
                default:
                    break;
            }
        }
    }
}
