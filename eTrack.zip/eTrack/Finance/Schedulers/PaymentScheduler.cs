﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Finance
{
    /// <summary>
    /// Calculated against CalculationPeriod StartDate if InAdvance (EndDate otherwise).
    /// The Frequency cannot be less than the calculation's. Needs to be a integer multiple.
    /// </summary>
    public class PaymentScheduler
    {
        public Scheduler CalculationScheduler;
        public bool InAdvance;
        public int NbPeriodSkipped; // not good f.e. for annual payment  vs daily calc. => need a frequency builder       
        public int OffsetPeriodMultiplier;
        public FrequencyPeriod OffsetPeriod;
        public BusinessDayAdjuster BusinessDayAdjuster;
        private Schedule _Schedule;
        public Schedule Schedule
        {
            get
            {
                GenerateSchedule();
                return _Schedule;
            }
        }
        public void GenerateSchedule()
        {
            var res = new Schedule();
            var calculationSchedule = CalculationScheduler.Schedule;
            var counter = 0;
            var firstIndex = 0; var lastIndex = calculationSchedule.Count - 1;
            if (!InAdvance) { firstIndex = 1; lastIndex = calculationSchedule.Count; }
            for (var i = firstIndex; i < lastIndex; i++)
            {
                if (counter <= NbPeriodSkipped)
                {
                    counter++;
                    var curDate = calculationSchedule[i].Date;
                    switch (OffsetPeriod)
                    {
                        case FrequencyPeriod.D:
                            curDate = curDate.AddDays(OffsetPeriodMultiplier);
                            res.Add(curDate);
                            break;
                        case FrequencyPeriod.W:
                            curDate = curDate.AddDays(7 * OffsetPeriodMultiplier);
                            res.Add(curDate);
                            break;
                        case FrequencyPeriod.M:
                            curDate = curDate.AddMonths(OffsetPeriodMultiplier);
                            res.Add(curDate);
                            break;
                        case FrequencyPeriod.Y:
                            curDate = curDate.AddYears(OffsetPeriodMultiplier);
                            res.Add(curDate);
                            break;
                        default:
                            res.Add(curDate);
                            break;
                    }
                }
                if (counter > NbPeriodSkipped)
                {
                    counter = 0;
                }
            }
            BusinessDayAdjuster.AdjustForBusinessDays(res);
            _Schedule = res;
        }
    }
}
