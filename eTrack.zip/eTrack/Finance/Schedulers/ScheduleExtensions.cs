﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Finance
{
    public static class ScheduleExtensions
    {
        /// <summary>
        /// 01/01/2015 | 15/01/2015 | 04/06/2015  Merge  01/02/2015 | 01/08/2015
        /// 100        | 100        | 200         Merge  2%         | 3%
        /// 01/01/2015 | 15/01/2015 | 01/02/2015 | 04/06/2015 | 01/08/2015
        /// 0          | 0          |  2         | 4          | 6
        /// </summary>
        public static Schedule Merge(this Schedule s1,Schedule s2)
        {
            if (s1 == null) return s2;
            if (s2 == null) return s1;
            var result = new Schedule(s1.Concat(s2.Where(si=>!s1.Dates.Contains(si.Date)).ToList()).ToList());
            result.Sort();
            return result;
        }

        /// <summary>
        /// 01/01/2015 | 15/01/2015 | 04/06/2015  Offset 
        /// 90         | 100        | 200         
        /// 01/01/2015 | 15/01/2015 | 04/06/2015 
        /// Null       | 90         | 100          
        /// </summary>
        public static Schedule Offset(this Schedule s,int offset=1)
        {
            var res = new Schedule(s.Dates.ToArray());
            if (offset>=0)
            {
                for (var i=0;i<res.Count;i++)
                {
                    if (i >= offset)
                    {
                        res[i].Item = s[i - offset].Item.Clone();
                    }
                    else
                    {
                        res[i].Item = null;
                    }
                }     
            }
            else
            {
                for (var i = 0; i < res.Count; i++)
                {
                    if (i < res.Count+offset)
                    {
                        res[i].Item = s[i - offset].Item.Clone();
                    }
                    else
                    {
                        res[i].Item = null;
                    }
                }     
            }
            return res;
        }

        /// <summary>
        /// 01/01/2015 | 15/01/2015 | 04/06/2015  GetLevels  01/02/2015 | 01/08/2015
        /// 100        | 100        | 200         GetLevels  2%         | 3%
        /// 01/01/2015 | 15/01/2015 | 04/06/2015 
        /// 0          | 0          |  2%        
        /// </summary>
        public static Schedule GetLevelsInside(this Schedule s1,Schedule levels)
        {
            var res = new Schedule(s1.Dates.ToArray());
            for (var i = 0; i < res.Count; i++)
            {
                var item = levels.FindFirstInside(res[i].Date);
                res[i].Item.Value = item.Item.Value;
            }
            return res;
        }

        /// <summary>
        /// 01/01/2015 | 15/01/2015 | 04/06/2015  GetLevels  01/02/2015 | 01/08/2015
        /// 100        | 100        | 200         GetLevels  2%         | 3%
        /// 01/01/2015 | 15/01/2015 | 04/06/2015 
        /// 2%         | 2%         |  2%        
        /// </summary>
        public static Schedule GetLevels(this Schedule s1, Schedule levels)
        {
            var res = new Schedule(s1.Dates.ToArray());
            for (var i = 0; i < res.Count; i++)
            {
                if (res[i].Item != null)
                {
                    var item = levels.FindFirst(res[i].Date);
                    if (item.Item == null)
                    {
                        res[i].Item = null;
                    }
                    else
                    {
                        res[i].Item.Value = item.Item.Value;
                    }
                }
            }
            return res;
        }

        public static Schedule Apply(this Schedule s1, Func<double,  double> f)
        {
            var res = s1.Clone();
            for(var i=0;i<res.Count;i++)
            {
                res[i].Item.Value = f(s1[i].Item.Value);
            }
            return res;
        }        

        public static Schedule Apply(this Schedule s1,Schedule s2,Func<double,double,double> f)
        {
            if (s1 == null) return s2;
            if (s2 == null) return s1;
            var res = s1.Clone().Merge(s2.Clone());
            var s11 = res.GetLevels(s1);
            var s22 = res.GetLevels(s2);
            for (var i = 0; i < res.Count; i++)
            {
                if (s11[i].Item != null && s22[i].Item != null)
                {
                    res[i].Item.Value = f(s11[i].Item.Value, s22[i].Item.Value);
                }
                else
                {
                    res[i].Item = null;
                }
            }
            // remove ScheduleItem with null items:
            res=new Schedule(res.ToListOfScheduleItem().Where(item => item.Item != null).ToList());
            return res;
        }
    }
}
