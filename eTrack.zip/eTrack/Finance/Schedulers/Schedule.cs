﻿using Finance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Finance
{    
       

    /// <summary>
    /// Collection of SheduleItem, ordered by item's dates.
    /// NB. Maybe not ordered when accessed via extension methods (Skip(), ToList()...). To be checked.
    /// </summary>
    public class Schedule : IList<ScheduleItem>
    {
        protected List<ScheduleItem> _Schedule;
        protected bool _IsSorted = false;

        #region ctors
        public Schedule()
        {
            _Schedule = new List<ScheduleItem>();
        }
        public Schedule(List<ScheduleItem> list)
        {
            _Schedule = list;
            _IsSorted = false;
        }
        public Schedule(params DateTime[] args)
            : this()
        {
            foreach (var date in args)
            {
                this.Add(new ScheduleItem() { Date = date });
            }
            this.Sort();
        }
        public Schedule(List<Accrual> list):this()
        {
            foreach (var accrual in list)
            {
                this.Add(new ScheduleItem() { Date = accrual.StartDate, Item = new Item() { Value = accrual.Amount } });
            }
            this.Sort();
        }
        public Schedule(List<CashFlow> list)
            : this()
        {
            foreach (var accrual in list)
            {
                this.Add(new ScheduleItem() { Date = accrual.PaymentDate, Item = new Item() { Value = accrual.Amount } });
            }
            this.Sort();
        }
        #endregion

        #region custom methods

        /// <summary>
        /// Return the last item index whose date is before or equal to the target date.
        /// Return the first or last item index if target is outside the timeframe.
        /// </summary>
        /// <param name="date">The target date</param>
        /// <returns></returns>
        public int FindFirstIndex(DateTime date)
        {
            // before all
            if (date <= this[0].Date) return 0;
            // after all
            if (date >= this.Last().Date) return this.Count-1;
            for (var i = 1; i < this.Count; i++)
            {
                if (date >=this[i - 1].Date && date < this[i].Date) return i-1;
            }
            return 0;
        }

        /// <summary>
        /// Return the first item index whose date is strictly after the target date.
        /// Return the first or last item index if target is outside the timeframe.
        /// </summary>
        /// <param name="date">The target date</param>
        /// <returns></returns>
        public int FindNextIndex(DateTime date)
        {
            // before all
            if (date <= this[0].Date) return 0;
            // after all
            if (date >= this.Last().Date) return this.Count-1;
            for (var i = 1; i < this.Count; i++)
            {
                if (date >this[i - 1].Date && date <= this[i].Date) return i;                
            }
            return 0;
        }

        /// <summary>
        /// Return the last item whose date is before or equal to the target date.
        /// Return the first or last item if target is outside the timeframe.
        /// </summary>
        /// <param name="date">The target date</param>
        /// <returns></returns>
        public ScheduleItem FindFirst(DateTime date)
        {
            var index = FindFirstIndex(date);
            return this[index];
        }

        /// <summary>
        /// Return the first item whose date is strictly after the target date.
        /// Return the first or last item if target is outside the timeframe.
        /// </summary>
        /// <param name="date">The target date</param>
        /// <returns></returns>
        public ScheduleItem FindNext(DateTime date)
        {
            var index = FindNextIndex(date);
            return this[index];
        }

        // <summary>
        /// Return the first item index whose date is strictly after the target date.
        /// Return null if target is outside the timeframe.
        /// </summary>
        /// <param name="date">The target date</param>
        /// <returns></returns>
        public ScheduleItem FindFirstInside(DateTime date)
        {
            // before all
            if (date <= this[0].Date) return null;
            // after all
            if (date >= this.Last().Date) return null;
            for (var i = 1; i < this.Count; i++)
            {
                if (date >= this[i - 1].Date && date < this[i].Date) return this[i - 1];
            }
            return null;
        }
        
        /// <summary>
        /// Return the first item whose date is strictly after the target date.
        /// Return null if target is outside the timeframe.
        /// </summary>
        /// <param name="date">The target date</param>
        /// <returns></returns>
        public ScheduleItem FindNextInside(DateTime date)
        {
            // before all
            if (date <= this[0].Date) return null;
            // after all
            if (date >= this.Last().Date) return null;
            for (var i = 1; i < this.Count; i++)
            {
                if (date >= this[i - 1].Date && date < this[i].Date) return this[i];
            }
            return null;
        }


        /// <summary>
        /// Risk: last scheduleItem ignored...
        /// </summary>
        /// <returns></returns>
        public List<Accrual> ToAccruals(Currency currency)
        {
            var res = new List<Accrual>();
            for (var i = 0; i < _Schedule.Count - 1; i++)
            {
                var si = _Schedule[i];
                var accrual = new Accrual(si.Date, _Schedule[i + 1].Date, si.Item.Value) { Currency = currency };
                res.Add(accrual);
            }
            return res;
        }

        public List<CashFlow> ToCashFlows(Currency currency)
        {
            var res = new List<CashFlow>();
            for (var i = 0; i < _Schedule.Count; i++)
            {
                var si = _Schedule[i];
                var cf = new CashFlow(si.Date, currency, si.Item.Value);
                res.Add(cf);
            }
            return res;
        }

        public static Schedule CreateEmptySchedule(DateTime startDate, DateTime endDate, Frequency frequency = Frequency.Yearly)
        {
            var result = new Schedule();
            while (startDate < endDate)
            {
                result.Add(new ScheduleItem() { Date = startDate });
                startDate = startDate.AddMonths((int)frequency);
            }
            result.Add(new ScheduleItem() { Date = endDate });
            return result;
        }

        public void Sort()
        {
            _Schedule = this.OrderBy(s => s.Date).ToList();
        }

        public List<DateTime> Dates
        {
            get
            {
                var res = new List<DateTime>();
                foreach(var item in this)
                {
                    res.Add(item.Date);
                }
                return res;
            }
        }

        public Schedule Clone()
        {
            var res = new Schedule(this.Dates.ToArray());
            for(var i=0;i<res.Count;i++)
            {
                if (this[i].Item == null)
                {
                    res[i].Item = null;
                }
                else
                {
                    res[i].Item = this[i].Item.Clone();
                }
            }
            return res;
        }

        public static Schedule operator +(Schedule s1, Schedule s2)
        {
            var result = s1.Apply(s2, (a, b) => a + b);
            return result;
        }

        public static Schedule operator -(Schedule s1, Schedule s2)
        {
            var result = s1.Apply(s2, (a, b) => a - b);
            return result;
        }

        public static Schedule operator *(Schedule s1, Schedule s2)
        {
            var result = s1.Apply(s2, (a, b) => a * b);
            return result;
        }
        public static Schedule operator /(Schedule s1, Schedule s2)
        {
            var result = s1.Apply(s2, (a, b) => a / b);
            return result;
        }



        ///// <summary>
        ///// 01/01/2015 | 15/01/2015 | 04/06/2015  *  01/02/2015 | 01/08/2015
        ///// 100        | 100        | 200         *  2%         | 3%
        ///// 01/01/2015 | 15/01/2015 | 01/02/2015 | 04/06/2015 | 01/08/2015
        ///// 0          | 0          |  2         | 4          | 6
        ///// </summary>
        ///// <param name="s1"></param>
        ///// <param name="s2"></param>
        ///// <returns></returns>
        //public static Schedule operator *(Schedule s1, Schedule s2)
        //{
        //    if (s1 == null || s1.Count==0) return null;
        //    if (s2 == null || s2.Count==0) return null;
        //    var result = s1+s2;
        //    for (var i = 0; i < result.Count;i++)
        //    {
        //        var date = result[i].Date;
        //        var left = s1.FindFirstInside(date);
        //        var right = s2.FindFirstInside(date);
        //        if (left == null)
        //        {
        //            result[i].Item.Value = 0.0;
        //            result[i].Item.Formula = string.Format("{1:#,##0.00}*({0})", 0.0,right.Item.Formula);
        //        }
        //        else
        //        {
        //            if (right == null)
        //            {
        //                result[i].Item.Value = 0.0;
        //                result[i].Item.Formula = string.Format("({0})*{1:#,##0.00}", left.Item.Formula, 0.0);
        //            }
        //            else
        //            {
        //                result[i].Item.Value =left.Item.Value*right.Item.Value;
        //                result[i].Item.Formula=string.Format("({0})*{1:#,##0.00}",left.Item.Formula,right.Item.Value);
        //            }
        //        }

        //    }
        //    return result;
        //}


        public List<ScheduleItem> ToListOfScheduleItem() { return _Schedule; }

        public void Add(DateTime date)
        {
            this.Add(new ScheduleItem() { Date = date });
        }

        public void Add(DateTime date, double amount)
        {
            this.Add(new ScheduleItem() { Date = date, Item = new Item() { Value = amount } });
        }

        public void Add(DateTime date, double amount, string comment)
        {
            this.Add(new ScheduleItem() { Date = date, Item = new Item() { Value = amount, Comment = comment } });
        }
        
        #endregion

        #region ICollection

        public void Add(ScheduleItem item)
        {
            _Schedule.Add(item);
            _IsSorted = false;
        }

        public void Clear()
        {
            _Schedule.Clear();
        }

        public bool Contains(ScheduleItem item)
        {
            return _Schedule.Contains(item);
        }

        public void CopyTo(ScheduleItem[] array, int arrayIndex)
        {
            _Schedule.CopyTo(array, arrayIndex);
        }

        public int Count
        {
            get { return _Schedule.Count; }
        }

        public bool IsReadOnly
        {
            get { return false; }
        }

        public bool Remove(ScheduleItem item)
        {
            return _Schedule.Remove(item);
        }

        public IEnumerator<ScheduleItem> GetEnumerator()
        {
            if (_IsSorted == false)
            {
                _Schedule.OrderBy(s => s.Date);
                _IsSorted = true;
            }
            return _Schedule.GetEnumerator();
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            if (_IsSorted == false)
            {
                _Schedule.OrderBy(s => s.Date);
                _IsSorted = true;
            }
            return _Schedule.GetEnumerator();
        }
        #endregion

        #region IList
        public int IndexOf(ScheduleItem item)
        {
            return _Schedule.IndexOf(item);
        }

        public void Insert(int index, ScheduleItem item)
        {
            _Schedule.Insert(index, item);
        }

        public void RemoveAt(int index)
        {
            _Schedule.RemoveAt(index);
        }

        public ScheduleItem this[int index]
        {
            get
            {
                return _Schedule[index];
            }
            set
            {
                _Schedule[index] = value;
            }
        }
        #endregion
    }
}