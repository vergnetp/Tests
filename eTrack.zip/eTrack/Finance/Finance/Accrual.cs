﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Finance
{
    
    public class Accrual
    {
        public Accrual(DateTime startDate)
        {
            this.StartDate = startDate;
            this.Currency = Currency.Default;
        }
        public Accrual(DateTime startDate,DateTime endDate,double amount=0.0)
        {
            this.StartDate = startDate;
            this.EndDate = endDate;
            this.Amount = amount;
            this.Currency = Currency.Default;
        }
        public DateTime StartDate { get; set; }
        private DateTime _EndDate;
        public DateTime EndDate { get { if (_EndDate == DateTime.MinValue) { return this.StartDate; } else { return _EndDate; } } set { _EndDate = value; } }
        private DateTime _PaymentDate;
        public DateTime PaymentDate { get { if (_PaymentDate == DateTime.MinValue) { return this.EndDate; } else { return _PaymentDate; } } set { _PaymentDate = value; } }
        public double Amount { get; set; }
        public Currency Currency { get; set; }
        
    }

    
   
}