﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Finance
{
    public class Calculator
    {

        /// <summary>
        /// Only works on annual rates
        /// </summary>
        /// <param name="accrualScheduler"></param>
        /// <param name="annualRates"></param>
        /// <param name="currency"></param>
        /// <returns></returns>
        public static List<Accrual> GetAccruals(Scheduler accrualScheduler, Schedule annualRates, Currency currency)
        {
            var res = new List<Accrual>();
            var schedule = accrualScheduler.Schedule;
            for (var i = 0; i < schedule.Count - 1; i++)
            {
                var start = schedule[i].Date;
                var end = schedule[i + 1].Date;
                var accrual = new Accrual(start, end);
                accrual.Currency = currency;
                var accruedAmount = 0.0;
                var dayCount = DayCount.ActAct;
                for (var j = 0; j < annualRates.Count - 1; j++)
                {
                    var factor = DateHelper.Yearfrac(DateHelper.Max(annualRates[j].Date, start), DateHelper.Min(annualRates[j + 1].Date, end), dayCount);
                    accruedAmount += annualRates[j].Item.Value * Math.Max(0.0, factor);
                }
                accrual.Amount = accruedAmount;
                res.Add(accrual);
            }
            return res;
        }

        public static List<CashFlow> GetCashFlows(PaymentScheduler paymentScheduler, List<Accrual> accruals, Currency currency)
        {
            var schedule = paymentScheduler.Schedule;
            for (var i = 0; i < schedule.Count; i++)
            {
                var cashFlow = 0.0;
                if (paymentScheduler.InAdvance)
                {
                    cashFlow = accruals.Where
                        (
                            accrual =>
                            (i == 0 && accrual.StartDate <= schedule[i].Date)
                            ||
                            (i > 0 && accrual.StartDate > schedule[i - 1].Date && accrual.StartDate <= schedule[i].Date)
                        )
                        .Sum(accrual => accrual.Amount);
                }
                else
                {
                    cashFlow = accruals.Where
                        (
                            accrual =>
                            (i == 0 && accrual.EndDate <= schedule[i].Date)
                            ||
                            (i > 0 && accrual.EndDate > schedule[i - 1].Date && accrual.EndDate <= schedule[i].Date)
                        )
                        .Sum(accrual => accrual.Amount);
                }
                schedule[i].Item.Value = cashFlow;
            }
            var res = schedule.ToCashFlows(currency);
            return res;
        }
   
      
    }
}
