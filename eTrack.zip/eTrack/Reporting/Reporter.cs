﻿using Finance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Reporting
{
    public interface IFxConverter
    {
        double GetFXRate(DateTime date, Currency source, Currency destination);
    }
    public class DefaultFxConverter : IFxConverter
    {
        public double GetFXRate(DateTime date, Currency source, Currency destination) { return 1.0; }
    }

    /// <summary>
    /// Transform lists of accruals or CF into a Schedule of a given frequency, start, end and currency.
    /// The reporting currency can also be inputed.
    /// </summary>
    public class Reporter
    {
        private DateTime _StartDate;
        private DateTime _EndDate;
        private Frequency _Frequency;
        private Currency _ReportingCurrency;
        private IFxConverter _FxConverter = new DefaultFxConverter();

        public Reporter(DateTime startDate, DateTime endDate, Currency reportingCurrency, Frequency frequency = Frequency.Yearly, IFxConverter fxConverter = null)
        {
            _StartDate = startDate; _EndDate = endDate; _Frequency = frequency; _ReportingCurrency = reportingCurrency;
            _FxConverter = fxConverter == null ? new DefaultFxConverter() : fxConverter;
        }
        public Reporter(DateTime startDate, DateTime endDate, Frequency frequency = Frequency.Yearly)
        {
            _StartDate = startDate; _EndDate = endDate; _Frequency = frequency; 
            _FxConverter = new DefaultFxConverter();
        }

        /// <summary>
        /// List of cashflows paid between the previous item's date and the current one.   
        /// </summary>
        /// <param name="cashFlows"></param>
        /// <returns></returns>
        public Schedule ReportCashFlows(List<CashFlow> cashFlows)
        {
            var result = Schedule.CreateEmptySchedule(_StartDate, _EndDate, _Frequency);
            cashFlows.OrderBy(c => c.PaymentDate);
            var startDate = _StartDate.AddDays(-1);
            result.RemoveAt(0);
            foreach (var endPeriodItem in result)
            {
                var cumulatedCashFlow = cashFlows.Where(c => c.PaymentDate > startDate && c.PaymentDate <= endPeriodItem.Date).Sum(c => c.Amount * (_ReportingCurrency==null?1.0:_FxConverter.GetFXRate(c.PaymentDate, c.Currency, _ReportingCurrency)));
                endPeriodItem.Item = new Item() { Value = cumulatedCashFlow };
                startDate = endPeriodItem.Date;
            }
            return result;
        }

        public double CalculateAccrual(List<Accrual> accruals, DateTime start, DateTime end, DayCount dayCount)
        {
            var result = 0.0;
            // accruals null or empty
            if (accruals == null || !accruals.Any()) return 0.0;
            // accruals start after
            if (accruals.First().StartDate > end) return 0.0;
            // accruals start and finish in the middle
            if (accruals.First().StartDate > start && accruals.Last().EndDate < end) return accruals.Sum(a => a.Amount);
            // Else:
            for (int i = 0; i < accruals.Count; i++)
            {
                var accruedAmount = 0.0;
                var fxRate = 1.0;
                if (_ReportingCurrency != null) fxRate = _FxConverter.GetFXRate(accruals[i].PaymentDate, accruals[i].Currency, _ReportingCurrency);
                var yearFrac = DateHelper.Yearfrac(DateHelper.Max(start, accruals[i].StartDate), DateHelper.Min(end, accruals[i].EndDate), dayCount) / DateHelper.Yearfrac(accruals[i].StartDate, accruals[i].EndDate, dayCount);
                // accrual start before and finishes within the period | start,accual
                if (accruals[i].StartDate <= start && accruals[i].EndDate > start && accruals[i].EndDate <= end)
                {
                    accruedAmount = accruals[i].Amount * fxRate * yearFrac;
                }
                // accrual start before and finishes after the period | start,end
                if (accruals[i].StartDate <= start && accruals[i].EndDate > start && accruals[i].EndDate > end)
                {
                    accruedAmount = accruals[i].Amount * fxRate * yearFrac;
                }
                // accrual start and finishes within period | accrual,accrual
                if (accruals[i].StartDate > start && accruals[i].EndDate <= end)
                {
                    accruedAmount = accruals[i].Amount * fxRate * yearFrac;
                }
                // accrual start within the period and finishes after | accrual,end
                if (accruals[i].StartDate > start && accruals[i].StartDate <= end && accruals[i].EndDate > end)
                {
                    accruedAmount = accruals[i].Amount * fxRate * yearFrac;
                }                        
                result += accruedAmount;
            }
            return result;
        }

        /// <summary>
        /// List of amounts accrued.
        /// </summary>
        /// <param name="accruals"></param>
        /// <param name="start"></param>
        /// <param name="end"></param>
        /// <param name="dayCount"></param>
        /// <returns></returns>
        public Schedule ReportAccruals(List<Accrual> accruals, DayCount dayCount)
        {
            var result = Schedule.CreateEmptySchedule(_StartDate, _EndDate, _Frequency);
            accruals.OrderBy(a => a.StartDate);
            for (var i = 0; i < result.Count - 1; i++)
            {
                var accruedAmount = this.CalculateAccrual(accruals, result[i].Date, result[i + 1].Date, dayCount);
                result[i].Item = new Item() { Value = accruedAmount };
            }
            result.RemoveAt(result.Count - 1);
            return result;
        }

        /// <summary>
        /// List of amounts accrued.
        /// </summary>
        /// <param name="accruals"></param>
        /// <param name="reportingSchedule"></param>
        /// <param name="dayCount"></param>
        /// <returns></returns>
        public Schedule ReportAccruals(List<Accrual> accruals, Schedule reportingSchedule,DayCount dayCount)
        {           
            accruals.OrderBy(a => a.StartDate);
            for (var i = 0; i < reportingSchedule.Count - 1; i++)
            {
                var accruedAmount = this.CalculateAccrual(accruals, reportingSchedule[i].Date, reportingSchedule[i + 1].Date, dayCount);
                reportingSchedule[i].Item = new Item() { Value = accruedAmount };
            }
            reportingSchedule.RemoveAt(reportingSchedule.Count - 1);
            return reportingSchedule;
        }
             
    
    }
}