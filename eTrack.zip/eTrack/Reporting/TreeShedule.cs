﻿using Finance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Reporting
{
    public class TreeSchedule : Schedule
    {
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public Frequency Frequency { get; set; }
        public TreeSchedule() { this.Children = new List<TreeSchedule>(); ReCalculate(); }
        public TreeSchedule(DateTime startDate, DateTime endDate, Frequency frequency = Frequency.Yearly)
            : this()
        {
            _Schedule = Schedule.CreateEmptySchedule(startDate, endDate, frequency).ToListOfScheduleItem();
        }
        public TreeSchedule(Schedule schedule) : this() { _Schedule = schedule.ToListOfScheduleItem(); }
        public string Name { get; set; }
        public string Level { get; set; }
        public List<TreeSchedule> Children { get; set; }
        public void AddEmptyNode()
        {
            this.Children.Add(new TreeSchedule(StartDate, EndDate, Frequency));
        }

        /// <summary>
        /// Aggregate children. Requires same number of items (same dates)
        /// WARNING: no check on that.
        /// </summary>
        public void ReCalculate()
        {
            foreach (var schedule in this.Children)
            {
                for (int i = 0; i < this.Count; i++)
                {
                    _Schedule[i].Item.Value += schedule[i].Item.Value;
                }
            }

        }
    }
}