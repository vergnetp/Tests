﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace BigData
//{
    
//    public class Brain : IDisposable
//    {
//        Encoder _Encoder; Solver _Solver;

//        public Brain(Encoder encoder = null, Solver solver = null)
//        {
//            _Encoder = encoder ?? new Encoder(new MissingDataAverageAndNA(new DataPreparator())); _Solver = solver ?? new SolverGradientDescent();
//        }

//        public string TEMP_FOLDER = @"C:\temp";

//        public void Predict(string decodedPredFile, string testFile, int[] dependentColumns, long offset = 0, long size = long.MaxValue) { _Encoder.EncodeTest(EncodedXTestFile, null, testFile, dependentColumns, offset, size); _Solver.Predict(EncodedYPredFile, EncodedXTestFile, 0, long.MaxValue); _Encoder.DecodeYPred(decodedPredFile, EncodedYPredFile, 0, long.MaxValue); }
//        public bool Fit(string trainingFile, int[] dependentColumns, long offset, long size) { _Encoder.EncodeTrain(EncodedXTrainFile, EncodedYTrainFile, trainingFile, dependentColumns, offset, size); return _Solver.Fit(EncodedXTrainFile, EncodedYTrainFile, 0, long.MaxValue); }

//        public void Dispose()
//        {
//            _Encoder.DeleteFiles();
//        }
//        ~Brain() { Dispose(); }
//    }
    
//    public class Solver:ISolver
//    {

//        public void Predict(string encodedPredFile, string encodedXFile, long offset = 0, long size = long.MaxValue) { }
//        public bool Fit(string encodedXTrainFile, string encodedYTrainFile, long offset, long size) { return true; }

//        //public IModel Model
//        //{
//        //    get
//        //    {
//        //        throw new NotImplementedException();
//        //    }
//        //    set
//        //    {
//        //        throw new NotImplementedException();
//        //    }
//        //}

//        public Encoder Encoder
//        {
//            get
//            {
//                throw new NotImplementedException();
//            }
//            set
//            {
//                throw new NotImplementedException();
//            }
//        }

//        public int MaxIterations
//        {
//            get
//            {
//                throw new NotImplementedException();
//            }
//            set
//            {
//                throw new NotImplementedException();
//            }
//        }

//        public float LearningRate
//        {
//            get
//            {
//                throw new NotImplementedException();
//            }
//            set
//            {
//                throw new NotImplementedException();
//            }
//        }

//        public float ConvergenceThreshold
//        {
//            get
//            {
//                throw new NotImplementedException();
//            }
//            set
//            {
//                throw new NotImplementedException();
//            }
//        }

//        public float[] Solution
//        {
//            get { throw new NotImplementedException(); }
//        }

//        public int LastIteration
//        {
//            get { throw new NotImplementedException(); }
//        }

//        public void UpdateModelWeights(float[,] XTrain, float[,] YTrain)
//        {
//            throw new NotImplementedException();
//        }

//        public bool Fit(float[,] XTrain, float[,] YTrain)
//        {
//            throw new NotImplementedException();
//        }

//        public Task<bool> FitAsync(float[,] XTrain, float[,] YTrain)
//        {
//            throw new NotImplementedException();
//        }

//        public void Reset()
//        {
//            throw new NotImplementedException();
//        }

//        public ISolver Clone()
//        {
//            throw new NotImplementedException();
//        }

//        public event EventHandler EpochCompleted;

//        public event EventHandler ResetCalled;
//    }
//}
