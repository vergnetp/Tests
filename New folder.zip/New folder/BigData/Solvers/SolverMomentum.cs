﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace BigData
{
    [DataContract]
    public class SolverMomentum : SolverGradientDescent
    {

        [DataMember]
        public float Momentum { get; set; }

        [DataMember]
        protected float[] _PreviousUpdates;

        public SolverMomentum(IModel model = null, IRepository repo = null, MissingDataHandler missingDataHandler = null,
         int maxIterations = 20000, float convergenceThreashold = 0.00001F, float learningRate = 0.25F, float momentum = 0.2F, MinY minY = MinY.MinusOne, ILogger logger = null)
            : base(model, repo,missingDataHandler, maxIterations, convergenceThreashold, learningRate, minY, logger)
        {
            Momentum = momentum;
        }

        public override void UpdateModelWeights(float[,] XTrain, float[,] YTrain)
        {
            var gradient = Model.GetGradients(XTrain, YTrain);
            if (_PreviousUpdates == null || !Model.Weights.Length.Equals(_PreviousUpdates.Length)) _PreviousUpdates = new float[Model.Weights.Length];
            var oldWeights = Model.Weights;
            Model.Weights = Model.Weights.Select((value, index) => value - gradient[index] * LearningRate - _PreviousUpdates[index] * Momentum).ToArray();
            _PreviousUpdates = Model.Weights.Subtract(oldWeights);
        }
    }
}
