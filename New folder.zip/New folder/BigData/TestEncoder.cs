﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigData
{
    public class TestEncoder
    {
        public static void Test()
        {
            var repo = new RepositoryCsv(@"C:\Users\philippe\Desktop");
            var logger = new LoggerConsole();
            var dataPreparator = new DataPreparator(repo);
            var encoder = new Encoder(new MissingDataAverageAndNA(dataPreparator, logger, repo), repo, logger);
            encoder.EncodeTrain("train", new[] { 1 },offset:400,size:30,minY:MinY.MinusOne);
            encoder.DecodeX("decodedX", "XTrain",MinY.MinusOne);
            encoder.DecodeY("decodedY", "YTrain", MinY.MinusOne);
        }
    }
}
