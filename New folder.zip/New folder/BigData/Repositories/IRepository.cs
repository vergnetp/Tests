﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigData
{
    public interface IRepository
    {
        void Initialize(string address, string user, string pwd);

        long GetNbRows(string table);
        int GetNbColumns(string table);
        string[] Header(string table);

        float[,] ImportAsFloat(string table, long offset = 0, long size = long.MaxValue);
        string[,] Import(string table, long offset = 0, long size = long.MaxValue);

        void InsertData(string table, float[,] data);  
          
        void Export(string table, string[,] data, bool hasHeader);
        void InsertData(string table, string[,] data, bool hasHeader);

        void Export(string table, string[] data);
        void InsertRow(string table, string[] data);

        void Delete(string table);
        void Clear(string table);
    }
}
