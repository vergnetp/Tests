﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigData
{

    /// <summary>
    /// The dependent variable range needs to be accessible from the activation functions of neural networks.
    /// So it is best to ensure the range is between MinY and 1 (minY can be 0 or -1)
    /// </summary>
    public enum MinY
    {
        MinusOne = -1,
        Zero = 0
    }

    public class Encoder
    {        
        public MissingDataHandler MissingDataHandler;
        public IRepository Repo;
        protected ILogger _Logger;
        protected MinY _MinY;
        public string[] xEncodedHeader;
        public string[] yEncodedHeader;
        public bool IsEncoded = false;

        public Encoder(MissingDataHandler missingDataHandler,IRepository repo,ILogger logger)
        { 
            MissingDataHandler = missingDataHandler;
            Repo = repo; 
            _Logger = logger;
        }

        protected void GetEncodedHeaders(string trainingName, int[] dependentColumns)
        {
            var header = Repo.Header(trainingName);
            var lx = new List<string>(); var ly = new List<string>();
            for(var j=0;j<header.Length;j++)
            {
                if (MissingDataHandler.DataPreparator.ColumnTypes[j] == ColumnType.Categorical)
                {
                    for (var k = 0; k < MissingDataHandler.DataPreparator.DistinctValues[j].Count; k++)
                    {
                        if (dependentColumns != null && dependentColumns.Contains(j))
                        {
                            ly.Add(header[j]);
                        }
                        else
                        {
                            lx.Add(header[j]);
                        }
                    }
                }
                else
                {
                    if (dependentColumns!=null && dependentColumns.Contains(j))
                    {
                        ly.Add(header[j]);
                    }
                    else
                    {
                        lx.Add(header[j]);
                    }
                }                
            }
            xEncodedHeader = lx.ToArray(); yEncodedHeader = ly.ToArray();
        }

        protected void Encode(string encodedXName, string encodedYName, string completeName, string preparedName, string trainingName, int[] dependentColumns, long offset, long size,MinY minY,bool doTrain)
        {
            Repo.Clear(encodedXName); Repo.Clear(encodedYName);
            _MinY = minY;
            
            var curOffset = 0L; var curSize = long.MaxValue;
            var lastRow = curOffset + curSize;
            var firstRow = Repo.Header(trainingName); 
            if (!IsEncoded) { GetEncodedHeaders(trainingName, dependentColumns); }
            Repo.Export(encodedXName, xEncodedHeader);
            Repo.Export(encodedYName, yEncodedHeader);
            var n = (long)firstRow.Length;
            var maxSize = 1000 * 1000 / n;// 1000 * 1000 / n; // We allow a 64MB array max
            var subSize = Math.Min(curSize, maxSize);
            var subData = Repo.Import(completeName, curOffset, subSize);
            do
            {
                float[,] X; float[,] Y;
                if (dependentColumns!=null)
                {
                    EncoderTool.Encode(subData, dependentColumns,
                        MissingDataHandler.DataPreparator.DistinctValues, MissingDataHandler.DataPreparator.ColumnTypes,
                        MissingDataHandler.DataPreparator.Means, MissingDataHandler.DataPreparator.StdDevs,
                         MissingDataHandler.DataPreparator.Mins, MissingDataHandler.DataPreparator.Maxs, minY,
                        out X, out Y);
                }
                else
                {
                    EncoderTool.Encode(subData, null,
                    MissingDataHandler.DataPreparator.XDistinctValues, MissingDataHandler.DataPreparator.XColumnTypes,
                    MissingDataHandler.DataPreparator.XMeans, MissingDataHandler.DataPreparator.XStdDevs,
                     MissingDataHandler.DataPreparator.XMins, MissingDataHandler.DataPreparator.XMaxs, minY,
                    out X, out Y);
                }
                Repo.InsertData(encodedXName,  X);
                Repo.InsertData(encodedYName,  Y);
                curOffset += subSize;
                subSize = Math.Min(subSize, lastRow);
                subData = Repo.Import(completeName, curOffset, subSize);
            } while (subData != null);
            
        }
        public void EncodeTrain(string trainingName, int[] dependentColumns, string encodedXName="XTrain", string encodedYName="YTrain", long offset=0, long size=long.MaxValue, MinY minY = MinY.MinusOne, string completeTrainDataName = "CompleteTrain", string preparedTrainDataName = "PreparedTrain")
        {
            IsEncoded = false;
            MissingDataHandler.HandleTrain(completeTrainDataName, preparedTrainDataName, trainingName, dependentColumns, offset, size);
            Encode(encodedXName, encodedYName, completeTrainDataName, preparedTrainDataName, trainingName, dependentColumns, offset, size,minY,true);
            IsEncoded = true;
        }
        public void EncodeTest(string testName, int[] dependentColumns, string encodedXName="XTest", string encodedYName="YTest", long offset = 0, long size = long.MaxValue, MinY minY = MinY.MinusOne, string completeTestDataName = "CompleteTest", string preparedTestDataName = "PreparedTest")
        {
            if (!IsEncoded) throw new Exception("You must encode the training Data first, before encoding the test set.");
            MissingDataHandler.HandleTest(completeTestDataName, testName, testName, dependentColumns, offset, size);
            Encode(encodedXName, encodedYName, completeTestDataName, testName, testName, dependentColumns, offset, size,minY,false);
        }

        public void DecodeX(string outputName, string xName, MinY minY)
        {
            Repo.Clear(outputName);
            var offset = 0L; var size = long.MaxValue;
            var lastRow = offset + size;
            var firstRow = Repo.Header(xName);
            var header = MissingDataHandler.DataPreparator.XHeader;
            Repo.Export(outputName, header);
            var n = (long)firstRow.Length;
            var maxSize = 1000 * 1000 / n;// 1000 * 1000 / n; // We allow a 64MB array max
            var subSize = Math.Min(size, maxSize);
            var subData = Repo.ImportAsFloat(xName,  offset, subSize);
            do
            {
                var X = EncoderTool.DecodeX(subData, MissingDataHandler.DataPreparator.XDistinctValues, MissingDataHandler.DataPreparator.XColumnTypes, MissingDataHandler.DataPreparator.XMeans, MissingDataHandler.DataPreparator.XStdDevs,minY);
                Repo.InsertData(outputName, X,false);
                offset += subSize;
                subSize = Math.Min(subSize, lastRow - offset);
                subData = Repo.ImportAsFloat(xName, offset, subSize);
            } while (subData != null);
        }

        public void DecodeY(string outputName, string yName, MinY minY) 
        {
            Repo.Clear(outputName);
            var offset = 0L; var size = long.MaxValue;
            var lastRow = offset + size;
            var firstRow = Repo.Header(yName);
            var header = MissingDataHandler.DataPreparator.YHeader;
            Repo.Export(outputName, header);
            var n = (long)firstRow.Length;
            var maxSize = 1000 * 1000 / n;// 1000 * 1000 / n; // We allow a 64MB array max
            var subSize = Math.Min(size, maxSize);
            var subData = Repo.ImportAsFloat(yName, offset, subSize);
            do
            {
                var X = EncoderTool.DecodeY(subData, MissingDataHandler.DataPreparator.YDistinctValues, 
                    MissingDataHandler.DataPreparator.YColumnTypes, MissingDataHandler.DataPreparator.YMeans,
                    MissingDataHandler.DataPreparator.YStdDevs, MissingDataHandler.DataPreparator.YMins,
                    MissingDataHandler.DataPreparator.YMaxs,minY);
                Repo.InsertData(outputName, X, false);
                offset += subSize;
                subSize = Math.Min(subSize, lastRow - offset);
                subData = Repo.ImportAsFloat(yName, offset, subSize);
            } while (subData != null);
        
        }
        
    }

   
}
