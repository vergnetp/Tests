﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigData
{

    /// <summary>
    /// The dependent variable range needs to be accessible from the activation functions of neural networks.
    /// So it is best to ensure the range is between MinY and 1 (minY can be 0 or -1)
    /// </summary>
    public enum MinY
    {
        MinusOne = -1,
        Zero = 0
    }

    public class Encoder
    {        
        protected MissingDataHandler _MissingDataHandler;
        protected IRepository _Repo;
        protected ILogger _Logger;
        protected MinY _MinY;

        public Encoder(MissingDataHandler missingDataHandler,IRepository repo,ILogger logger)
        { 
            _MissingDataHandler = missingDataHandler;
            _Repo = repo; 
            _Logger = logger;
        }

        protected void GetHeader(string trainingName, int[] dependentColumns,out string[] xHeader,out string[] yHeader)
        {
            var header = _Repo.Header(trainingName);
            var lx = new List<string>(); var ly = new List<string>();
            for(var j=0;j<header.Length;j++)
            {
                if (_MissingDataHandler.DataPreparator.ColumnTypes[j] == ColumnType.Categorical)
                {
                    for (var k = 0; k < _MissingDataHandler.DataPreparator.DistinctValues[j].Count; k++)
                    {
                        if (dependentColumns.Contains(j))
                        {
                            ly.Add(header[j]);
                        }
                        else
                        {
                            lx.Add(header[j]);
                        }
                    }
                }
                else
                {
                    if (dependentColumns.Contains(j))
                    {
                        ly.Add(header[j]);
                    }
                    else
                    {
                        lx.Add(header[j]);
                    }
                }                
            }
            xHeader = lx.ToArray(); yHeader = ly.ToArray();
        }

        protected void Encode(string encodedXName, string encodedYName, string completeName, string preparedName, string trainingName, int[] dependentColumns, long offset, long size,MinY minY)
        {
            _Repo.Clear(encodedXName); _Repo.Clear(encodedYName);
            _MinY = minY;
            _MissingDataHandler.HandleTrain(completeName, preparedName, trainingName, dependentColumns, offset, size);
            var curOffset = 0L; var curSize = long.MaxValue;
            var lastRow = curOffset + curSize;
            var firstRow = _Repo.Header(trainingName);
            string[] xHeader; string[] yHeader;
            GetHeader(trainingName, dependentColumns, out xHeader,out  yHeader);
            _Repo.Export(encodedXName, xHeader);
            _Repo.Export(encodedYName, yHeader);
            var n = (long)firstRow.Length;
            var maxSize = 10;// 1000 * 1000 / n; // We allow a 64MB array max
            var subSize = Math.Min(curSize, maxSize);
            var subData = _Repo.Import(completeName, curOffset, subSize);
            do
            {
                float[,] X; float[,] Y;               
                EncoderTool.Encode(subData, dependentColumns, 
                    _MissingDataHandler.DataPreparator.DistinctValues, _MissingDataHandler.DataPreparator.ColumnTypes, 
                    _MissingDataHandler.DataPreparator.Means, _MissingDataHandler.DataPreparator.StdDevs,
                     _MissingDataHandler.DataPreparator.Mins, _MissingDataHandler.DataPreparator.Maxs, minY, 
                    out X, out Y);
                _Repo.InsertData(encodedXName,  X);
                _Repo.InsertData(encodedYName,  Y);
                curOffset += subSize;
                subSize = Math.Min(subSize, lastRow);
                subData = _Repo.Import(completeName, curOffset, subSize);
            } while (subData != null);
        }
        public void EncodeTrain(string trainingName, int[] dependentColumns, string encodedXName="XTrain", string encodedYName="YTrain", long offset=0, long size=long.MaxValue, MinY minY = MinY.MinusOne, string completeTrainDataName = "CompleteTrain", string preparedTrainDataName = "PreparedTrain")
        {
            Encode(encodedXName, encodedYName, completeTrainDataName, preparedTrainDataName, trainingName, dependentColumns, offset, size,minY);
        }
        public void EncodeTest(string testName, int[] dependentColumns, string encodedXName="XTest", string encodedYName="YTest", long offset = 0, long size = long.MaxValue, MinY minY = MinY.MinusOne, string completeTestDataName = "CompleteTest", string preparedTestDataName = "PreparedTest")
        {
            Encode(encodedXName, encodedYName, completeTestDataName, preparedTestDataName, testName, dependentColumns, offset, size,minY);
        }

        public void DecodeX(string outputName, string xName, MinY minY)
        {
            _Repo.Clear(outputName);
            var offset = 0L; var size = long.MaxValue;
            var lastRow = offset + size;
            var firstRow = _Repo.Header(xName);
            var header = _MissingDataHandler.DataPreparator.XHeader;
            _Repo.Export(outputName, header);
            var n = (long)firstRow.Length;
            var maxSize = 10;// 1000 * 1000 / n; // We allow a 64MB array max
            var subSize = Math.Min(size, maxSize);
            var subData = _Repo.ImportAsFloat(xName,  offset, subSize);
            do
            {
                var X = EncoderTool.DecodeX(subData, _MissingDataHandler.DataPreparator.XDistinctValues, _MissingDataHandler.DataPreparator.XColumnTypes, _MissingDataHandler.DataPreparator.XMeans, _MissingDataHandler.DataPreparator.XStdDevs,minY);
                _Repo.InsertData(outputName, X,false);
                offset += subSize;
                subSize = Math.Min(subSize, lastRow - offset);
                subData = _Repo.ImportAsFloat(xName, offset, subSize);
            } while (subData != null);
        }

        public void DecodeY(string outputName, string yName, MinY minY) 
        {
            _Repo.Clear(outputName);
            var offset = 0L; var size = long.MaxValue;
            var lastRow = offset + size;
            var firstRow = _Repo.Header(yName);
            var header = _MissingDataHandler.DataPreparator.YHeader;
            _Repo.Export(outputName, header);
            var n = (long)firstRow.Length;
            var maxSize = 10;// 1000 * 1000 / n; // We allow a 64MB array max
            var subSize = Math.Min(size, maxSize);
            var subData = _Repo.ImportAsFloat(yName, offset, subSize);
            do
            {
                var X = EncoderTool.DecodeY(subData, _MissingDataHandler.DataPreparator.YDistinctValues, 
                    _MissingDataHandler.DataPreparator.YColumnTypes, _MissingDataHandler.DataPreparator.YMeans,
                    _MissingDataHandler.DataPreparator.YStdDevs, _MissingDataHandler.DataPreparator.YMins,
                    _MissingDataHandler.DataPreparator.YMaxs,minY);
                _Repo.InsertData(outputName, X, false);
                offset += subSize;
                subSize = Math.Min(subSize, lastRow - offset);
                subData = _Repo.ImportAsFloat(yName, offset, subSize);
            } while (subData != null);
        
        }
        
    }

   
}
