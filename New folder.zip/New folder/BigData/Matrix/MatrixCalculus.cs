﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigData
{
    public static class MatrixCalculus
    {
        public static void ValidationPartition(float[,] X, float[,] Y, double trainingRatio, out float[,] XTrain, out float[,] YTrain, out float[,] XVal, out float[,] YVal)
        {
            var trainNumber = (int)(trainingRatio * X.GetLength(0));
            var indices = Accord.Math.Matrix.Indices(X.GetLength(0));
            Accord.Statistics.Tools.Shuffle(indices);
            var slots = Accord.Math.Matrix.Split(indices, trainNumber);
            var lastSlot = Accord.Math.Matrix.Submatrix(indices, slots[0].Length, indices.Length - 1);
            XTrain = Accord.Math.Matrix.Submatrix(X, slots.First());
            YTrain = Accord.Math.Matrix.Submatrix(Y, slots.First());
            XVal = Accord.Math.Matrix.Submatrix(X, lastSlot);
            YVal = Accord.Math.Matrix.Submatrix(Y, lastSlot);
        }

        /// <summary>
        /// Split X and Y into K smaller chunks
        /// </summary>
        /// <param name="X">Matrix X</param>
        /// <param name="Y">Matrix Y</param>
        /// <param name="K">How many chunks</param>
        /// <returns>A list of tuples of chunks of X and Y</returns>
        public static List<Tuple<float[,], float[,]>> KPartition(float[,] X, float[,] Y, int K)
        {
            var res = new List<Tuple<float[,], float[,]>>();
            var m = X.GetLength(0);
            var chunkSize = m / K;
            var indices = Accord.Math.Matrix.Indices(m);
            Accord.Statistics.Tools.Shuffle(indices);
            var chunkIndices = Accord.Math.Matrix.Split(indices, chunkSize);
            var lastChunkIndices = Accord.Math.Matrix.Submatrix(indices, chunkIndices[0].Length * chunkIndices.Length, indices.Length - 1);
            var lastX = Accord.Math.Matrix.Submatrix(X, lastChunkIndices);
            var lastY = Accord.Math.Matrix.Submatrix(Y, lastChunkIndices);
            foreach (var chunk in chunkIndices)
            {
                var subX = Accord.Math.Matrix.Submatrix(X, chunk);
                var subY = Accord.Math.Matrix.Submatrix(Y, chunk);
                res.Add(new Tuple<float[,], float[,]>(subX, subY));
            }
            if (lastX.Length > 0) res.Add(new Tuple<float[,], float[,]>(lastX, lastY));
            return res;
        }

        public static bool IsEqual(this string[,] a, string[,] b)
        {
            var res = true;
            Parallel.For(0, a.GetLength(0), i =>
            {
                for (var j = 0; j < a.GetLength(1); j++)
                {
                    if (a[i, j] == null)
                    {
                        res = res && b[i, j] == null;
                    }
                    else if (b[i, j] == null)
                    {
                        res = res && a[i, j] == null;
                    }
                    else
                    {
                        res = res && a[i, j].Equals(b[i, j]);
                    }
                }
            });
            return res;
        }

        public static bool IsEqual(this float[,] a, float[,] b)
        {
            var res = true;
            Parallel.For(0, a.GetLength(0), i =>
            {
                {
                    for (var j = 0; j < a.GetLength(1); j++)
                    {
                        res = res && a[i, j].Equals(b[i, j]);
                    }
                }
            });
            return res;
        }

        public static void Extract<T>(T[] a,int[] targetIndices,out T[] target,out T[] remainder)
        {
            target = new T[targetIndices.Length];
            remainder = new T[a.Length - targetIndices.Length];
            var k = 0; var k2 = 0;
            for (var i=0;i<a.Length;i++)
            {
                if (targetIndices.Contains(i))
                {
                    target[k] = a[i]; k++;
                }
                else
                {
                    remainder[k2] = a[i]; k2++;
                }
            }
        }

    }
}
