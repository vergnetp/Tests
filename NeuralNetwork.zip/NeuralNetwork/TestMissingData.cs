﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class TestMissingData
    {
        public static void Test()
        {
            var xTrain = new[,]
            {
            { "0","male"} ,
            {"","female"},
            {"2","male"},
            {"3",null}
            };
            var yTrain = new[,] {{ "0"}, {""}, {"1" },{"0"}};
            var xTest = new[,]
            {
            {"1",null},
            {"2","male"} ,
            {null,""},
            {"","female"}
            };
            var xColTypes=new[] { ColumnType.Numeric, ColumnType.Binary };
            var missingDataRemover = new MissingDataRemover();
            var missingDataAverage = new MissingDataAverageAndNA();
            string[,] xTestComplete, xTrainComplete,yTrainComplete;
            missingDataRemover.Handle(xTrain, yTrain, xTest, xColTypes, new[] { ColumnType.Binary },  out xTrainComplete, out yTrainComplete,out xTestComplete);
            var isOk=(xTrainComplete.Equal(new[,] { 
            { "0", "male" }, 
            { "2", "male" } }));
            isOk=isOk&&(xTestComplete.Equal(new[,] {  { "2", "male" } }));
            isOk = isOk && (yTrainComplete.Equal(new[,] { { "0" }, { "1" } }));
            missingDataAverage.Handle(xTrain, yTrain, xTest, xColTypes, new[] { ColumnType.Binary }, out xTrainComplete, out yTrainComplete, out xTestComplete);
            isOk = isOk && (xTrainComplete.Equal(new[,] { 
            { "0", "male" },
            { "2", "male" },
            { "3","NA"}}));
            isOk = isOk && (xTestComplete.Equal(new[,] {
            {"1","NA"},
            {"2","male"} ,
            {"1.666667","female"}}));
            isOk = isOk && (yTrainComplete.Equal(new[,] { { "0" }, { "1"},{"0"} }));
            isOk = isOk && xColTypes.Last().Equals(ColumnType.Categorical);

        }
    }
}
