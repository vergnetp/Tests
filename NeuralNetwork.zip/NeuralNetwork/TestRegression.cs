﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class TestRegression
    {
        public static void Test()
        {
            var XTrain = new[,]
                {
                    {"200","active"},
                    {"300","disable"},
                    {"400","active"},
                    {"500","active"}
                };            
            var YTrain = new[,]
                {
                    {"1"},
                    {"2"},
                    {"3"},
                    {"1"}
                };
            var XTest = new[,] { { "400", "disable" } };
            var encoder = new DataNormalizer();
            var activator = new ActivatorTanh();
            var minY = MinY.MinusOne;
            var normalizedXTrain = encoder.EncodeXTrain(XTrain);
            var normalizedXTest = encoder.EncodeXTest(XTest);
            var normalizedYTrain = encoder.EncodeYTrain(YTrain);            
            var costCalculator = new CostCalculatorQuadratic();
            var regularizedCostCalculator = new RegularizedCostCalculator(costCalculator, RegularizationScheme.L2Norm, 0.0F);
            var network = new ModelNeuralNetwork(normalizedXTrain.GetLength(1), normalizedYTrain.GetLength(1), new int[2] { 8,4 }, regularizedCostCalculator, activator);
            var solver = new SolverMomentum(network,10000,0.00001F,0.8F,0.2F);
            var solved=solver.Fit(normalizedXTrain, normalizedYTrain);            
            var rawPred = solver.Model.Predict(normalizedXTrain);
            var nbEpochs = solver.LastIteration;
            var cost = solver.Model.CostCalculator.Cost(rawPred, normalizedYTrain, solver.Solution);
            var pred = encoder.DecodeY(rawPred);
            var testRawPred = solver.Model.Predict(normalizedXTest);
            var testPred = encoder.DecodeY(testRawPred);
        }
    }
}
