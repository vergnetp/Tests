﻿using Accord.Math;
using Accord.Math.Optimization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class oNeuralNetwork
    {
        public bool IsCostQuadratic = false;
        protected int _NbFeatures;
        protected int _NbClasses;
        protected int[] _HiddenLayerSizes;
        protected int _NbLayers;
        public List<float[,]> _Weights=new List<float[,]>();
        public List<float[]> _Biaises=new List<float[]>();


        #region tests

        public float QuadraticCostGradient(float[,] a,float[,] Y,int sample,int classe)
        {
            return a[sample, classe] - Y[sample, classe];
        }

        public static float Sigmoid(float z)
        {
            return 1.0F/(1.0F+(float)Math.Exp(-z));
        }
        public static float SigmoidPrime(float z)
        {
            return Sigmoid(z)*(1-Sigmoid(z));
        }

        public float Forward(float[,] X,Func<float,float> activation,int s,int l)
        {
            var theta1 = _Weights[0];
            var bias1 = _Biaises[0];
            var theta2 = _Weights[1];
            var bias2 = _Biaises[1];
            var h0 = _HiddenLayerSizes[0];
            var n = _NbFeatures;
            var z2_sl = 0.0F;
            for (var k=0;k<h0;k++)
            {
                var z1_sk = 0.0F;
                for(var z=0;z<n;z++)
                {
                    z1_sk += X[s, z] * theta1[k,z];
                }
                z1_sk += bias1[k];
                var a1_sk = activation(z1_sk);
                z2_sl += a1_sk * theta2[l,k];
            }
            z2_sl+=bias2[l];   
            var a2_sl = activation(z2_sl);
            return a2_sl;
        }

        public float[,] Forward(float[,] X,Func<float,float> activation)
        {
            var res = new float[X.GetLength(0), _NbClasses];
            for (var s = 0; s < X.GetLength(0);s++ )
            {
                for(var l=0;l<_NbClasses;l++)
                {

                    res[s, l] = Forward(X, activation, s, l);
                }
            }
            return res;
        }

        public float[,] GradientTheta2(float[,] X, float[,] Y, Func<float, float> activation, Func<float, float> activationPrime)
        {
            var res = new float[_NbClasses, _HiddenLayerSizes[0]];
            for (var l=0;l<res.GetLength(0);l++)
            {
                for (var i= 0; i < res.GetLength(1); i++)
                {
                    res[l,i] = GradientTheta2(X, Y, activation, activationPrime, i,l);
                }                
            }
            return res;
        }

        public float[,] GradientTheta1(float[,] X, float[,] Y, Func<float, float> activation, Func<float, float> activationPrime)
        {
            var res = new float[ _HiddenLayerSizes[0],_NbFeatures];
            for (var l = 0; l < res.GetLength(0); l++)
            {
                for (var i = 0; i < res.GetLength(1); i++)
                {
                    res[l, i] = GradientTheta1(X, Y, activation, activationPrime, i, l);
                }
            }
            return res;
        }
        
        public float GradientTheta2(float[,] X,float[,]Y,Func<float,float> activation,Func<float,float> activationPrime,int i,int l)
        {
            var grad = 0.0F;
            var theta1 = _Weights[0];
            var bias1 = _Biaises[0];
            var theta2 = _Weights[1];
            var bias2 = _Biaises[1];
            var h0 = _HiddenLayerSizes[0];
            var n = _NbFeatures;  
            for (var s=0;s<X.GetLength(0);s++)
            {
                var z2_sl = 0.0F;
                var a1_si = 0.0F;
                for (var k = 0; k < h0; k++)
                {
                    var z1_sk = 0.0F;
                    for (var z = 0; z < n; z++)
                    {
                        z1_sk += X[s, z] * theta1[k, z];
                    }
                    z1_sk += bias1[k];
                    var a1_sk = activation(z1_sk);
                    if (k == i) a1_si = a1_sk;
                    z2_sl += a1_sk * theta2[l, k];
                }
                z2_sl += bias2[l];
                var a2_sl = activation(z2_sl);
                grad+=(a2_sl-Y[s,l])*activationPrime(z2_sl)*a1_si;// replace a-y by cost gradient
            }
            return grad/(float)X.GetLength(0);
        }

        public float GradientTheta1(float[,] X, float[,] Y, Func<float, float> activation, Func<float, float> activationPrime, int i, int j)
        {
            var grad = 0.0F;
            var theta1 = _Weights[0];
            var bias1 = _Biaises[0];
            var theta2 = _Weights[1];
            var bias2 = _Biaises[1];
            var h0 = _HiddenLayerSizes[0];
            var n = _NbFeatures;
            for (var s = 0; s < X.GetLength(0); s++)
            {
                for (var l = 0; l < _NbClasses; l++)
                {
                    var z2_sl = 0.0F;
                    var z1_sj= 0.0F;
                    var a0_si = 0.0F;
                    for (var k = 0; k < h0; k++)
                    {
                        var z1_sk = 0.0F;
                        for (var z = 0; z < n; z++)
                        {
                            z1_sk += X[s, z] * theta1[k, z];
                            if (z == i) a0_si = X[s, z];
                        }
                        z1_sk += bias1[k];
                        var a1_sk = activation(z1_sk);
                        if (k == j) z1_sj = z1_sk;
                        z2_sl += a1_sk * theta2[l, k];
                    }
                    z2_sl += bias2[l];
                    var a2_sl = activation(z2_sl);
                    grad += (a2_sl - Y[s, l]) * activationPrime(z2_sl) * theta2[l,j] * activationPrime(z1_sj) * a0_si;// replace a-y by cost gradient
                }
            }
            return grad / (float)X.GetLength(0);
        }

        #endregion

        public oNeuralNetwork(){ }

        public oNeuralNetwork(int nbFeatures,int nbClasses,int[] hiddenLayerSizes)
        {
            _NbFeatures=nbFeatures;
            _NbClasses=nbClasses;
            _HiddenLayerSizes = hiddenLayerSizes;            
            Initialize();
        }
       
        public void Initialize()
        {
            _NbLayers = _HiddenLayerSizes.GetLength(0);
            var gradients = GetRandomWeights();
            _Weights = gradients.WeightsGrad;
            _Biaises = gradients.BiaisesGrad;
        }

        public class Gradients
        {
            public List<float[,]> WeightsGrad ;
            public List<float[]> BiaisesGrad;
        }

        public Gradients GetGradient(float[,] X,float[,] Y,float lambda)
        {
            // todo: activation function and derivate to be dynamic (softmax etc)       
            var a = new List<float[,]>();
            var w = _Weights;
            var b = _Biaises;
            var weightsGrad = new List<float[,]>();
            var biaisesGrad = new List<float[]>();

            // Forward pass:
            a.Add(X);             
            for (var l=0;l<_NbLayers+1;l++)
            {
                //float[,] deb1 = a[l].MultiplyGpu(w[l].Transpose());
                //float[,] deb2 = a[l].MultiplyByTranspose(w[l]);
                //var isSame=deb1[4, 2] == deb2[4, 2];
                //var fd = isSame;
                //a.Add(a[l].MultiplyGpu(w[l].Transpose()).Add(b[l], 0).ApplySigmoid());
                a.Add(a[l].MultiplyByTranspose(w[l]).Add(b[l], 0).ApplySigmoid());   
            }

            // Backpropagation:
            var averagor = 1.0F / (float)X.GetLength(0);
            float[,] d=null;
            for (var l=_NbLayers+1;l>0;l--)
            {
                if (l == _NbLayers + 1)
                {
                    d = a[l].Subtract(Y);//a[2]-y
                }
                else
                {
                    d = d.MultiplyBy(w[l]); //d*w[2] 
                }  
                if (IsCostQuadratic || l < _NbLayers + 1)
                {
                    var aDerivate = a[l].ElementwiseMultiply(1.Subtract(a[l]));//a[2].*(1-a[2])
                    d = d.ElementwiseMultiply(aDerivate);// d=d.*sp(a[2])    
                }
                var grad = d.TransposeAndMultiply(a[l-1]).Multiply(averagor);//d'*a[1]./m
                grad = grad.Add(w[l-1].Multiply(lambda)); // d + w[2].*lambda // Regularization
                weightsGrad.Insert(0, grad);
                var ones = Matrix.Vector(d.GetLength(0), 1.0F).Reshape(d.GetLength(0), 1);
                biaisesGrad.Insert(0, d.TransposeAndMultiply(ones).Multiply(averagor).Reshape());//d'*[1s]/m //average per row
            }
            return new Gradients() {WeightsGrad=weightsGrad,BiaisesGrad=biaisesGrad };
        }

        protected Gradients _PreviousUpdates;
        public void UpdateGradient(float[,] X,float[,] Y,float rho,float lambda,float alpha=0.1F,bool useMomentum=false)
        {            
            if (_PreviousUpdates == null) _PreviousUpdates = this.GetRandomWeights();
            // make rho dynamic?
            var gradients = GetGradient(X, Y, lambda);
            var weightsGrad = gradients.WeightsGrad;
            var biaisesGrad = gradients.BiaisesGrad;
            
            for (var l=0;l<weightsGrad.Count;l++)
            {
                var weightUpdate=weightsGrad[l].Multiply(rho);                
                var biasUpdate = biaisesGrad[l].Multiply(rho);
                if (useMomentum)
                {
                    weightUpdate = weightUpdate.Add(_PreviousUpdates.WeightsGrad[l].Multiply(alpha));
                    biasUpdate = biasUpdate.Add(_PreviousUpdates.BiaisesGrad[l].Multiply(alpha));
                }
                 _Weights[l] = _Weights[l].Subtract(weightUpdate);
                _Biaises[l] = _Biaises[l].Subtract(biasUpdate);
                _PreviousUpdates.WeightsGrad[l] = weightUpdate;
                _PreviousUpdates.BiaisesGrad[l] = biasUpdate;
            }
        }
      
        #region Runs

        public float Solve(float[,] X, float[,] Y,bool normalize, float lambda = 0.0F)
        {
            var XTrain = X;
            if (normalize) { XTrain=Normalize(X); }
            
            var f = new Func<double[], double>(theta =>
            {
                Unroll(theta);
                var cost = Cost(XTrain, Y,lambda,false);
                return cost;
            });
            var g = new Func<double[], double[]>(theta =>
            {
                Unroll(theta);
                var gradients = GetGradient(XTrain, Y, lambda);
                var grad = Roll(gradients.WeightsGrad, gradients.BiaisesGrad);
                return grad;
            });
            var solver = new BroydenFletcherGoldfarbShanno(NbParams(), f, g);
            var solved = solver.Minimize();
            return (float)solver.Value;
        }

        public void ValidationPartition(float[,] X,float[,] Y,double trainingRatio,out float[,] XTrain,out float[,] YTrain,out float[,] XVal, out float[,] YVal)
        {
            var trainNumber = (int)trainingRatio * X.GetLength(0);
            var indices = Accord.Math.Matrix.Indices(X.GetLength(0));
            Accord.Statistics.Tools.Shuffle(indices);
            var slots = Accord.Math.Matrix.Split(indices, trainNumber);
            var lastSlot = Accord.Math.Matrix.Submatrix(indices, slots.Length, indices.Length);
            XTrain = Accord.Math.Matrix.Submatrix(X, slots.First());
            YTrain = Accord.Math.Matrix.Submatrix(Y, slots.First());
            XVal = Accord.Math.Matrix.Submatrix(X, lastSlot);
            YVal = Accord.Math.Matrix.Submatrix(Y, lastSlot);  
        }

        public List<Tuple<float[,],float[,]>> KPartition(float[,] X, float[,] Y, int K)
        {           
            var res = new List<Tuple<float[,], float[,]>>();
            var indices = Accord.Math.Matrix.Indices(X.GetLength(0));
            Accord.Statistics.Tools.Shuffle(indices);
            var slots = Accord.Math.Matrix.Split(indices, K);
            var lastSlot = Accord.Math.Matrix.Submatrix(indices, slots.Length, indices.Length);
            var lastX = Accord.Math.Matrix.Submatrix(X, lastSlot);
            var lastY = Accord.Math.Matrix.Submatrix(Y, lastSlot);            
            foreach (var slot in slots)
            {
                var subX = Accord.Math.Matrix.Submatrix(X, slot);
                var subY = Accord.Math.Matrix.Submatrix(Y, slot);
                res.Add(new Tuple<float[,], float[,]>(subX,subY));
            }
            res.Add(new Tuple<float[,], float[,]>(lastX, lastY));
            return res;
        }

        public class TrainValidationData
        {
            public float[,] XTrain;
            public float[,] YTrain;
            public float[,] XVal;
            public float[,] YVal;
        }

        public void TestCV()
        {
            var X = new float[10, 2]; 
            for (var i=0;i<X.GetLength(0);i++)
            {
                X[i, 0] = i;
            }
            var Y = new float[10, 1];
            for (var i = 0; i < Y.GetLength(0); i++)
            {
                Y[i, 0] = i*100;
            }
            var cv = PrepareCrossValidation(X, Y, 3);
            System.Diagnostics.Debug.Assert(cv.Count == 4);
            var sum=0.0F;
            cv.First().XTrain.Apply(x=>sum+=x);
            cv.First().XVal.Apply(x => sum += x);
            System.Diagnostics.Debug.Assert(sum == 45);
            System.Diagnostics.Debug.Assert(cv.First().XTrain.GetLength(0)==7);
            System.Diagnostics.Debug.Assert(cv.First().XTrain.GetLength(1) == 2);
            System.Diagnostics.Debug.Assert(cv.First().XVal.GetLength(0) == 3);
            System.Diagnostics.Debug.Assert(cv.First().XVal.GetLength(1) == 2);
            System.Diagnostics.Debug.Assert(cv.First().YTrain.GetLength(0) == 7);
            System.Diagnostics.Debug.Assert(cv.First().YTrain.GetLength(1) == 1);
            System.Diagnostics.Debug.Assert(cv.First().YVal.GetLength(0) == 3);
            System.Diagnostics.Debug.Assert(cv.First().YVal.GetLength(1) == 1);
            System.Diagnostics.Debug.Assert(cv.Last().YTrain.GetLength(0) == 9);
            System.Diagnostics.Debug.Assert(cv.Last().YTrain.GetLength(1) == 1);
            System.Diagnostics.Debug.Assert(cv.Last().YVal.GetLength(0) == 1);
            System.Diagnostics.Debug.Assert(cv.Last().YVal.GetLength(1) == 1);
            var exception = false;
            try
            {
                cv = PrepareCrossValidation(X, Y, 11);
            }
            catch(Exception)
            {
                exception = true;
            }
            System.Diagnostics.Debug.Assert(exception);
        }

        public List<TrainValidationData> PrepareCrossValidation(float[,] X,float[,] Y,int K)
        {
            if(X.GetLength(0) !=Y.GetLength(0))throw new ArgumentException();
            if (K>Y.GetLength(0)) throw new ArgumentException();
            var nbItems = (int)X.GetLength(0) / K;
            var res = new List<TrainValidationData>();
            var indices = Accord.Math.Matrix.Indices(X.GetLength(0));
            Accord.Statistics.Tools.Shuffle(indices);
            var slots = Accord.Math.Matrix.Split(indices, nbItems).ToList();
            var lastSlot = Accord.Math.Matrix.Submatrix(indices, slots.Count * nbItems, indices.Length - 1);
            slots.Add(lastSlot);
            for (var k = 0; k < slots.Count;k++ )
            {
                var XVal = Accord.Math.Matrix.Submatrix(X, slots[k]);
                var YVal = Accord.Math.Matrix.Submatrix(Y, slots[k]);                
                var trainIndices = new int[0];
                for (var i = 0; i < slots.Count; i++)
                {
                    if (i!=k) trainIndices = trainIndices.Concat(slots[i]).ToArray();
                }
                var XTrain = Accord.Math.Matrix.Submatrix(X, trainIndices);
                var YTrain = Accord.Math.Matrix.Submatrix(Y, trainIndices);
                res.Add(new TrainValidationData() {XTrain=XTrain,YTrain=YTrain ,XVal=XVal,YVal=YVal});
            }           
            return res;
        }

        public void CrossTrain(float[,] X, float[,] Y,int K)
        {
            var models = new List<float>() { 0.0F, 0.01F, 0.1F, 0.3F, 1.0F, 3.0F };
            var modelResults = new List<float>();
            foreach (var model in models)
            {
                var subSamples = PrepareCrossValidation(X, Y, K);
                var validationResults = new List<float>();
                foreach (var subSample in subSamples)
                {
                    //Run(subSample.XTrain, subSample.YTrain, false, subSample.XVal, subSample.YVal, rho, miniBatchSize, lambda, nbEpochs, null, 0.9F, true);
                    //validationResults.Add(this.Cost(subSample.XVal, subSample.YVal, lambda, true));
                }
                // Get some metric on the validation results:
                var validationStat = validationResults.Average();
                modelResults.Add(validationStat);
            }
            // Choose the model with the best validation metric:
            var bestMetricIndex = modelResults.Select((value,index) => new {Value=value,Index=index }).Aggregate((a,b)=>(a.Value>b.Value)?a:b).Index;
            var bestModel = models[bestMetricIndex];
        }

    


        public void Run(float[,] XTrain, float[,] YTrain, bool normalize, float[,] XVal = null, float[,] YVal = null, float rho = 0.25F, int miniBatchSize = 50, float lambda = 0.0F, int nbEpochs = 30, string path = null, float alpha = 0.1F, bool useMomentum = false)
        {
            // todo: automatic partition train/validation-> DONE
            // todo: Cross Validation on a few lambda (alternatively study dropout technique)
            // todo: stop if validation gets "considerably" worse
            // todo: stop if convergence (weights stale?)
            // todo: clone network and serialize in other thread
            if (XVal == null) 
            {
                this.ValidationPartition(XTrain, YTrain, 0.8,out XTrain,out YTrain,out XVal,out YVal);         
            }
            var X = XTrain;
            if (normalize) { X = Normalize(XTrain); }
            var Y = YTrain;
            var gradientOk = CheckGradient(X, Y,false);
            Console.WriteLine(string.Format("Gradient Ok: {0}", gradientOk));
            for (var i = 0; i < nbEpochs; i++)
            {
                RunEpoch(X, Y, normalize,XVal, YVal, rho,miniBatchSize, lambda,alpha,useMomentum);
                if (i % (nbEpochs/10)==0)
                {
                    this.Serialize(path);
                }
            }
        }

        protected int _NbEpoch;
        protected void RunEpoch(float[,] XTrain, float[,] YTrain, bool normalized, float[,] XVal = null, float[,] YVal = null, float rho = 0.25F, int miniBatchSize = 50, float lambda = 0.0F, float alpha = 0.1F, bool useMomentum = false)
        {
            _NbEpoch++;
            Console.WriteLine(string.Format("Epoch Nb.{0}", _NbEpoch));
            if (XVal == null) { XVal = XTrain; YVal = YTrain; }
            var X = XTrain; var Y = YTrain;
            //var indices = Accord.Math.Matrix.Indices(X.GetLength(0));
            var partition = this.KPartition(XTrain, YTrain, miniBatchSize);
            foreach (var part in partition)
            {
                var subX = part.Item1; 
                var subY = part.Item2;
                UpdateGradient(subX,subY, rho, lambda);
            }           
            var cost = Cost(X, Y,lambda,false);            
            var accuracy = GetAccuracy(XVal, YVal,normalized);
            Console.WriteLine(string.Format("Cost: {0}", cost));
            Console.WriteLine(string.Format("Accuracy: {0:P}", accuracy));
            UpdateGradient(X, Y, rho, lambda,alpha, useMomentum);            
        }

        #endregion
        
        #region Predictions and performance

        public float[,] Predict(float[,] X,bool normalize)
        {
            var normalizedX = X;            
            if (normalize && this.TrainingMeans!=null && this.TrainingStdDevs!=null)
            {
                normalizedX = new float[X.GetLength(0), X.GetLength(1)];
                for (var j = 0; j < X.GetLength(1); j++)
                {
                    for (var i = 0; i < X.GetLength(0); i++)
                    {
                        normalizedX[i, j] = (X[i, j] - TrainingMeans[j]) / TrainingStdDevs[j];
                    }
                }
            }
            
            var a = new List<float[,]>();
            var w = _Weights;
            var b = _Biaises;
            a.Add(normalizedX);
            for (var l = 0; l < _NbLayers+1; l++)
            {
                a.Add(a[l].MultiplyByTranspose(w[l]).Add(b[l], 0).ApplySigmoid());
            }
            return a.Last();
        }

        public float GetAccuracy(float[,] X,float[,] Y,bool normalize)
        {
            var nbSuccess = 0.0F;
            var pred = Predict(X,normalize);
            for (var i = 0; i < Y.GetLength(0); i++)
            {
                if (Y.GetLength(1) > 1)
                {
                    var predIndex = 0;
                    var yIndex = 0;
                    for (var j = 0; j < Y.GetLength(1); j++)
                    {
                        if (pred[i, j] > pred[i, predIndex]) predIndex = j;
                        if (Y[i, j] > Y[i, yIndex]) yIndex = j;
                    }
                    if (yIndex.Equals(predIndex) && predIndex > -1) { nbSuccess++; }
                }
                else
                {
                    if ((pred[i, 0] > 0.5 && Y[i, 0] == 1)||(pred[i, 0] <= 0.5 && Y[i, 0] == 0)) { nbSuccess++; }
                }
            }
            return nbSuccess / (float)Y.GetLength(0);
        }

        #endregion

        #region Cost

        public float Cost(float[,] X,float[,] Y,float lambda,bool normalize)
        {
           if (IsCostQuadratic)
           {
               return QuadraticCost(X, Y,lambda,normalize);
           }
           return LogCost(X, Y,lambda,normalize);
        }

        public float QuadraticCost(float[,] X,float[,] Y,float lambda,bool normalize)
        {            
            var cost = 0.0F;
            var pred = Predict(X,normalize);
            for (var i = 0; i <Y.GetLength(0);i++)
            {
                for (var j = 0; j < Y.GetLength(1);j++)
                {
                    cost += ((pred[i, j] - Y[i, j]) * (pred[i, j] - Y[i, j]))/2.0F;
                }
            }
            cost += RegularizationCost(lambda);
            return cost/((float)X.GetLength(0));
        }

        public float LogCost(float[,] X, float[,] Y, float lambda,bool normalize)
        {
            var cost = 0.0F;
            var pred = Predict(X,normalize);
            for (var i = 0; i < Y.GetLength(0); i++)
            {
                for (var j = 0; j < Y.GetLength(1); j++)
                {
                    if (pred[i, j] == 0F) pred[i, j] = 0.00000000000001F;
                    if (pred[i, j] == 1F) pred[i, j] = 0.99999999999999F;
                    cost += -Y[i, j] * (float)Math.Log(pred[i, j]) - (1.0F - Y[i, j]) * (float)Math.Log(1.0F - pred[i, j]);
                }
            }
            cost += RegularizationCost(lambda);
            return cost / ((float)X.GetLength(0));
        }

        public float RegularizationCost(float lambda)
        {
            var cost = 0.0F;
            for (var l = 0; l < _Weights.Count; l++)
            {
                for (var i = 0; i < _Weights[l].GetLength(0); i++)
                {
                    for (var j = 0; j < _Weights[l].GetLength(1); j++)
                    {
                        cost += lambda*(_Weights[l][i, j] * _Weights[l][i, j]) / 2.0F;
                    }
                }
            }
            return cost;
        }
      
        #endregion

        #region Gradients

        public bool CheckGradient(float[,] X,float[,] Y,bool normalize,float lambda=0.0F)
        {   
            var XExtract=Accord.Math.Matrix.Submatrix(X,new int[]{0,1,2,3});
            var YExtract = Accord.Math.Matrix.Submatrix(Y, new int[] { 0, 1, 2, 3 });
            var tolerance = 0.00000001F;
            var distance = 0.0F;
            var normPlus = 0.0F;
            var normMinus = 0.0F;
            var gradientsCalc=GetGradient(XExtract,YExtract,lambda);
            var gradientsNum = GetNumGradient(XExtract, YExtract, normalize,lambda);
            for (var l = 0; l < _NbLayers + 1;l++ )
            {
                for (var i=0;i<_Weights[l].GetLength(0);i++)
                {
                    for (var j = 0; j < _Weights[l].GetLength(1); j++)
                    {        
                        var gradNum=gradientsNum.WeightsGrad[l][i,j];
                        var gradCalc = gradientsCalc.WeightsGrad[l][i, j];
                        normMinus += (gradNum - gradCalc)*(gradNum - gradCalc);
                        normPlus += (gradNum + gradCalc) * (gradNum + gradCalc);
                        //if (Math.Abs(gradCalc - gradNum) > tolerance) throw new Exception("Gradient issue");                       
                    }
                }
                for (var i = 0; i < _Biaises[l].GetLength(0); i++)
                {
                    var gradNum = gradientsNum.BiaisesGrad[l][i];
                    var gradCalc = gradientsCalc.BiaisesGrad[l][i];
                    normMinus += (gradNum - gradCalc) * (gradNum - gradCalc);
                    normPlus += (gradNum + gradCalc) * (gradNum + gradCalc);
                    //if (Math.Abs(gradCalc - gradNum) > tolerance) throw new Exception("Gradient issue");
                }
            }
            normMinus = (float)Math.Pow(normMinus, 0.5);
            normPlus = (float)Math.Pow(normPlus, 0.5);
            distance = normMinus/normPlus;
            return distance<tolerance;
        }

        public Gradients GetNumGradient(float[,] X, float[,] Y, bool normalize,float lambda = 0.0F)
        {
            var epsilon = 0.0001F;
            var gradients = GetRandomWeights();
            for (var l = 0; l < _NbLayers + 1; l++)
            {
                var original = new float[gradients.WeightsGrad[l].GetLength(0), gradients.WeightsGrad[l].GetLength(1)];
                for (var i = 0; i < gradients.WeightsGrad[l].GetLength(0); i++)
                {
                    for (var j = 0; j < gradients.WeightsGrad[l].GetLength(1); j++)
                    {
                        original[i, j] = _Weights[l][i, j];
                        _Weights[l][i, j] -= epsilon;
                        var minusCost = Cost(X, Y, lambda,normalize);
                        _Weights[l][i, j] += 2 * epsilon;
                        var plusCost = Cost(X, Y, lambda,normalize);
                        var gradNum = (plusCost - minusCost) / (2.0F * epsilon);
                        gradients.WeightsGrad[l][i, j] = gradNum;                        
                    }
                }
                _Weights[l]=original;
                //var deb = original.Equal(_Weights[l]);
                var originalB = new float[gradients.BiaisesGrad[l].GetLength(0)];
                
                for (var i = 0; i < gradients.BiaisesGrad[l].GetLength(0); i++)
                {
                    originalB[i] = _Biaises[l][i];
                    _Biaises[l][i] -= epsilon;
                    var minusCost = Cost(X, Y, lambda,normalize);
                    _Biaises[l][i] += 2.0F * epsilon;
                    var plusCost = Cost(X, Y, lambda,normalize);
                    var gradNum = (plusCost - minusCost) / (2.0F * epsilon);
                    gradients.BiaisesGrad[l][i] = gradNum;                    
                }
                _Biaises[l] = originalB;
            }            
            return gradients;
        }
        
        #endregion

        #region Roll/Unroll

        public int NbParams()
        {
            var n = 0;
            for (var l = 0; l < _Weights.Count; l++)
            {
                n += _Weights[l].GetLength(0) * _Weights[l].GetLength(1);
            }
            for (var l = 0; l < _Biaises.Count; l++)
            {
                n += _Biaises[l].GetLength(0);
            }
            return n;
        }

        public double[] Roll(List<float[,]> weights,List<float[]> biaises)
        {
            var n = 0;
            for (var l = 0; l < weights.Count; l++)
            {
                n += weights[l].GetLength(0) * weights[l].GetLength(1);
            }
            for (var l = 0; l < biaises.Count; l++)
            {
                n += biaises[l].GetLength(0);
            }
            var res = new double[n];
            var counter = 0;
            for (var l = 0; l < weights.Count; l++)
            {
                for (var i = 0; i < weights[l].GetLength(0); i++)
                {
                    for (var j = 0; j < weights[l].GetLength(1); j++)
                    {
                        res[counter] = (double)weights[l][i, j];
                        counter++;
                    }
                }
            }
            for (var l = 0; l < biaises.Count; l++)
            {
                for (var i = 0; i < biaises[l].GetLength(0); i++)
                {
                    res[counter] = (double)biaises[l][i];
                    counter++;
                }
            }
            return res;
        }

        public void Unroll(double[] v)
        {
            var counter = 0;
            for (var l = 0; l < _Weights.Count; l++)
            {
                for (var i = 0; i < _Weights[l].GetLength(0); i++)
                {
                    for (var j = 0; j < _Weights[l].GetLength(1); j++)
                    {
                        _Weights[l][i, j] = (float)v[counter];
                        counter++;
                    }
                }
            }
            for (var l = 0; l < _Biaises.Count; l++)
            {
                for (var i = 0; i < _Biaises[l].GetLength(0); i++)
                {
                    _Biaises[l][i] = (float)v[counter];
                    counter++;
                }
            }
        }

        #endregion

        #region Normalization/Randomization

        public float[] TrainingMeans{get;set;}
        public float[] TrainingStdDevs { get; set; }

        public float[,] Normalize(float[,] a)
        {
            var XDouble = Accord.Math.Matrix.ToDouble(a);

            TrainingMeans = Accord.Math.Matrix.Apply(Accord.Statistics.Tools.Mean(XDouble), x => (float)x);
            TrainingStdDevs = Accord.Math.Matrix.Apply(Accord.Statistics.Tools.StandardDeviation(XDouble), x => (float)x);
            return Accord.Math.Matrix.Apply(Accord.Statistics.Tools.ZScores(XDouble), x => (float)x);
        }

        public void Randomize(float[,] v)
        {
            var rnd = new Random();
            var epsilon = Math.Pow(6, 0.5) * Math.Pow(v.GetLength(0) + v.GetLength(1), -0.5); ;
            for (var i = 0; i < v.GetLength(0); i++)
            {
                for (var j = 0; j < v.GetLength(1); j++)
                {
                    v[i, j] = (float)(rnd.NextDouble() * 2 * epsilon - epsilon);
                }
            }
        }

        public void Randomize(float[] v)
        {
            var rnd = new Random();
            var epsilon = Math.Pow(6, 0.5) * Math.Pow(v.GetLength(0) + 1, -0.5); ;
            for (var i = 0; i < v.GetLength(0); i++)
            {
                v[i] = (float)(rnd.NextDouble() * 2 * epsilon - epsilon);
            }
        }
        
        public Gradients GetRandomWeights()
        {
            var weights = new List<float[,]>();
            var biaises = new List<float[]>();
            var w = new float[_HiddenLayerSizes[0], _NbFeatures]; //Randomize(w);
            weights.Add(w);
            var b = new float[_HiddenLayerSizes[0]]; //Randomize(b);
            biaises.Add(b);
            for (var l = 0; l + 1 < _NbLayers; l++)
            {
                w = new float[_HiddenLayerSizes[l + 1], _HiddenLayerSizes[l]]; //Randomize(w);
                weights.Add(w);
                b = new float[_HiddenLayerSizes[l + 1]]; //Randomize(b);
                biaises.Add(b);
            }
            w = new float[_NbClasses, _HiddenLayerSizes.Last()];// Randomize(w);
            weights.Add(w);
            b = new float[_NbClasses]; //Randomize(b);
            biaises.Add(b);
            weights[0][0, 0] = 1.0F; // here
            return new Gradients() { WeightsGrad = weights, BiaisesGrad = biaises };
        }

        #endregion

        #region Serialization

        public string Serialize(string path)
        {
            // todo: nbEpoch (and last Cost?)
            if (path == null) { path = @"C:\temp\NeuralNetwork.txt"; }
            var sb = new StringBuilder();
            sb.AppendLine(string.Format("Nb Features:{0}", _NbFeatures));
            sb.AppendLine(string.Format("Nb Classes:{0}", _NbClasses));
            sb.AppendLine(string.Format("Hidden Layers:{0}", string.Join(";", _HiddenLayerSizes)));
            sb.AppendLine(string.Format("Quadratic Cost:{0}", IsCostQuadratic));
            sb.AppendLine(string.Format("Normalization Means:{0}", string.Join(";", this.TrainingMeans)));
            sb.AppendLine(string.Format("Normalization Standard Deviations:{0}", string.Join(";", this.TrainingStdDevs)));
            sb.AppendLine(string.Format("Weights:{0}", string.Join(";", Roll(_Weights, _Biaises))));
            var res = sb.ToString();
            if (path != null) System.IO.File.WriteAllText(path, res);
            return res;
        }

        public void Deserialize(string path)
        {
            if (path == null) { path = @"C:\temp\NeuralNetwork.txt"; }
            var lines = System.IO.File.ReadAllLines(path);
            _NbFeatures = Convert.ToInt32(lines[0].Split(':').Last());
            _NbClasses = Convert.ToInt32(lines[1].Split(':').Last());
            _HiddenLayerSizes = lines[2].Split(':').Last().Split(';').Apply(x => Convert.ToInt32(x));
            IsCostQuadratic = Convert.ToBoolean(lines[3].Split(':').Last());
            this.TrainingMeans = lines[4].Split(':').Last().Split(';').Apply(x => (float)Convert.ToDouble(x));
            this.TrainingStdDevs = lines[5].Split(':').Last().Split(';').Apply(x => (float)Convert.ToDouble(x));
            var weights = lines[6].Split(':').Last().Split(';').Apply(x => Convert.ToDouble(x));
            Initialize();
            Unroll(weights);
        }

        #endregion

    }
}
