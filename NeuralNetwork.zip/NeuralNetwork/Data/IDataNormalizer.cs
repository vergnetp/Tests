﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{

    public enum ColumnType
    {
        Unknown,
        Numeric,
        Binary,
        Categorical
    }

    /// <summary>
    /// The dependent variable range needs to be accessible from the activation functions of neural networks.
    /// So it is best to ensure the range is between MinY and 1 (minY can be 0 or -1)
    /// </summary>
    public enum MinY
    {
        MinusOne = -1,
        Zero = 0
    }

    public interface IDataNormalizer
    {
        MinY MinY { get; }
        ColumnType[] XColTypes { get;   }
        ColumnType[] YColTypes { get;   }
        string[][] XDistinctValues { get;   }
        string[][] YDistinctValues { get;   }
        bool IsXEncoded { get; }
        bool IsYEncoded { get; }        
        float[,] EncodeXTrain(string[,] rawData, ColumnType[] colTypes = null);
        float[,] EncodeXTest(string[,] rawData, ColumnType[] colTypes = null);
         float[,] EncodeYTrain(string[,] rawData,  ColumnType[] colTypes = null);
        string[,] DecodeX(float[,] data);
        string[,] DecodeY(float[,] data);        
    }

}
