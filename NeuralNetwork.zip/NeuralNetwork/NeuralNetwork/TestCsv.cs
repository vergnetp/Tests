﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class TestCsv
    {

        public static void Test()
        {
            var path = @"C:\Users\UK800386\Desktop\CRDS_20160413.csv";
            var ret0=Importer.ImportCsv(path, true, 0, 4);
            var ret1 = Importer.ImportCsv(path, true, 4, 4);
            var ret2 = Importer.ImportCsv(path, true, 29586, 10000);
            var ret3 = Importer.ImportCsv(path, true, 29587, 10000);
            var ret4 = Importer.ImportCsv(path, true, 30000, 10000);

        }

    }
}
