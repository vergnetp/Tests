﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    class Program
    {
        // todo: replace by stackalloc all temp arrays
        static void Main(string[] args)
        {
            TestBigData.Test();
            TestCsv.Test();
            TestBrainBony.Test();
            TestWeights.Test();
            TestPerformance.Test();
            TestMemoryFile.Test();
            
            TestMissingData.Test();
            AccuracyAssessor.Test();
            //TestRegression.Test();
            DataNormalizer.Test();
            TestImport.Test();
            Console.ReadKey();
        }
    }
}

