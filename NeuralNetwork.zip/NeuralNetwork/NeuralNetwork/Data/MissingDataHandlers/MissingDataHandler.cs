﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace NeuralNetwork
{

    /// <summary>
    /// Remove all rows with at least one missing data in YTrain.
    /// Remove all empty rows. 
    /// Special logic to handle rows with only a few missing entries in XTrain or XTest is to be implemented in derived class.
    /// </summary>
    [DataContract]
    public abstract class MissingDataHandler : IMissingDataHandler
    {
        public abstract void HandlePartial(string[,] XTrain, string[,] XTest, ColumnType[] xColTypes);
         
        /// <summary>
        /// Remove all rows with at least one missing data in YTrain.
        /// Remove all empty rows. 
        /// Special logic to handle rows with only a few missing entries in XTrain or XTest is to be implemented in derived class.
        /// </summary>
        public void Handle(string[,] XTrain, string[,] YTrain, string[,] XTest, ColumnType[] xColTypes, ColumnType[] yColTypes, out string[,] XTrainComplete, out string[,] YTrainComplete, out string[,] XTestComplete)
        {
            var m = XTrain.GetLength(0);
            var n = XTrain.GetLength(1);
            var o = YTrain.GetLength(1);
            var mt = XTest.GetLength(0);
            var missingIndices = new List<int>();
            for (var i = 0; i < m; i++)
            {
                var isYMissing = false;
                for (var j = 0; j < o; j++)
                {
                    if (string.IsNullOrEmpty(YTrain[i, j]))
                    {
                        missingIndices.Add(i);
                        isYMissing = true;
                        break;
                    }
                }
                if (!isYMissing)
                {
                    for (var j = 0; j < n; j++)
                    {
                        var isFullLineMissing = true;
                        if (!string.IsNullOrEmpty(XTrain[i, j]))
                        {
                            isFullLineMissing = false;
                            break;
                        }
                        if (isFullLineMissing) missingIndices.Add(i);
                    }
                }
            }
            XTrainComplete = new string[m - missingIndices.Count, n];
            YTrainComplete = new string[m - missingIndices.Count, o];
            int k = 0;
            for (var i = 0; i < m; i++)
            {
                if (!missingIndices.Contains(i))
                {
                    for (var j = 0; j < n; j++)
                        XTrainComplete[k, j] = XTrain[i, j];
                    for (var j = 0; j < o; j++)
                        YTrainComplete[k, j] = YTrain[i, j];
                    k++;
                }

            }
            missingIndices.Clear();
            for (var i = 0; i < mt; i++)
            {
                var isFullLineMissing = true;
                for (var j = 0; j < n && isFullLineMissing; j++)
                {
                    if (!string.IsNullOrEmpty(XTest[i, j]))
                    {
                        isFullLineMissing = false;
                    }
                }
                if (isFullLineMissing) missingIndices.Add(i);
            }
            XTestComplete = new string[mt - missingIndices.Count, n];
            k = 0;
            for (var i = 0; i < mt; i++)
            {
                if (!missingIndices.Contains(i))
                {
                    for (var j = 0; j < n; j++)
                        XTestComplete[k, j] = XTest[i, j];
                    k++;
                }

            }
            HandlePartial(XTrainComplete, XTestComplete, xColTypes);
        }

        public static bool IsNumeric(object Expression)
        {
            float retNum;
            if (string.IsNullOrEmpty(Convert.ToString(Expression))) { return true; }
            bool isNum = float.TryParse(Convert.ToString(Expression), System.Globalization.NumberStyles.Any, System.Globalization.NumberFormatInfo.InvariantInfo, out retNum);
            return isNum;
        }
       
        public static void HandleTrain(int[] OutputColumns,string outputPath,string csvPath,long offset,long size,out List<string>[] distinctValues,out ColumnType[] colTypes)
        {
            // todo: if all column empty then categorical            
            ColumnType[] ColTypes;
            var lastRow = offset + size;
            var firstRow = Importer.ImportCsv(csvPath, true, 0, 1);
            var n = (long)firstRow.GetLength(1);
            var maxSize = 1000 *1000/n; // We allow a 64MB array max
            var subSize = Math.Min(size, maxSize);
            var subData = Importer.ImportCsv(csvPath, true, offset, subSize);
            var DistinctValues = new List<string>[subData.GetLength(1)];
            ColTypes = new ColumnType[subData.GetLength(1)];
            do
            {
                var missingIndices = new List<int>();
                for(var j=0;j< subData.GetLength(1);j++)
               //Parallel.For (0, subData.GetLength(1), j =>
                {
                    ColTypes[j]=ColumnType.Numeric;
                    if (DistinctValues[j] == null)
                    {
                        DistinctValues[j] = new List<string>();
                    }
                    var dico = new SortedDictionary<string, bool>(); 
                    for (var i = 0; i < subData.GetLength(0);i++ )
                    {                                           
                        if (OutputColumns!=null && (string.IsNullOrEmpty(subData[i,j]) &&  OutputColumns.Contains(j)))
                        {
                            if (!missingIndices.Contains(i))missingIndices.Add(i);
                        }
                        else
                        {
                            if (!DistinctValues[j].Contains(subData[i, j])) DistinctValues[j].Add(subData[i, j]);
                            if (!IsNumeric(subData[i, j])) ColTypes[j] = ColumnType.Categorical;
                        }
                    }                                
                }//);              
                subData=subData.RemoveRowsAndShuffle<string>(missingIndices.ToArray());                
                Exporter.ExportCsv(outputPath, subData);
                offset += subSize;
                subSize = Math.Min(subSize, lastRow - offset);
                subData = Importer.ImportCsv(csvPath, true, offset, subSize);                            
            } while (subData != null);
            // Add "NA" to be able to handle unseen data
            for (var j = 0; j < DistinctValues.Length;j++ )
            {
                if ((ColTypes[j] == ColumnType.Categorical || ColTypes[j] == ColumnType.Binary) && !DistinctValues[j].Contains("NA"))
                {
                    DistinctValues[j].Add("NA");
                    ColTypes[j] = ColumnType.Categorical;
                }                       
            }
            distinctValues = DistinctValues; colTypes = ColTypes;
        }

      
        public static void HandlePartialNA( string outputPath, string csvPath, long offset, long size,
            List<string>[] DistinctValues,ColumnType[] ColTypes,float[] Means)
        {
            var lastRow = offset + size;
            var firstRow = Importer.ImportCsv(csvPath, true, 0, 1);
            var n = (long)firstRow.GetLength(1);
            var maxSize = 1000*1000/n;// We allow a 64MB array max
            var subSize = Math.Min(size, maxSize);
            var subData = Importer.ImportCsv(csvPath, false, offset, subSize);
            while (subData != null) 
            {
                for(var j=0;j< subData.GetLength(1);j++)
                //Parallel.For(0, subData.GetLength(1), j =>
                {
                    if (ColTypes[j] == ColumnType.Numeric)
                    {
                        for (var i = 0; i < subData.GetLength(0); i++)
                        {
                            if (string.IsNullOrEmpty(subData[i, j]))
                            {
                                subData[i, j] = Means[j].ToString();
                            }
                        }
                    }
                    else
                    {
                        for (var i = 0; i < subData.GetLength(0); i++)
                        {
                            if (string.IsNullOrEmpty(subData[i, j]))
                            {
                                subData[i, j] = "NA";                                
                                DistinctValues[j].RemoveAll(s=>s=="");                                                               
                            }
                        }
                    }
                }//);             
                Exporter.ExportCsv(outputPath, subData);
                offset += subSize;
                subSize = Math.Min(subSize, lastRow - offset);
                subData = Importer.ImportCsv(csvPath, true, offset, subSize);
            } 
        }


    }
}
