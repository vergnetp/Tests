﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    [DataContract]
    public class DataNormalizer :IDataNormalizer
    {
        public DataNormalizer(MinY minY = MinY.Zero, ColumnType[] xColTypes = null, ColumnType[] yColTypes = null) { MinY = minY; XColTypes = xColTypes; YColTypes = yColTypes; }

        #region Members

        [DataMember]
        public MinY MinY { get; protected set; }

        [DataMember]
        public ColumnType[] XColTypes { get; set; }
        [DataMember]
        public ColumnType[] YColTypes { get; set; }

        [DataMember]
        protected string[][] _XDistinctValues;
        public string[][] XDistinctValues { get { return _XDistinctValues; } 
            protected set { 
                _XDistinctValues = value; 
            } }
        [DataMember]
        public string[][] YDistinctValues { get; protected set; }
        [DataMember]
        public bool IsXEncoded { get; protected set; }
        [DataMember]
        public bool IsYEncoded { get; protected set; }

        [DataMember]
        float[] _XMeans;
        [DataMember]
        float[] _XStdDevs;
        [DataMember]
        float[] _YMins;
        [DataMember]
        float[] _YMaxs;

        public int ExtraCols { get { return NumNewCols(XDistinctValues, XColTypes); } }

        #endregion

        #region Decode

        public string[,] DecodeY(float[,] data)
        {
            if (IsYEncoded)
            {
                var yExtraCols = NumNewCols(YDistinctValues, YColTypes);
                var result = new string[data.GetLength(0), data.GetLength(1) - yExtraCols];
                for (int row = 0; row < data.GetLength(0); ++row)
                {
                    int k = 0;
                    for (int col = 0; col < data.GetLength(1) - yExtraCols; ++col)
                    {
                        float val = data[row, k];
                        switch (YColTypes[col])
                        {
                            case ColumnType.Binary:
                                result[row, col] = BinaryDepenFromValue(val, col, YDistinctValues, MinY);
                                k++;
                                break;
                            case ColumnType.Categorical:
                                var values = new float[YDistinctValues[col].Length];
                                for (var i = 0; i < YDistinctValues[col].Length; i++)
                                {
                                    values[i] = data[row, k + i];
                                }
                                string vals = CatDepenFromValues(values, col, YDistinctValues, MinY);
                                k += YDistinctValues[col].Length;
                                result[row, col] = vals;
                                break;
                            default:
                                result[row, col] = NumDepenFromValue(val, col, _YMins, _YMaxs, MinY);
                                k++;
                                break;
                        }
                    }
                }
                return result;
            }
            else
            {
                var result = new string[data.GetLength(0), data.GetLength(1)];
                for (var i = 0; i < data.GetLength(0); i++)
                {
                    for (var j = 0; j < data.GetLength(1); j++)
                    {
                        result[i, j] = data[i, j].ToString();
                    }
                }
                return result;
            }

        }

        public string[,] DecodeX(float[,] data)
        {
            if (IsXEncoded)
            {
                var xExtraCols = NumNewCols(XDistinctValues, XColTypes);
                var result = new string[data.GetLength(0), data.GetLength(1) - xExtraCols];
                for (int row = 0; row < data.GetLength(0); ++row)
                {
                    int k = 0;
                    for (int col = 0; col < data.GetLength(1) - xExtraCols; ++col)
                    {
                        float val = data[row, k];
                        switch (XColTypes[col])
                        {
                            case ColumnType.Id:
                                break;
                            case ColumnType.Ignore:
                                break;
                            case ColumnType.Binary:
                                result[row, col] = BinaryIndepenFromValue(val, col, XDistinctValues);
                                k++;
                                break;
                            case ColumnType.Categorical:
                                var values = new float[XDistinctValues[col].Length];
                                for (var i = 0; i < XDistinctValues[col].Length; i++)
                                {
                                    values[i] = data[row, k + i];
                                }
                                string vals = CatIndepenFromValues(values, col, XDistinctValues);
                                result[row, col] = vals;
                                k += XDistinctValues[col].Length;
                                break;
                            default:
                                result[row, col] = NumIndepenFromValue(val, col, _XMeans, _XStdDevs);
                                k++;
                                break;
                        }
                    }
                }
                return result;
            }
            else
            {
                var result = new string[data.GetLength(0), data.GetLength(1)];
                for (var i = 0; i < data.GetLength(0); i++)
                {
                    for (var j = 0; j < data.GetLength(1); j++)
                    {
                        result[i, j] = data[i, j].ToString();
                    }
                }
                return result;
            }
        }

        #endregion

        public static void GetStats(string csvPath, long offset, long size,
            ColumnType[] ColTypes,
            out float[] means,out float[] stdDevs,out float[] maxs,out float[] mins)
        {
            var firstRow=Importer.ImportCsv(csvPath, false, 0, 1);
            var n = (long)firstRow.GetLength(1);
            var localMeans = new float[n]; var localStdDevs = new float[n]; var localMins = new float[n]; var localMaxs = new float[n];
            var maxSize = 1000*1000/n; // We allow a 64MB array max
            var subSize = Math.Min(size, maxSize);
            var curOffset = offset;
            var subData = Importer.ImportCsv(csvPath,false, curOffset, subSize);
            var nbRows = 0;
            do
            {
                Parallel.For(0, subData.GetLength(1), j =>
                {
                    localMins[j] = float.MaxValue;
                    if (ColTypes[j] == ColumnType.Numeric)
                    {
                        for (var i = 0; i < subData.GetLength(0); i++)
                        {
                            if (!string.IsNullOrEmpty(subData[i, j]))
                            {
                                float retNum;
                                float.TryParse(subData[i, j], System.Globalization.NumberStyles.Any, System.Globalization.NumberFormatInfo.InvariantInfo, out retNum);
                                localMeans[j] += retNum;
                                localMaxs[j] = localMaxs[j] > retNum ? localMaxs[j] : retNum;
                                localMins[j] = localMins[j] < retNum ? localMins[j] : retNum;
                            }
                        }
                    }
                });
                curOffset += subSize;
                nbRows += subData.GetLength(0);
                subData = Importer.ImportCsv(csvPath,false, curOffset, subSize);
            } while (subData != null);
            for (var j = 0; j < n; j++)
            {
                if (nbRows > 1) { localMeans[j] /= (float)nbRows; }
            }
            curOffset = offset;
            subData = Importer.ImportCsv(csvPath, false, curOffset, subSize);
            do
            {
                Parallel.For(0, subData.GetLength(1), j =>
                {
                    if (ColTypes[j] == ColumnType.Numeric)
                    {
                        for (var i = 0; i < subData.GetLength(0); i++)
                        {
                            float retNum;
                            float.TryParse(subData[i, j], System.Globalization.NumberStyles.Any, System.Globalization.NumberFormatInfo.InvariantInfo, out retNum);
                            localStdDevs[j] += (float)Math.Pow(retNum - localMeans[j], 2);
                        }
                    }
                });
                curOffset += subSize;
                subData = Importer.ImportCsv(csvPath, false, curOffset, subSize);
            } while (subData != null);
            for (var j = 0; j < n; j++)
            {
                if (nbRows > 1) { localStdDevs[j] /= (float)(nbRows - 1); }
                localStdDevs[j] = (float)Math.Sqrt(localStdDevs[j]);
            }
            means = localMeans; stdDevs = localStdDevs; mins = localMins; maxs = localMaxs;
        }


        public static void Encode(string[,] rawData, int[] outputColumns,
            string[][] distinctValues, ColumnType[] colTypes,
            float[] means, float[] stdDevs,float[] mins,float[] maxs,MinY minY,
            out float[,] X,out float[,] Y
            )
        {
            if (outputColumns == null) outputColumns = new int[0];
            var inputExtraCols = 0;
            var outputExtraCols = 0;
            var inputNbColToIgnore = 0;
            var outputNbColToIgnore = 0;
            for (int col = 0; col < rawData.GetLength(1); ++col)
            {
                if (outputColumns.Contains(col) && (colTypes[col] == ColumnType.Ignore || colTypes[col] == ColumnType.Id)) outputNbColToIgnore++;
                if (!outputColumns.Contains(col) && (colTypes[col] == ColumnType.Ignore || colTypes[col] == ColumnType.Id)) inputNbColToIgnore++;
                if (outputColumns.Contains(col) && (colTypes[col] == ColumnType.Categorical)) outputExtraCols+=distinctValues[col].Length;
                if (!outputColumns.Contains(col) && (colTypes[col] == ColumnType.Categorical)) inputExtraCols += distinctValues[col].Length;
                if (outputColumns.Contains(col) && (colTypes[col] != ColumnType.Categorical)) outputExtraCols -= 1;
                if (!outputColumns.Contains(col) && (colTypes[col] != ColumnType.Categorical)) inputExtraCols -= 1;
            }
            var x = new float[rawData.GetLength(0), rawData.GetLength(1) + inputExtraCols - inputNbColToIgnore - outputColumns.Length];
            var y = new float[rawData.GetLength(0), outputColumns.Length + outputExtraCols - outputNbColToIgnore];
            Parallel.For(0, rawData.GetLength(0), row =>
            {
                int xk = 0; int yk = 0;
                for (int col = 0; col < rawData.GetLength(1); ++col)
                {
                    string val = rawData[row, col];
                    switch (colTypes[col])
                    {
                        case ColumnType.Id:
                            break;
                        case ColumnType.Ignore:
                            break;
                        case ColumnType.Binary:
                            if (outputColumns.Contains(col))
                            {
                                y[row, yk++] = BinaryIndepenToValue(val, col, distinctValues);
                            }
                            else
                            {
                                x[row, xk++] = BinaryDepenToValue(val, col, distinctValues);
                            }
                            break;
                        case ColumnType.Categorical:
                            if (!distinctValues[col].Contains(val)) { val = "NA"; /*add unseen val for col in cache to log*/ }
                            if (outputColumns.Contains(col))
                            {
                                var vals = CatDepenToValues(val, col, distinctValues);
                                for (int j = 0; j < vals.Length; ++j)
                                    y[row, yk++] = vals[j] / vals.Length;// lower the values to avoid overfitting
                            }
                            else
                            {
                                var vals = CatIndepenToValues(val, col, distinctValues);
                                for (int j = 0; j < vals.Length; ++j)
                                    x[row, xk++] = vals[j] / vals.Length;// lower the values to avoid overfitting
                            }
                            break;
                        default:
                            if (outputColumns.Contains(col))
                            {
                                y[row, yk++] = NumIndepenToValue(val, col, means, stdDevs);
                            }
                            else
                            {
                                x[row, xk++] = NumDepenToValue(val, col, mins, maxs,minY);
                            }
                            break;
                    }
                }
            });
            X = x;
            Y = y;
        }

        public static void Encode(string outputRootPath, string csvPath, long offset, long size, int[] outputColumns,
            string[][] distinctValues, ColumnType[] colTypes,
            float[] means, float[] stdDevs,float[] mins,float[] maxs,MinY minY
            )
        {
            //GetStats(OutputColumns, csvPath, offset, size);
            // delete if exists outputPath
            var firstRow = Importer.ImportCsv(csvPath,false, 0, 1);
            var n = (long)firstRow.GetLength(1);
            var maxSize = 1000 * 1000 / n; // We allow a 64MB array max
            var subSize = Math.Min(size, maxSize);
            var subData = Importer.ImportCsv(csvPath, false, offset, subSize);
            do
            {
                float[,] X;float[,] Y;
                Encode(subData,outputColumns,distinctValues,colTypes,means,stdDevs,mins,maxs,minY,out X,out Y);
                //Exporter.ExportToMemoryFile(System.IO.Path.Combine(outputRootPath,"X.data"),offset,X);
                //Exporter.ExportToMemoryFile(System.IO.Path.Combine(outputRootPath,"Y.data"),offset,Y);
                Exporter.ExportCsv(System.IO.Path.Combine(outputRootPath, "X.csv"), offset, X);
                Exporter.ExportCsv(System.IO.Path.Combine(outputRootPath, "Y.csv"), offset, Y);
                offset += subSize;
                subData = Importer.ImportCsv(csvPath, false, offset, subSize);
            } while (subData != null);
        }

       


        #region Values Encoding Functions

        static float BinaryIndepenToValue(string val, int col, string[][] distinctValues) // binary x value -> -1 or +1
        {
            //if (distinctValues[col].Length != 2)
            //    throw new Exception("Binary x data only 2 values allowed");
            if (distinctValues[col][0] == val)
                return -1.0F;
            else
                return +1.0F;
        }
        static string BinaryIndepenFromValue(float val, int col, string[][] distinctValues) // binary x value -> -1 or +1
        {
            if (distinctValues[col].Length != 2)
                throw new Exception("Binary x data only 2 values allowed");
            if (val == -1.0F)
                return distinctValues[col][0];
            else
                return distinctValues[col][1];
        }

        static float BinaryDepenToValue(string val, int col, string[][] distinctValues, MinY minY = MinY.Zero) // binary y value -> 0 or 1
        {
            if (distinctValues[col].Length > 2)
                throw new Exception("Binary y data only 2 values allowed");
            if (distinctValues[col][0] == val)
                return (float)minY;
            else
                return 1.0F;
        }
        static string BinaryDepenFromValue(float val, int col, string[][] distinctValues, MinY minY = MinY.Zero) // binary y value -> 0 or 1
        {
            if (distinctValues[col].Length > 2)
                throw new Exception("Binary y data only 2 values allowed");
            if (val < (1.0F + (float)minY) / 2.0F)
                return distinctValues[col][0];
            else
                return distinctValues[col][1];
        }

        static float[] CatIndepenToValues(string val, int col, string[][] distinctValues) // categorical x value -> 1-of-(C-1) effects encoding
        {
            //if (distinctValues[col].Length == 2) throw new Exception("Categorical x data only 1, 3+ values allowed");
            int size = distinctValues[col].Length;
            float[] result = new float[size];

            int idx = 0;
            for (int i = 0; i < size; ++i)
            {
                if (distinctValues[col][i] == val)
                {
                    idx = i; break;
                }
            }

            if (idx == size - 1) // the value is the last one so use effects encoding
            {
                for (int i = 0; i < size; ++i) // ex: [-1.0, -1.0, -1.0]
                {
                    result[i] = -1.0F;
                }
            }
            else // value is not last, use dummy 
            {
                result[result.Length - 1 - idx] = +1.0F; // ex: [0.0, 1.0, 0.0]
            }
            return result;
        }
        static string CatIndepenFromValues(float[] val, int col, string[][] distinctValues) // categorical x value -> 1-of-(C-1) effects encoding
        {
            if (distinctValues[col].Length == 2)
                throw new Exception("Categorical x data only 1, 3+ values allowed");
            int size = distinctValues[col].Length;

            if (val[0] == -1.0F) return distinctValues[col][size - 1];

            int idx = 0;
            for (int i = 0; i < size; ++i)
            {
                if (val[i] == 1.0F)
                {
                    idx = i; break;
                }
            }
            return distinctValues[col][size - 1 - idx];
        }

        static float[] CatDepenToValues(string val, int col, string[][] distinctValues, MinY minY = MinY.Zero) // categorical y value -> 1-of-C dummy encoding
        {
            if (distinctValues[col].Length == 2)
                throw new Exception("Categorical x data only 1 or 3+ values allowed");
            int size = distinctValues[col].Length;
            float[] result = new float[size];
            for (var i = 0; i < result.Length; i++)
            {
                result[i] = (float)minY;
            }
            int idx = 0;
            for (int i = 0; i < size; ++i)
            {
                if (distinctValues[col][i] == val)
                {
                    idx = i; break;
                }
            }
            result[result.Length - 1 - idx] = 1.0F; // ex: [-1.0, 1.0, -1.0]
            return result;
        }
        static string CatDepenFromValues(float[] val, int col, string[][] distinctValues, MinY minY = MinY.Zero) // categorical y value -> 1-of-C dummy encoding
        {
            if (distinctValues[col].Length == 2)
                throw new Exception("Categorical x data only 1, 3+ values allowed");
            int size = distinctValues[col].Length;

            int idx = 0;
            for (int i = 0; i < size; ++i)
            {
                if (val[i] > (1.0F + (float)minY) / 2.0F)
                {
                    idx = i; break;
                }
            }
            return distinctValues[col][size - 1 - idx];
        }

        static float NumIndepenToValue(string val, int col, float[] means, float[] stdDevs) // numeric x value -> (x - m) / s
        {
            float x = float.Parse(val);
            float m = means[col];
            float sd = stdDevs[col];
            return (x - m) / sd;
        }
        static string NumIndepenFromValue(float val, int col, float[] means, float[] stdDevs) // numeric x value -> (x - m) / s
        {
            float m = means[col];
            float sd = stdDevs[col];
            return (val * sd + m).ToString();
        }

        //(x-min)/(max-min)	 for [0;1] or (2x-(max+min))/(max-min) for [-1;1]
        static float NumDepenToValue(string val, int col, float[] mins, float[] maxs, MinY minY)
        {
            float x = float.Parse(val);
            float min = mins[col];
            float max = maxs[col];
            if (minY == MinY.Zero)
            {
                return (x - min) / (max - min);
            }
            else
            {
                return (2.0F * x - max - min) / (max - min);
            }
        }
        static string NumDepenFromValue(float val, int col, float[] mins, float[] maxs, MinY minY)
        {
            float min = mins[col];
            float max = maxs[col];
            if (minY == MinY.Zero)
            {
                return (val * (max - min) + min).ToString();
            }
            else
            {
                return ((val * (max - min) + max + min) / 2.0F).ToString();
            }
        }

        static int NumNewCols(string[][] distinctValues, ColumnType[] colTypes)
        {
            // number of additional columns needed due to categorical encoding
            int result = 0;
            for (int i = 0; i < colTypes.Length; ++i)
            {
                if (colTypes[i] == ColumnType.Categorical)
                {
                    int numCatValues = distinctValues[i].Length;
                    result += numCatValues - 1;
                }
            }
            return result;
        }

        #endregion

       

        public static void Test()
        {
            var rawData = new string[,] { 
        {"male","60000.00","suburban","54","republican"}, 
        {"female","24000.00","city","28","democrat"},
        {"male","30000.00","rural","31","libertarian"},
        {"female","30000.00","suburban","48","republican"},
        {"female","18000.00","city","22","democrat"},
        {"male","56000.00","rural","39","other"}};

            var testData = new string[,] { 
        {"male","59000.00","suburban","54","republican"}, 
        {"female","24000.00","rural","28","democrat"},
        {"male","32000.00","rural","31","libertarian"}};

            Console.WriteLine("\nBegin transform");
            var encoder = new DataNormalizer(MinY.Zero);
            //var codedData = encoder.EncodeYTrain(rawData);
            //var check = encoder.DecodeY(codedData);
            Console.WriteLine("\nTransform complete");
        }

        public static ColumnType[] GetColTypes(string[,] data) { return null; }

        public float[,] EncodeXTrain(string[,] rawData)
        {
            throw new NotImplementedException();
        }

        public float[,] EncodeXTest(string[,] rawData)
        {
            throw new NotImplementedException();
        }

        public float[,] EncodeYTrain(string[,] rawData)
        {
            throw new NotImplementedException();
        }

        public float[,] EncodeYVal(string[,] rawData)
        {
            throw new NotImplementedException();
        }
    }
}
