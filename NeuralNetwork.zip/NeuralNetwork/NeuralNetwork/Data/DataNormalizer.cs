﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;

namespace NeuralNetwork
{
    [DataContract]
    public class DataNormalizer : IDataNormalizer
    {
        public DataNormalizer(MinY minY = MinY.Zero, ColumnType[] xColTypes = null, ColumnType[] yColTypes = null) { MinY = minY; XColTypes = xColTypes; YColTypes = yColTypes; }

        [DataMember]
        public MinY MinY { get; protected set; }

        [DataMember]
        public ColumnType[] XColTypes { get; set; }
        [DataMember]
        public ColumnType[] YColTypes { get; set; }

        [DataMember]
        protected string[][] _XDistinctValues;
        public string[][] XDistinctValues { get { return _XDistinctValues; } 
            protected set { 
                _XDistinctValues = value; 
            } }
        [DataMember]
        public string[][] YDistinctValues { get; protected set; }
        [DataMember]
        public bool IsXEncoded { get; protected set; }
        [DataMember]
        public bool IsYEncoded { get; protected set; }

        [DataMember]
        float[] _XMeans;
        [DataMember]
        float[] _XStdDevs;
        [DataMember]
        float[] _YMins;
        [DataMember]
        float[] _YMaxs;

        public int ExtraCols { get { return NumNewCols(XDistinctValues, XColTypes); } }

        #region Encode

        public float[,] EncodeXTrain(string[,] rawData)
        {
            XDistinctValues = GetDistinctValues(rawData);
            if (XColTypes == null)
            {
                XColTypes = GetColTypes(XDistinctValues);                
            }
            // Force NA to be added to all categorical/Binary columns. 
            // This will be handy for theTest set: all non seen values will be replaced by NA:
            for (var j = 0; j < XColTypes.Length; j++)
            {
                if (XColTypes[j] == ColumnType.Categorical || XColTypes[j] == ColumnType.Binary)
                {
                    var l = new List<string>(XDistinctValues[j]);
                    if (!l.Contains("NA"))
                    {
                        l.Add("NA");
                        XDistinctValues[j] = l.ToArray();
                    }
                    XColTypes[j] = ColumnType.Categorical;
                }
            }
            _XMeans = GetMeans(rawData, XColTypes);
            _XStdDevs = GetStdDevs(rawData, XColTypes, _XMeans);
            IsXEncoded = true;
            var xExtraCols = NumNewCols(XDistinctValues, XColTypes);
            return EncodeX(rawData, XDistinctValues, XColTypes, xExtraCols, _XMeans, _XStdDevs);
        }

        public float[,] EncodeYTrain(string[,] rawData)
        {
            YDistinctValues = GetDistinctValues(rawData);
            if (YColTypes == null)
            {
                YColTypes = GetColTypes(YDistinctValues);                
            }
            // Force NA to be added to all categorical/Binary columns. 
            // This will be handy for theTest set: all non seen values will be replaced by NA:
            for (var j = 0; j < YColTypes.Length; j++)
            {
                if (YColTypes[j] == ColumnType.Categorical || YColTypes[j] == ColumnType.Binary)
                {
                    var l = new List<string>(YDistinctValues[j]);
                    if (!l.Contains("NA"))
                    {
                        l.Add("NA");
                        YDistinctValues[j] = l.ToArray();
                    }
                    YColTypes[j] = ColumnType.Categorical;
                }
            }
            var yExtraCols = NumNewCols(YDistinctValues, YColTypes);
            _YMins = GetMins(rawData, YColTypes);
            _YMaxs = GetMaxs(rawData, YColTypes);
            var result = new float[rawData.GetLength(0), rawData.GetLength(1) + yExtraCols];
            for (int row = 0; row < rawData.GetLength(0); ++row)
            {
                int k = 0;
                for (int col = 0; col < rawData.GetLength(1); ++col)
                {
                    string val = rawData[row, col];
                    switch (YColTypes[col])
                    {
                        case ColumnType.Binary:
                            result[row, k++] = BinaryDepenToValue(val, col, YDistinctValues, MinY);
                            break;
                        case ColumnType.Categorical:
                            var vals = CatDepenToValues(val, col, YDistinctValues, MinY);
                            for (var j = 0; j < vals.Length; ++j)
                                result[row, k++] = vals[j];
                            break;
                        default:
                            result[row, k++] = NumDepenToValue(val, col, _YMins, _YMaxs, MinY);
                            break;
                    }
                }
            }
            //var test = Decode(result);
            IsYEncoded = true;
            return result;
        }

        public float[,] EncodeYVal(string[,] rawData)
        {
            if (!IsYEncoded) throw new Exception("You must encode YTrain before encoding YTest or YVal");
            var yExtraCols = NumNewCols(YDistinctValues, YColTypes);
            var distinctValues = GetDistinctValues(rawData);
            if (distinctValues.Length != YDistinctValues.Length)
            {
                throw new Exception(string.Format("The training and test data sets don't have the same number of columns: {0} vs {1}", distinctValues.Length, YDistinctValues.Length));
            }
            for (var col = 0; col < distinctValues.Length; col++)
            {
                if (YColTypes[col] != ColumnType.Numeric && YColTypes[col] != ColumnType.Ignore && YColTypes[col] != ColumnType.Id)
                {
                    var l1 = distinctValues[col].ToList(); var l2 = YDistinctValues[col].ToList();
                    var diff = l1.Except(l2);
                    foreach (var d in diff)
                    {
                        for (var i = 0; i < rawData.GetLength(0); i++)
                        {
                            if (rawData[i, col].Equals(d))
                            {
                                rawData[i, col] = "NA";
                            }
                        }
                    }
                }
            }
            var result = new float[rawData.GetLength(0), rawData.GetLength(1) + yExtraCols];
            for (int row = 0; row < rawData.GetLength(0); ++row)
            {
                int k = 0;
                for (int col = 0; col < rawData.GetLength(1); ++col)
                {
                    string val = rawData[row, col];
                    switch (YColTypes[col])
                    {
                        case ColumnType.Binary:
                            result[row, k++] = BinaryDepenToValue(val, col, YDistinctValues, MinY);
                            break;
                        case ColumnType.Categorical:
                            var vals = CatDepenToValues(val, col, YDistinctValues, MinY);
                            for (var j = 0; j < vals.Length; ++j)
                                result[row, k++] = vals[j];
                            break;
                        default:
                            result[row, k++] = NumDepenToValue(val, col, _YMins, _YMaxs, MinY);
                            break;
                    }
                }
            }
            return result;
        }

        public float[,] EncodeXTest(string[,] rawData)
        {
            if (IsXEncoded)
            {
                var xExtraCols = NumNewCols(XDistinctValues, XColTypes);
                var distinctValues = GetDistinctValues(rawData);
                if (distinctValues.Length != XDistinctValues.Length)
                {
                    throw new Exception(string.Format("The training and test data sets don't have the same number of columns: {0} vs {1}", distinctValues.Length, XDistinctValues.Length));
                }
                for (var col = 0; col < distinctValues.Length; col++)
                {
                    if (XColTypes[col] != ColumnType.Numeric && XColTypes[col] != ColumnType.Ignore && XColTypes[col] != ColumnType.Id)
                    {
                        var l1 = distinctValues[col].ToList(); var l2 = XDistinctValues[col].ToList();
                        var diff = l1.Except(l2);
                        foreach (var d in diff)
                        {
                            for (var i = 0; i < rawData.GetLength(0); i++)
                            {
                                if (rawData[i, col].Equals(d))
                                {
                                    rawData[i, col] = "NA";
                                }
                            }
                        }
                    }
                }
                return EncodeX(rawData, XDistinctValues, XColTypes, xExtraCols, _XMeans, _XStdDevs);
            }
            else
            {
                var m = rawData.GetLength(0); var n = rawData.GetLength(1);
                var res = new float[m, n];
                for (var i = 0; i < m; i++)
                {
                    for (var j = 0; j < n; j++)
                    {
                        float value;
                        var convertSuccess = float.TryParse(rawData[i, j], out value);
                        if (!convertSuccess) throw new Exception(string.Format("Train data needs to be encoded before predicting on test data. Indeed, some values in the test set cannont be converted to number, For example: {0}", rawData[i, j]));
                        res[i, j] = value;
                    }
                }
                return res;
            }
        }

        #endregion

        #region Decode

        public string[,] DecodeY(float[,] data)
        {
            if (IsYEncoded)
            {
                var yExtraCols = NumNewCols(YDistinctValues, YColTypes);
                var result = new string[data.GetLength(0), data.GetLength(1) - yExtraCols];
                for (int row = 0; row < data.GetLength(0); ++row)
                {
                    int k = 0;
                    for (int col = 0; col < data.GetLength(1) - yExtraCols; ++col)
                    {
                        float val = data[row, k];
                        switch (YColTypes[col])
                        {
                            case ColumnType.Binary:
                                result[row, col] = BinaryDepenFromValue(val, col, YDistinctValues, MinY);
                                k++;
                                break;
                            case ColumnType.Categorical:
                                var values = new float[YDistinctValues[col].Length];
                                for (var i = 0; i < YDistinctValues[col].Length; i++)
                                {
                                    values[i] = data[row, k + i];
                                }
                                string vals = CatDepenFromValues(values, col, YDistinctValues, MinY);
                                k += YDistinctValues[col].Length;
                                result[row, col] = vals;
                                break;
                            default:
                                result[row, col] = NumDepenFromValue(val, col, _YMins, _YMaxs, MinY);
                                k++;
                                break;
                        }
                    }
                }
                return result;
            }
            else
            {
                var result = new string[data.GetLength(0), data.GetLength(1)];
                for (var i = 0; i < data.GetLength(0); i++)
                {
                    for (var j = 0; j < data.GetLength(1); j++)
                    {
                        result[i, j] = data[i, j].ToString();
                    }
                }
                return result;
            }

        }

        public string[,] DecodeX(float[,] data)
        {
            if (IsXEncoded)
            {
                var xExtraCols = NumNewCols(XDistinctValues, XColTypes);
                var result = new string[data.GetLength(0), data.GetLength(1) - xExtraCols];
                for (int row = 0; row < data.GetLength(0); ++row)
                {
                    int k = 0;
                    for (int col = 0; col < data.GetLength(1) - xExtraCols; ++col)
                    {
                        float val = data[row, k];
                        switch (XColTypes[col])
                        {
                            case ColumnType.Id:
                                break;
                            case ColumnType.Ignore:
                                break;
                            case ColumnType.Binary:
                                result[row, col] = BinaryIndepenFromValue(val, col, XDistinctValues);
                                k++;
                                break;
                            case ColumnType.Categorical:
                                var values = new float[XDistinctValues[col].Length];
                                for (var i = 0; i < XDistinctValues[col].Length; i++)
                                {
                                    values[i] = data[row, k + i];
                                }
                                string vals = CatIndepenFromValues(values, col, XDistinctValues);
                                result[row, col] = vals;
                                k += XDistinctValues[col].Length;
                                break;
                            default:
                                result[row, col] = NumIndepenFromValue(val, col, _XMeans, _XStdDevs);
                                k++;
                                break;
                        }
                    }
                }
                return result;
            }
            else
            {
                var result = new string[data.GetLength(0), data.GetLength(1)];
                for (var i = 0; i < data.GetLength(0); i++)
                {
                    for (var j = 0; j < data.GetLength(1); j++)
                    {
                        result[i, j] = data[i, j].ToString();
                    }
                }
                return result;
            }
        }

        #endregion

        static string[][] GetDistinctValues(string[,] data)
        {
            int numRows = data.GetLength(0);
            var numCols = data.GetLength(1);
            string[][] result = new string[numCols][];
            for (int col = 0; col < numCols; ++col)
            {

                var d = new SortedDictionary<string, bool>(); // bool is a dummy
                for (int row = 0; row < numRows; ++row)
                {
                    string currVal = data[row, col];
                    if (d.ContainsKey(currVal) == false)
                        d.Add(currVal, true);
                }
                result[col] = new string[d.Count];
                int k = 0;
                foreach (string val in d.Keys)
                    result[col][k++] = val;
            }
            return result;
        }

        public static ColumnType[] GetColTypes(string[,] data)
        {
            var distinctValues = GetDistinctValues(data);
            var colTypes = GetColTypes(distinctValues);
            return colTypes;
        }

        static ColumnType[] GetColTypes(string[][] distinctValues)
        {
            var res = new ColumnType[distinctValues.Length];
            for (var j = 0; j < distinctValues.Length; j++)
            {
                res[j] = ColumnType.Categorical;
                if (distinctValues[j].Length.Equals(2))
                {
                    res[j] = ColumnType.Binary;
                }
                else
                {
                    var isNumeric = true;
                    for (var i = 0; i < distinctValues[j].Length; i++)
                    {
                        if (!IsNumeric(distinctValues[j][i]))
                        {
                            isNumeric = false; break;
                        }
                    }
                    if (isNumeric) res[j] = ColumnType.Numeric;
                }

            }
            return res;
        }

        #region Tools

        float[,] EncodeX(string[,] rawData, string[][] distinctValues, ColumnType[] colTypes, int extraCols, float[] means, float[] stdDevs, float[] weights = null)
        {
            var nbColToIgnore = 0;
            for (int col = 0; col < rawData.GetLength(1); ++col)
            {
                if (colTypes[col] == ColumnType.Ignore || colTypes[col] == ColumnType.Id) nbColToIgnore++;
            }
            var result = new float[rawData.GetLength(0), rawData.GetLength(1) + extraCols - nbColToIgnore];
            for (var row = 0; row < rawData.GetLength(0); row++)
            {
                int k = 0;
                for (int col = 0; col < rawData.GetLength(1); ++col)
                {
                    string val = rawData[row, col];
                    switch (colTypes[col])
                    {
                        case ColumnType.Id:
                            break;
                        case ColumnType.Ignore:
                            break;
                        case ColumnType.Binary:
                            result[row, k++] = BinaryIndepenToValue(val, col, distinctValues);
                            break;
                        case ColumnType.Categorical:
                            var vals = CatIndepenToValues(val, col, distinctValues);
                            var hack = 1F; if (col > 2) hack = 1F;
                            for (int j = 0; j < vals.Length; ++j)
                                result[row, k++] = vals[j] / hack;
                            break;
                        default:
                            result[row, k++] = NumIndepenToValue(val, col, means, stdDevs);
                            break;
                    }
                }
            }
            if (weights != null)
            {
                for (var j = 0; j < result.GetLength(1); j++)
                {
                    for (var i = 0; i < result.GetLength(0); i++)
                    {
                        if (weights[j] != 0F) result[i, j] /= weights[j];
                    }
                }
            }
            return result;
        }

        static bool IsNumeric(object Expression)
        {
            float retNum;
            if (string.IsNullOrEmpty(Convert.ToString(Expression))) { return true; }
            bool isNum = float.TryParse(Convert.ToString(Expression), System.Globalization.NumberStyles.Any, System.Globalization.NumberFormatInfo.InvariantInfo, out retNum);
            return isNum;
        }

        static float BinaryIndepenToValue(string val, int col, string[][] distinctValues) // binary x value -> -1 or +1
        {
            //if (distinctValues[col].Length != 2)
            //    throw new Exception("Binary x data only 2 values allowed");
            if (distinctValues[col][0] == val)
                return -1.0F;
            else
                return +1.0F;
        }
        static string BinaryIndepenFromValue(float val, int col, string[][] distinctValues) // binary x value -> -1 or +1
        {
            if (distinctValues[col].Length != 2)
                throw new Exception("Binary x data only 2 values allowed");
            if (val == -1.0F)
                return distinctValues[col][0];
            else
                return distinctValues[col][1];
        }

        static float BinaryDepenToValue(string val, int col, string[][] distinctValues, MinY minY = MinY.Zero) // binary y value -> 0 or 1
        {
            if (distinctValues[col].Length > 2)
                throw new Exception("Binary y data only 2 values allowed");
            if (distinctValues[col][0] == val)
                return (float)minY;
            else
                return 1.0F;
        }
        static string BinaryDepenFromValue(float val, int col, string[][] distinctValues, MinY minY = MinY.Zero) // binary y value -> 0 or 1
        {
            if (distinctValues[col].Length > 2)
                throw new Exception("Binary y data only 2 values allowed");
            if (val < (1.0F + (float)minY) / 2.0F)
                return distinctValues[col][0];
            else
                return distinctValues[col][1];
        }

        static float[] CatIndepenToValues(string val, int col, string[][] distinctValues) // categorical x value -> 1-of-(C-1) effects encoding
        {
            if (distinctValues[col].Length == 2)
                throw new Exception("Categorical x data only 1, 3+ values allowed");
            int size = distinctValues[col].Length;
            float[] result = new float[size];

            int idx = 0;
            for (int i = 0; i < size; ++i)
            {
                if (distinctValues[col][i] == val)
                {
                    idx = i; break;
                }
            }

            if (idx == size - 1) // the value is the last one so use effects encoding
            {
                for (int i = 0; i < size; ++i) // ex: [-1.0, -1.0, -1.0]
                {
                    result[i] = -1.0F;
                }
            }
            else // value is not last, use dummy 
            {
                result[result.Length - 1 - idx] = +1.0F; // ex: [0.0, 1.0, 0.0]
            }
            return result;
        }
        static string CatIndepenFromValues(float[] val, int col, string[][] distinctValues) // categorical x value -> 1-of-(C-1) effects encoding
        {
            if (distinctValues[col].Length == 2)
                throw new Exception("Categorical x data only 1, 3+ values allowed");
            int size = distinctValues[col].Length;

            if (val[0] == -1.0F) return distinctValues[col][size - 1];

            int idx = 0;
            for (int i = 0; i < size; ++i)
            {
                if (val[i] == 1.0F)
                {
                    idx = i; break;
                }
            }
            return distinctValues[col][size - 1 - idx];
        }

        static float[] CatDepenToValues(string val, int col, string[][] distinctValues, MinY minY = MinY.Zero) // categorical y value -> 1-of-C dummy encoding
        {
            if (distinctValues[col].Length == 2)
                throw new Exception("Categorical x data only 1 or 3+ values allowed");
            int size = distinctValues[col].Length;
            float[] result = new float[size];
            for (var i = 0; i < result.Length; i++)
            {
                result[i] = (float)minY;
            }
            int idx = 0;
            for (int i = 0; i < size; ++i)
            {
                if (distinctValues[col][i] == val)
                {
                    idx = i; break;
                }
            }
            result[result.Length - 1 - idx] = 1.0F; // ex: [-1.0, 1.0, -1.0]
            return result;
        }
        static string CatDepenFromValues(float[] val, int col, string[][] distinctValues, MinY minY = MinY.Zero) // categorical y value -> 1-of-C dummy encoding
        {
            if (distinctValues[col].Length == 2)
                throw new Exception("Categorical x data only 1, 3+ values allowed");
            int size = distinctValues[col].Length;

            int idx = 0;
            for (int i = 0; i < size; ++i)
            {
                if (val[i] > (1.0F + (float)minY) / 2.0F)
                {
                    idx = i; break;
                }
            }
            return distinctValues[col][size - 1 - idx];
        }

        static float NumIndepenToValue(string val, int col, float[] means, float[] stdDevs) // numeric x value -> (x - m) / s
        {
            float x = float.Parse(val);
            float m = means[col];
            float sd = stdDevs[col];
            return (x - m) / sd;
        }
        static string NumIndepenFromValue(float val, int col, float[] means, float[] stdDevs) // numeric x value -> (x - m) / s
        {
            float m = means[col];
            float sd = stdDevs[col];
            return (val * sd + m).ToString();
        }

        //(x-min)/(max-min)	 for [0;1] or (2x-(max+min))/(max-min) for [-1;1]
        static float NumDepenToValue(string val, int col, float[] mins, float[] maxs, MinY minY)
        {
            float x = float.Parse(val);
            float min = mins[col];
            float max = maxs[col];
            if (minY == MinY.Zero)
            {
                return (x - min) / (max - min);
            }
            else
            {
                return (2.0F * x - max - min) / (max - min);
            }
        }
        static string NumDepenFromValue(float val, int col, float[] mins, float[] maxs, MinY minY)
        {
            float min = mins[col];
            float max = maxs[col];
            if (minY == MinY.Zero)
            {
                return (val * (max - min) + min).ToString();
            }
            else
            {
                return ((val * (max - min) + max + min) / 2.0F).ToString();
            }
        }

        static int NumNewCols(string[][] distinctValues, ColumnType[] colTypes)
        {
            // number of additional columns needed due to categorical encoding
            int result = 0;
            for (int i = 0; i < colTypes.Length; ++i)
            {
                if (colTypes[i] == ColumnType.Categorical)
                {
                    int numCatValues = distinctValues[i].Length;
                    result += numCatValues - 1;
                }
            }
            return result;
        }

        // ---------------------------------------------------------------------------

        static float[] GetMeans(string[,] data, ColumnType[] colTypes)
        {
            var numRows = data.GetLength(0);
            var numCols = data.GetLength(1);
            float[] result = new float[numCols];
            for (int col = 0; col < numCols; ++col) // each column
            {
                if (colTypes[col] != ColumnType.Numeric) continue; // curr col is not numeric

                float sum = 0.0F;
                for (int row = 0; row < numRows; ++row)
                {
                    float val = float.Parse(data[row, col]);
                    if (float.IsNaN(val)) throw new Exception(string.Format("{0} is not numeric, as expected, in cell [{1},{2}]", data[row, col], row, col));
                    sum += val;
                }
                result[col] = sum / data.Length;
            }
            return result;
        }

        static float[] GetStdDevs(string[,] data, ColumnType[] colTypes, float[] means)
        {
            var numRows = data.GetLength(0);
            var numCols = data.GetLength(1);
            float[] result = new float[numCols];
            for (int col = 0; col < numCols; ++col) // each column
            {
                if (colTypes[col] != ColumnType.Numeric) continue; // curr col is not numeric

                float sum = 0.0F;
                for (int row = 0; row < numRows; ++row)
                {
                    float val = float.Parse(data[row, col]);
                    if (float.IsNaN(val)) throw new Exception(string.Format("{0} is not numeric, as expected, in cell [{1},{2}]", data[row, col], row, col));
                    sum += (val - means[col]) * (val - means[col]);
                }
                result[col] = (float)Math.Sqrt(sum / (data.Length - 1));
            }
            return result;
        }

        static float[] GetMins(string[,] data, ColumnType[] colTypes)
        {
            var numRows = data.GetLength(0);
            var numCols = data.GetLength(1);
            float[] result = new float[numCols];
            for (int col = 0; col < numCols; ++col) // each column
            {
                if (colTypes[col] != ColumnType.Numeric) continue; // curr col is not numeric

                float min = 0.0F;
                for (int row = 0; row < numRows; ++row)
                {
                    float val = float.Parse(data[row, col]);
                    if (float.IsNaN(val)) throw new Exception(string.Format("{0} is not numeric, as expected, in cell [{1},{2}]", data[row, col], row, col));
                    min = min < val ? min : val;
                }
                result[col] = min;
            }
            return result;
        }

        static float[] GetMaxs(string[,] data, ColumnType[] colTypes)
        {
            var numRows = data.GetLength(0);
            var numCols = data.GetLength(1);
            float[] result = new float[numCols];
            for (int col = 0; col < numCols; ++col) // each column
            {
                if (colTypes[col] != ColumnType.Numeric) continue; // curr col is not numeric

                float max = 0.0F;
                for (int row = 0; row < numRows; ++row)
                {
                    float val = float.Parse(data[row, col]);
                    if (float.IsNaN(val)) throw new Exception(string.Format("{0} is not numeric, as expected, in cell [{1},{2}]", data[row, col], row, col));
                    max = max > val ? max : val;
                }
                result[col] = max;
            }
            return result;
        }
        // ----------------------------------------------------------------------------

        #endregion

        public static void Test()
        {
            var rawData = new string[,] { 
        {"male","60000.00","suburban","54","republican"}, 
        {"female","24000.00","city","28","democrat"},
        {"male","30000.00","rural","31","libertarian"},
        {"female","30000.00","suburban","48","republican"},
        {"female","18000.00","city","22","democrat"},
        {"male","56000.00","rural","39","other"}};

            var testData = new string[,] { 
        {"male","59000.00","suburban","54","republican"}, 
        {"female","24000.00","rural","28","democrat"},
        {"male","32000.00","rural","31","libertarian"}};

            Console.WriteLine("\nBegin transform");
            var encoder = new DataNormalizer(MinY.Zero);
            var codedData = encoder.EncodeYTrain(rawData);
            var check = encoder.DecodeY(codedData);
            Console.WriteLine("\nTransform complete");
        }


    }
}
