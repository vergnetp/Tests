﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class DataGateway
    {
        protected IMissingDataHandler _MissingDataHandler;
        protected IDataNormalizer _DataNormalizer;        

        public DataGateway(IMissingDataHandler missingDataHandler,IDataNormalizer dataNormalizer)
        {
            _MissingDataHandler = missingDataHandler;
            _DataNormalizer = dataNormalizer;
        }

        public bool IsEncoded;
        public string[][] DistinctValues = null;public ColumnType[] ColTypes = null;
        public float[] Means = null; float[] StdDevs = null; float[] Mins = null; float[] Maxs = null;

        public void PrepareTrain(
            string rawDataPath,
            int[] outputColumns,  
            long offset=0, long size=long.MaxValue, string root=@"C:\temp", string xFileName="XTrain.csv", string yFileName="YTrain.csv",
            MinY minY=MinY.MinusOne
            )
        {
            var csvPath = Path.Combine(root, rawDataPath);
            var completeRowsPath = Path.Combine(root, "CompleteRows.csv");
            var completePath = Path.Combine(root, "Complete.csv");
            var xPath = Path.Combine(root, xFileName);
            var yPath = Path.Combine(root, yFileName);
            File.Delete(completeRowsPath);
            File.Delete(completePath);
            File.Delete(xPath);
            File.Delete(yPath);            
            MissingDataHandler.HandleTrain(outputColumns, completeRowsPath, csvPath,0, long.MaxValue, out DistinctValues, out ColTypes);         
            DataNormalizer.GetStats(completeRowsPath, offset, size, ColTypes, out Means, out StdDevs, out Maxs, out Mins);
            MissingDataHandler.HandlePartialNA(completePath, completeRowsPath, offset,size, DistinctValues, ColTypes,Means);          
            DataNormalizer.Encode(root,completePath, offset,size, outputColumns, DistinctValues, ColTypes, Means, StdDevs, Mins, Maxs, minY);
            IsEncoded = true;
        }

        public void PrepareTest(
            string rawDataPath,
            int[] outputColumns,
            long offset = 0, long size = long.MaxValue, string root = @"C:\temp", string xFileName = "XTest.csv", string yFileName = "YTest.csv",
            MinY minY = MinY.MinusOne
            )
        {
            if (!IsEncoded) throw new Exception("Training data must be encoded before the Test set.");
            var csvPath = Path.Combine(root, rawDataPath);
            var completeRowsPath = Path.Combine(root, "CompleteRows.csv");
            var completePath = Path.Combine(root, "Complete.csv");
            var xPath = Path.Combine(root, xFileName);
            var yPath = Path.Combine(root, yFileName);
            File.Delete(completeRowsPath);
            File.Delete(completePath);
            File.Delete(xPath);
            File.Delete(yPath);
            string[][] distinctValues = null; ColumnType[] colTypes = null;
            MissingDataHandler.HandleTrain(outputColumns, completeRowsPath, csvPath, offset, size, out distinctValues, out colTypes);  
            MissingDataHandler.HandlePartialNA(completePath, completeRowsPath, offset, size, DistinctValues, ColTypes, Means);
            DataNormalizer.Encode(root, completePath, offset, size, outputColumns, DistinctValues, ColTypes, Means, StdDevs, Mins, Maxs, minY);
        }
    }
}
