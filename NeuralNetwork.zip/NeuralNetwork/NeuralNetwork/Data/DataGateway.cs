﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class DataGateway
    {
        protected IMissingDataHandler _MissingDataHandler;
        protected IDataNormalizer _DataNormalizer;        

        public DataGateway(IMissingDataHandler missingDataHandler,IDataNormalizer dataNormalizer)
        {
            _MissingDataHandler = missingDataHandler;
            _DataNormalizer = dataNormalizer;
        }

        public static void PrepareTrain(string xFileName,string yFileName,
            int[] outputColumns, string root, string rawDataFileName, long offset=0, long size=long.MaxValue)
        {
            var csvPath = Path.Combine(root, rawDataFileName);
            var completeRowsPath = Path.Combine(root, "CompleteRows.csv");
            var completePath = Path.Combine(root, "Complete.csv");
            var xPath = Path.Combine(root, xFileName);
            var yPath = Path.Combine(root, yFileName);
            File.Delete(completeRowsPath);
            File.Delete(completePath);
            File.Delete(xPath);
            File.Delete(yPath);
            string[][] distinctValues = null; ColumnType[] colTypes = null;
            MissingDataHandler.HandleTrain(outputColumns, completeRowsPath, csvPath, offset, size, out distinctValues, out colTypes);

            float[] means = null; float[] stdDevs = null; float[] mins = null; float[] maxs = null;
            DataNormalizer.GetStats(completePath, offset, size, colTypes, out means, out stdDevs, out maxs, out mins);
            MissingDataHandler.HandlePartialNA(completePath, completeRowsPath, offset,size, distinctValues, colTypes,means);          
            DataNormalizer.Encode(root,completePath, offset,size, outputColumns, distinctValues, colTypes, means, stdDevs, mins, maxs, MinY.MinusOne);
        }

    }
}
