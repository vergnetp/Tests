﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class ModelNeuralNetwork:IModel
    {

        // NB. those are reset at each call to Initialize (or ResetWeights)
        protected List<float[,]> _Thetas;
        protected List<float[]> _Biaises;       
        protected int _NbWeights;

        protected void Unroll()
        {
            Unroll(Weights,ref _Thetas,ref _Biaises);
        }
        public void Unroll(float[] weights,ref List<float[,]> thetas,ref List<float[]> biaises)
        {
            //from weights to thetas and biaises
            var startIndex = 0;
            foreach (var t in thetas)
            {
                t.UnRoll(weights, startIndex);
                startIndex += t.Length;
            }
            foreach (var b in biaises)
            {
                weights.CopyFrom(b, startIndex);
                startIndex += b.Length;
            }
        }
        public float[] Roll(List<float[,]> thetas,List<float[]> biaises)
        {
            // from thetas and biaises to weights
            var weightsLength = 0;
            thetas.ForEach(x => weightsLength += x.Length);
            biaises.ForEach(x => weightsLength += x.Length);
            var weights = new float[weightsLength];
            var startIndex = 0;
            foreach(var t in thetas)
            {
                t.Roll(weights, startIndex);
                startIndex += t.Length;
            }
            foreach (var b in biaises)
            {
                weights.CopyInto(b, startIndex);
                startIndex += b.Length;
            }
            return weights;
        }

        public IActivator Activator;
              
        public ModelNeuralNetwork(int nbFeatures,int nbClasses,int[] hiddenLayerSizes,IRegularizedCostCalculator costCalculator,IActivator activator) 
        {
            Activator = activator;
            CostCalculator=costCalculator;
            Parameters = new ParametersNeuralNetwork();            
            Initialize(hiddenLayerSizes,nbFeatures,nbClasses);           
        }

        public IModel Clone()
        {
            var costCalculator = this.CostCalculator.Clone();
            var model = System.Activator.CreateInstance(this.GetType(), this.ModelParameters.NbFeatures,this.ModelParameters.NbClasses,this.ModelParameters.HiddenLayerSizes,costCalculator,this.Activator) as IModel;
            model.Weights=this.Weights;
            return model;
        }

        public Parameters Parameters { get; set; }

        public ParametersNeuralNetwork ModelParameters
        {
            get
            {
                return (ParametersNeuralNetwork)this.Parameters;
            }
        }

        public void Initialize(int[] hiddenLayerSizes,int nbFeatures,int nbClasses)
        {
            this.ModelParameters.HiddenLayerSizes = hiddenLayerSizes;
            this.ModelParameters.NbFeatures = nbFeatures;
            this.ModelParameters.NbClasses = nbClasses;
            _NbWeights=0;
            var weights = new List<float[,]>();
            var biaises = new List<float[]>();
            var w = new float[this.ModelParameters.HiddenLayerSizes[0], this.ModelParameters.NbFeatures];
            w.Randomize();
            weights.Add(w);
            var b = new float[this.ModelParameters.HiddenLayerSizes[0]];
            b.Randomize();
            biaises.Add(b);
            _NbWeights+=w.Length+b.Length;
            for (var l = 0; l + 1 < this.ModelParameters.HiddenLayerSizes.Length; l++)
            {
                w = new float[this.ModelParameters.HiddenLayerSizes[l + 1], this.ModelParameters.HiddenLayerSizes[l]];
                w.Randomize();
                weights.Add(w);
                b = new float[this.ModelParameters.HiddenLayerSizes[l + 1]];
                b.Randomize();
                biaises.Add(b);
                _NbWeights+=w.Length+b.Length;
            }
            w = new float[this.ModelParameters.NbClasses, this.ModelParameters.HiddenLayerSizes.Last()]; 
            w.Randomize();
            weights.Add(w);
            b = new float[this.ModelParameters.NbClasses]; 
            b.Randomize();
            biaises.Add(b);
            _NbWeights+=w.Length+b.Length;
            _Thetas = weights;
            _Biaises = biaises;            
            Weights=Roll(_Thetas,_Biaises);
        }

        public void ResetWeights(int nbFeatures, int nbClasses)
        {
            Initialize(this.ModelParameters.HiddenLayerSizes,nbFeatures,nbClasses);
        }

        private float[] _Weights;
        public float[] Weights 
        { 
            get { return _Weights; } 
            set 
            {
                _Weights = value; 
                Unroll();
            } 
        }
      
        public float[] GetGradients(float[,] X, float[,] Y)
        {
            if (Weights == null || !X.GetLength(1).Equals(this.ModelParameters.NbFeatures) || !Y.GetLength(1).Equals(this.ModelParameters.NbClasses))
            {
                Initialize(this.ModelParameters.HiddenLayerSizes, X.GetLength(1), Y.GetLength(1));
            }

            // todo: think about putting regularization in costderivate
            var w = _Thetas;
            var b = _Biaises;
            var weightsGrad = new List<float[,]>();
            var biaisesGrad = new List<float[]>();

            // Forward pass:
            var zsAndActivations = GetZsAndActivations(X);
            var zs=zsAndActivations.Item1;
            var activations=zsAndActivations.Item2;
            
            // Backpropagation:
            var averagor = 1.0F / (float)X.GetLength(0);
            float[,] d = null;
            for (var l = ModelParameters.HiddenLayerSizes.Length + 1; l > 0; l--)
            {
                if (l == ModelParameters.HiddenLayerSizes.Length + 1)
                {
                    // Output layer: 
                    if (CostCalculator.CostCalculator is CostCalculatorLogistic)
                    {
                        d = activations[l].Subtract(Y); // Could save minutes on big data
                    }
                    else
                    {
                        d = CostCalculator.CostCalculator.CostDerivate(activations[l], Y);
                        d = d.ElementwiseMultiply(zs[l].Apply(Activator.ActivateDerivate));
                    }
                }
                else
                {
                    // Previous layers:
                    d = d.MultiplyBy( w[l]);
                    d = d.ElementwiseMultiply(zs[l].Apply(Activator.ActivateDerivate));
                }
                var grad = d.TransposeAndMultiply(activations[l - 1]).Multiply(averagor);//d'*a[1]./m
                if (CostCalculator.RegularizationScheme==RegularizationScheme.L2Norm)
                {
                    grad = grad.Add(w[l - 1].Multiply((float)this.CostCalculator.RegularizationBudget/(float)X.GetLength(0))); // d + w[2].*lambda // Regularization
                }
                if (CostCalculator.RegularizationScheme == RegularizationScheme.L1Norm)
                {
                    grad = grad.Add((w[l - 1].Apply(x => x / Math.Abs(x))).Multiply(this.CostCalculator.RegularizationBudget / X.GetLength(0))); // d + sign(w[2]).*lambda // Regularization
                }
                // Test: regularization on specific features:
                //if (l - 1 == 0)
                //{
                //    for (var i = 5; i <562; i++)
                //    {
                //        for (var j = 0; j < grad.GetLength(0); j++)
                //        {
                //            grad[j,i] += w[l - 1][j,i] * 0.8F;
                //        }
                //    }
                //}
                // End Test
                weightsGrad.Insert(0, grad);
                var ones = Accord.Math.Matrix.Reshape(Accord.Math.Matrix.Vector(d.GetLength(0), 1.0F),d.GetLength(0), 1);
                biaisesGrad.Insert(0, Accord.Math.Matrix.Reshape(d.TransposeAndMultiply(ones).Multiply(averagor)));//d'*[1s]/m //average per row
            } 
            var res = Roll(weightsGrad, biaisesGrad);
            return res;
        }

        protected Tuple<List<float[,]>,List<float[,]>> GetZsAndActivations(float[,] X)
        {
            Unroll();
            var activations = new List<float[,]>();
            var zs = new List<float[,]>();            
            var w = _Thetas;
            var b = _Biaises;
            activations.Add(X);
            zs.Add(X);
            for (var l = 0; l < ModelParameters.HiddenLayerSizes.Length + 1; l++)
            {
                var z=activations[l].MultiplyByTranspose(w[l]).Add(b[l], 0);
                var activation = z.Apply(Activator.Activate);
                zs.Add(z);
                activations.Add(activation);
            }
            return new Tuple<List<float[,]>,List<float[,]>>(zs,activations);
        }

        public float[,] Predict(float[,] X)
        {
            if (!X.GetLength(1).Equals(this.ModelParameters.NbFeatures)) throw new Exception(string.Format("The Neural Network was trained on {0} features and cannot predict on {1}.",this.ModelParameters.NbFeatures,X.GetLength(1)));
            var tuple = GetZsAndActivations(X);            
            var activations=tuple.Item2;
            var output=activations.Last();
            return output;
        }

        public IRegularizedCostCalculator CostCalculator{get;set;}
      
    }
}
