﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace NeuralNetwork
{
    [DataContract]
    public class Parameters
    {
        [DataMember]
        public int NbFeatures { get; set; }
        [DataMember]
        public int NbClasses { get; set; }
    }
}
