﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class ModelDecisionTree:IModel
    {

        public IModel Clone()
        {
            return new ModelDecisionTree();
        }

        public Parameters Parameters { get; set; }

        public class Node
        {
            public int Col;
            public Node[] Children;
            public float Value;
            public float Class;
            public bool IsLeaf;
        }

        protected Node _Tree;

        protected float GetClass(Node node,float targetValue)
        {
            if(node.Value.Equals(targetValue)&&node.IsLeaf)
            {
                return node.Class;
            }
            var newNode =node.Children.Where(child => child.Value.Equals(targetValue)).ToList().First();
            return GetClass(newNode, targetValue);
        }

        public float[,] Predict(float[,] X)
        {
            var m = X.GetLength(0);
            var res = new float[m, 1];
            for (var i=0;i<m;i++)
            {

                var value = X[i, _Tree.Col];
                var theClass = GetClass(_Tree, value);
                res[i, 1] = theClass;
            }
            return res;
        }

        protected void MakeTree(float[,] X,float[,] Y)
        {

        }




        public float[] Weights
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        
        public IRegularizedCostCalculator CostCalculator
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public void Initialize()
        {
            throw new NotImplementedException();
        }

        public void ResetWeights()
        {
            throw new NotImplementedException();
        }

        public void ResetWeights(int nbFeatures,int nbClasses)
        {
            throw new NotImplementedException();
        }

        public float[] GetGradients(float[,] X, float[,] Y)
        {
            throw new NotImplementedException();
        }

        
    }
}
