﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class ImpurityFunctionEntropy:IImpurityFunction
    {
        public float Calculate(float[] classes)
        {
            var res = 0.0F;
            var dico = new Dictionary<float, int>();
            var nbValues = classes.GetLength(0);
            for(var i=0;i<nbValues;i++)
            {
                var theClass=classes[i];
                if (dico.ContainsKey(theClass))
                {
                    dico[theClass] += 1;
                }
                else
                {
                    dico[theClass] = 1;
                }
            }
            foreach(var key in dico.Keys)
            {
                var nbOccurences = dico[key];
                var frequency = nbOccurences / nbValues;
                res -= frequency * (float)Math.Log(frequency);
            }
            return res;
        }
    }
}
