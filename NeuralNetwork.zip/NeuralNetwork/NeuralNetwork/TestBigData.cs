﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class TestBigData
    {
        public static void Test()
        {
            var root = @"C:\Users\philippe\Desktop\Data\Titanic";
            int[] outputColumns = null;   
            var csvPath = root + "\\Book1.csv";
            System.IO.File.Delete(root + "\\completeY.csv");
            System.IO.File.Delete(root + "\\complete.csv");
            System.IO.File.Delete(root + "\\X.csv");
            List<string>[] distinctValues = null; ColumnType[] colTypes = null;
            MissingDataHandler.HandleTrain(outputColumns, root + "\\completeY.csv", csvPath, 0, 100,out distinctValues,out colTypes);
           // MissingDataHandler.HandlePartialNA( root + "\\complete.csv", root + "\\completeY.csv", 0, 100,distinctValues,colTypes);

            float[] means=null; float[] stdDevs=null; float[] mins=null; float[] maxs=null;
            DataNormalizer.GetStats(root + "\\complete.csv", 0,100,  colTypes, out means, out stdDevs, out maxs, out mins);
            DataNormalizer.Encode(root , root + "\\complete.csv", 0, 100, outputColumns, distinctValues, colTypes, means, stdDevs, mins, maxs, MinY.MinusOne);

            var check = Importer.ImportCsvAsFloat(root + "\\X.csv", false);
            //var check=Importer.ImportFromMemoryFile(root +"\\X.data",734);
            var deb = 4;
            var nbrows = check.GetLength(0);
            var nbCols = check.GetLength(1);
        }
    }
}
