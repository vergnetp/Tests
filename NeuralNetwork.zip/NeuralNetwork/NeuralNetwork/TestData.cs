﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class TestData
    {
        public static float[,] GenerateVehiclesXTrain()
        {
            var XTrain = new float[10, 4]
            {
                {900.0F,2.0F,10.0F,4.0F},
                {800.0F,2.2F,8.0F,17.0F},
                {700.0F,1.8F,8.0F,1.0F},
                {300.0F,1.5F,4.0F,8.0F},
                {230.0F,1.4F,4.0F,17.0F},
                {250.0F,1.4F,4.0F,2.0F},
                {270.0F,1.4F,4.0F,3.0F},
                {90.0F,1.0F,2.0F,3.0F},
                {100.0F,0.9F,2.0F,3.0F},
                {110.0F,1.2F,2.0F,3.0F}
            };
            return XTrain;
        }

        public static float[,] GenerateVehiclesYTrain()
        {
            var YTrain = new float[10, 3]
            {
                {1.0F,0.0F,0.0F},
                {1.0F,0.0F,0.0F},
                {1.0F,0.0F,0.0F},
                {0.0F,1.0F,0.0F},
                {0.0F,1.0F,0.0F},
                {0.0F,1.0F,0.0F},
                {0.0F,1.0F,0.0F},
                {0.0F,0.0F,1.0F},
                {0.0F,0.0F,1.0F},
                {0.0F,0.0F,1.0F}
            };
            return YTrain;
        }

        public static float[,] GenerateVehiclesXVal()
        {
            var XVal = new float[6, 4]
            {
                {900.0F,2.0F,10.0F,4.0F},
                {800.0F,2.2F,8.0F,17.0F},
                {770.0F,2.2F,9.0F,17.0F},
                {370.0F,1.4F,4.0F,17.0F},
                {70.0F,1.1F,2.0F,17.0F},
                {10.0F,0.2F,2.0F,17.0F}
            };
            return XVal;
        }

        public static float[,] GenerateVehiclesYVal()
        {
            var YVal = new float[6, 3]
            {
                {1.0F,0.0F,0.0F},
                {1.0F,0.0F,0.0F},
                {1.0F,0.0F,0.0F},
                {0.0F,1.0F,0.0F},
                {0.0F,0.0F,1.0F},
                {0.0F,0.0F,1.0F}
            };
            return YVal;
        }

        public static float[,] GenerateCourseraTheta1()
        {
            return new float[5, 3]
            {
                {  -0.027942F,  -0.099999F,-0.028790F},
                {   0.065699F,  -0.053657F,-0.096140F},
                {   0.098936F,   0.042017F,-0.075099F},
                {  0.041212F,   0.099061F,0.014988F},
                { -0.054402F,   0.065029F,0.091295F}
            };
        }

        public static float[] GenerateCourseraBiais1()
        {
            return new float[5]
            {
                0.084147F,
                 0.090930F,
                 0.014112F,
                 -0.075680F,
                -0.095892F
            };
        }

        public static float[,] GenerateCourseraTheta2()
        {
            return new float[3, 5]
            {
                {  -0.075680F,   0.065699F,  -0.054402F,   0.042017F,-0.028790F},  
                {  -0.095892F,   0.098936F,  -0.099999F,   0.099061F,-0.096140F},  
                {  -0.027942F,   0.041212F,  -0.053657F,   0.065029F,-0.075099F},  
            };
        }

        public static float[] GenerateCourseraBiais2()
        {
            return new float[3]
            {
                0.084147F,0.090930F,0.014112F,
            };
        }

        public static float[,] GenerateCourseraX()
        {
            return new float[5,3]
            {
                {0.084147F,  -0.027942F,  -0.099999F},
                {0.090930F,   0.065699F,  -0.053657F},
                {0.014112F,   0.098936F,   0.042017F},
                {-0.075680F,   0.041212F,   0.099061F},
                {-0.095892F,  -0.054402F,   0.065029F}
            };
        }

        public static float[,] GenerateCourseraY()
        {
            return new float[5,3]
            {
                {0.0F,1.0F,0.0F},
                {0.0F,0.0F,1.0F},
                {1.0F,0.0F,0.0F},
                {0.0F,1.0F,0.0F},
                {0.0F,0.0F,1.0F}
            };           
        }

    }
}
