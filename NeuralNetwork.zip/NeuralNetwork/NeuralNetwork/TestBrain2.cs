﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class TestBrain2
    {
        public static void Test()
        {
            var root = @"C:\Users\philippe\Desktop\Data\Titanic";
            //var root = @"C:\Users\UK800386\Desktop\";
            var xTrain = Path.Combine(root, "Train.csv");       
            var brain = new Brain2();
            brain.CrossValidate(xTrain, new[] { 0 });
        }
    }
}
