﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class TestSelector
    {
        public static void Test()
        {
            var accuracyAssessor = new AccuracyAssessor();
            var activator = new ActivatorSigmoid();
            var costCalculator = new CostCalculatorLogistic();
            var regularizedCostCalculator = new RegularizedCostCalculator(costCalculator, RegularizationScheme.L2Norm, 1.0F);

            var XTrain = TestData.GenerateVehiclesXTrain();
            var YTrain = TestData.GenerateVehiclesYTrain();
            var XVal = TestData.GenerateVehiclesXVal();
            var YVal = TestData.GenerateVehiclesYVal();
            var normalizer = new DataNormalizer();
            float[,] normalizedXTrain = null;// normalizer.EncodeXTrain(XTrain);
            float[,] normalizedXVal = null;// normalizer.EncodeXTest(XVal);

            var network = new ModelNeuralNetwork(normalizedXTrain.GetLength(1), YTrain.GetLength(1), new int[1] { 25 }, regularizedCostCalculator, activator);
            var solver = new SolverMomentum(network,null,normalizer, 1000, 0.01F, 0.8F, 0.9F);

            var regularizedCostCalculator2 = new RegularizedCostCalculator(costCalculator, RegularizationScheme.L2Norm, 0.3F);
            var network2 = new ModelNeuralNetwork(normalizedXTrain.GetLength(1), YTrain.GetLength(1), new int[1] { 25 }, regularizedCostCalculator2, activator);
            var solver2 = new SolverMomentum(network2, null, normalizer, 100000, 0.1F, 0.8F, 0.2F);

            //var selector = new ModelSelectorByCrossValidation(4);
            var models = new List<ISolver>() { solver, solver };
            var winner = solver2;// selector.SelectModel(normalizedXTrain, YTrain, models);

            var gradientOk = winner.CheckGradient(normalizedXTrain, YTrain);
            Console.WriteLine("Gradient is OK: {0}", gradientOk);
            var isOk = winner.Fit(normalizedXTrain, YTrain);
            Console.WriteLine("Solver converged: {0}", isOk);
            var valPredictions = winner.Model.Predict(normalizedXVal);
            var trainPredictions = winner.Model.Predict(normalizedXTrain);

            //var accuracy = accuracyAssessor.AssessAccuracy(trainPredictions, YTrain);
            var lastCost = winner.Model.CostCalculator.Cost(trainPredictions, YTrain, winner.Model.Weights);
            var lastIteration = winner.LastIteration;
            Console.WriteLine("Last iteration: {0}", lastIteration);
            Console.WriteLine("Last cost: {0}", lastCost);
            //Console.WriteLine("Last accuracy: {0:P}", accuracy);

            //accuracy = accuracyAssessor.AssessAccuracy(valPredictions, YVal);
            lastCost = winner.Model.CostCalculator.Cost(valPredictions, YVal, winner.Model.Weights);
            Console.WriteLine("Validation cost: {0}", lastCost);
            //Console.WriteLine("Validation accuracy: {0:P}", accuracy);
        }
    }
}
