﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class TestImport
    {
        public static void Test()
        {
            Exporter.ExportCsv(@"C:\temp\w.csv", new float[2, 1] { { 4 }, { 8 } });
            var ret = Importer.ImportCsvAsFloat(@"C:\temp\w.csv", false, 0, 0);
            System.IO.File.Delete(@"C:\temp\w.csv");
            if (ret != null) throw new Exception("Ret must be null");

            Exporter.ExportCsv(@"C:\temp\w.csv", new float[2, 1] { { 4 }, { 8 } });
            ret = Importer.ImportCsvAsFloat(@"C:\temp\w.csv", true, 0, 0);
            System.IO.File.Delete(@"C:\temp\w.csv");
            if (ret != null) throw new Exception("Ret must be null");

            Exporter.ExportCsv(@"C:\temp\w.csv", new float[2, 1] { { 4 }, { 8 } });
            ret = Importer.ImportCsvAsFloat(@"C:\temp\w.csv", true, 1, 1);
            System.IO.File.Delete(@"C:\temp\w.csv");
            if (ret != null) throw new Exception("Ret must be null");

            Exporter.ExportCsv(@"C:\temp\w.csv", new float[2, 1] { { 4 }, { 8 } });
            ret = Importer.ImportCsvAsFloat(@"C:\temp\w.csv", true,1, 0);
            System.IO.File.Delete(@"C:\temp\w.csv");
            if (ret != null) throw new Exception("Ret must be null");

            Exporter.ExportCsv(@"C:\temp\w.csv", new float[2, 1] { { 4 }, { 8 } });
            ret = Importer.ImportCsvAsFloat(@"C:\temp\w.csv", true, 2, 1);
            System.IO.File.Delete(@"C:\temp\w.csv");
            if (ret != null) throw new Exception("Ret must be null");

            Exporter.ExportCsv(@"C:\temp\w.csv", new float[2, 1] { { 4 }, { 8 } });
            ret = Importer.ImportCsvAsFloat(@"C:\temp\w.csv", false, 0, 2);
            System.IO.File.Delete(@"C:\temp\w.csv");
            if (ret[0,0] != 4 || ret[1,0]!=8) throw new Exception("Ret must be {{4},{8}}");

            Exporter.ExportCsv(@"C:\temp\w.csv", new float[2, 1] { { 4 }, { 8 } });
            ret = Importer.ImportCsvAsFloat(@"C:\temp\w.csv", false, 0, 1);
            System.IO.File.Delete(@"C:\temp\w.csv");
            if (ret[0, 0] != 4 || ret.GetLength(0)!=1) throw new Exception("Ret must be {{4}}");
            
            Exporter.ExportCsv(@"C:\temp\w.csv", new float[2, 1] { { 4 }, { 8 } });
            ret = Importer.ImportCsvAsFloat(@"C:\temp\w.csv", false, 1, 1);
            System.IO.File.Delete(@"C:\temp\w.csv");
            if (ret[0, 0] != 8 || ret.GetLength(0) != 1) throw new Exception("Ret must be {{8}}");

            Exporter.ExportCsv(@"C:\temp\w.csv", new float[2, 1] { { 4 }, { 8 } });
            ret = Importer.ImportCsvAsFloat(@"C:\temp\w.csv", true,0, 1);
            System.IO.File.Delete(@"C:\temp\w.csv");
            if (ret[0, 0] != 8 || ret.GetLength(0) != 1) throw new Exception("Ret must be {{8}}");

            Exporter.ExportCsv(@"C:\temp\w.csv", new float[2, 1] { { 4 }, { 8 } });
            ret = Importer.ImportCsvAsFloat(@"C:\temp\w.csv", true, 0, 2);
            System.IO.File.Delete(@"C:\temp\w.csv");
            if (ret[0, 0] != 8 || ret.GetLength(0) != 1) throw new Exception("Ret must be {{8}}");

            TestString();
        }

        public static void TestString()
        {

            Exporter.ExportCsv(@"C:\temp\w.csv", new string[2, 1] { { "4 "}, { "8" } });
            var ret = Importer.ImportCsv(@"C:\temp\w.csv", false, 0, 0);
            System.IO.File.Delete(@"C:\temp\w.csv");
            if (ret != null) throw new Exception("Ret must be null");

            Exporter.ExportCsv(@"C:\temp\w.csv", new string[2, 1] { { "4 " }, { "8" } });
            ret = Importer.ImportCsv(@"C:\temp\w.csv", true, 0, 0);
            System.IO.File.Delete(@"C:\temp\w.csv");
            if (ret != null) throw new Exception("Ret must be null");

            Exporter.ExportCsv(@"C:\temp\w.csv", new string[2, 1] { { "4 " }, { "8" } });
            ret = Importer.ImportCsv(@"C:\temp\w.csv", true, 1, 1);
            System.IO.File.Delete(@"C:\temp\w.csv");
            if (ret != null) throw new Exception("Ret must be null");

            Exporter.ExportCsv(@"C:\temp\w.csv", new string[2, 1] { { "4 " }, { "8" } });
            ret = Importer.ImportCsv(@"C:\temp\w.csv", true, 1, 0);
            System.IO.File.Delete(@"C:\temp\w.csv");
            if (ret != null) throw new Exception("Ret must be null");

            Exporter.ExportCsv(@"C:\temp\w.csv", new string[2, 1] { { "4" }, { "8" } });
            ret = Importer.ImportCsv(@"C:\temp\w.csv", true, 2, 1);
            System.IO.File.Delete(@"C:\temp\w.csv");
            if (ret != null) throw new Exception("Ret must be null");

            Exporter.ExportCsv(@"C:\temp\w.csv", new string[2, 1] { { "4" }, { "8" } });
            ret = Importer.ImportCsv(@"C:\temp\w.csv", false, 0, 2);
            System.IO.File.Delete(@"C:\temp\w.csv");
            if (ret[0, 0] != "4" || ret[1, 0] !="8") throw new Exception("Ret must be {{4},{8}}");

            Exporter.ExportCsv(@"C:\temp\w.csv", new string[2, 1] { { "4" }, { "8" } });
            ret = Importer.ImportCsv(@"C:\temp\w.csv", false, 0, 1);
            System.IO.File.Delete(@"C:\temp\w.csv");
            if (ret[0, 0] != "4" || ret.GetLength(0) != 1) throw new Exception("Ret must be {{4}}");

            Exporter.ExportCsv(@"C:\temp\w.csv", new string[2, 1] { { "4" }, { "8" } });
            ret = Importer.ImportCsv(@"C:\temp\w.csv", false, 1, 1);
            System.IO.File.Delete(@"C:\temp\w.csv");
            if (ret[0, 0] != "8" || ret.GetLength(0) != 1) throw new Exception("Ret must be {{8}}");

            Exporter.ExportCsv(@"C:\temp\w.csv", new string[2, 1] { { "4" }, { "8" } });
            ret = Importer.ImportCsv(@"C:\temp\w.csv", true, 0, 1);
            System.IO.File.Delete(@"C:\temp\w.csv");
            if (ret[0, 0] != "8" || ret.GetLength(0) != 1) throw new Exception("Ret must be {{8}}");

            Exporter.ExportCsv(@"C:\temp\w.csv", new string[2, 1] { { "4" }, { "8" } });
            ret = Importer.ImportCsv(@"C:\temp\w.csv", true, 0, 2);
            System.IO.File.Delete(@"C:\temp\w.csv");
            if (ret[0, 0] != "8" || ret.GetLength(0) != 1) throw new Exception("Ret must be {{8}}");

        }

    }
}
