﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace NeuralNetwork
{
    public class TestBrain
    {

        public static void Test()
        {
            var root = @"C:\Users\philippe\Desktop\Data\Titanic";
            var xTrain = Importer.ImportCsv(System.IO.Path.Combine(root, "xTrain.csv"));
            var yTrain = Importer.ImportCsv(System.IO.Path.Combine(root, "yTrain.csv"));
            var xTest = Importer.ImportCsv(System.IO.Path.Combine(root, "xTest.csv"));
            var brain = new Brain(xTrain, yTrain, xTest,                 
                xColTypesDic: new Dictionary<int, ColumnType>
                {
                    { 0, ColumnType.Id }, // id
                    { 1, ColumnType.Categorical }, // class
                    { 2, ColumnType.Ignore }, // title
                    //{3,ColumnType.Ignore},//sex
                    //{4,ColumnType.Ignore},//sib
                    //{5,ColumnType.Ignore},//parch
                    { 6, ColumnType.Ignore }, // ticket
                    { 7, ColumnType.Ignore }, // fare
                    //{ 8, ColumnType.Ignore },// cabin
                    //{ 9, ColumnType.Ignore }, // embarkment
                    //{ 10, ColumnType.Ignore }, // age
                    { 11, ColumnType.Ignore },// ageMissing
                    //{ 12, ColumnType.Ignore }, // ageStatus
                    {13,ColumnType.Ignore}// familySize
                },
                minY: MinY.Zero,serializer:new Serializer(root+"\\Brain.xml"));          
            brain.SetHiddenLayers(4);            
            brain.SetMaxIterations(200);
            brain.SetRegularization(0.03F);

            brain.SetLearningRate(0.8F);
            brain.SetLearningRateDecay(0.01F, 100);            
            
            //brain.Evaluate();
            brain.EvaluateRegularization();
            var deb = ArrayExtensions.Time;
            var nbCpu = ArrayExtensions.nbCpu;
            var nbGpu = ArrayExtensions.nbGpu;
            brain.Train();
            
            var preds=brain.Predict();
            Exporter.ExportCsv(root + "\\yTest.csv", preds);
           
            var retBrain = Importer.ReadObject<Brain>(root + "\\Brain.xml");
            preds=retBrain.Predict(xTest);
            Exporter.ExportCsv(root + "\\yTest2.csv", preds);
            // missing+200,{4;2}, 8000, 0.08F => 82.9% val but only 77.03% test
            // missing+200, {4}, 800, 0.08F => 81.9% val but only 77.03% test
            // missing+200+ignore sex and fare, 800, 0.08F => 81.7% val but only 79.43% test
            // missing+200+ignore sex and fare and sib and parch, 800, 0.08F => 81.3% val but only 78.47% test
            // missing+200+ignore sex and fare and sib, 800, 0.08F => 83.05% val but only 77.03% test
            // missing+200+ignore sex and fare and parch, 800, 0.08F => 82.15% val but only 75.12% test
            // missing+200+ignore sex and fare, 1200, 0.08F => 82.49% val but only 78.47% test 
            // missing+200+,{8}, 800, 0.3F, 0.8F class,title,sib,parch,ticket,cabin,embarkment,age200,ageMissing => 81.9% val and 80.38% test
            // missing+200+,{16}, 800, 0.3F, 0.8F class,title,sib,parch,ticket,cabin,embarkment,age200,ageMissing => 83% val and x% test
            // missing+200+,{8}, 800, 0.3F, 0.8F class,title,sib,parch,ticket,cabin,embarkment,age29.2,ageMissing => x% test
 
        }

    }
}
