﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class TestPerformance
    {
        protected static bool Check(float[,] res,float a,float b,float c, float d,float e)
        {
            var result = res[0, 0] == a && res[0,1] == b && res[1, 0] == c && res[1, 1] == d && res[res.GetLength(0)-1,res.GetLength(1)-1] == e;
            return result;
        }

        public static void Test()
        {
            float[,] res;
            var m = 2;
            var n = 15;
            var o =2;
            var a=new float[m,n];
            var b = new float[n, o];
            a[0, 0] = 1F; a[0, 1] = 2F; a[1, 0] = 3F; a[m - 1, n - 1] = 3F; a[1, 1] = 8F;
            b[0, 0] = 4F; b[0, 1] = 5F; b[1, 0] = 6F; b[n - 1, o - 1] = 1F;
            for (var i = 0; i < m; i++) for (var j = 0; j< n; j++) a[i, j] = i ;
            for (var i = 0; i < n; i++) for (var j = 0; j <o; j++) b[i, j] =1;
            var cpu = new CpuMatrix();
            var gpu = new GpuMatrix();
            var watch = new Stopwatch();


            Console.WriteLine("CPU Subtract");
            watch.Start();
            res = cpu.Subtract(a, a);
            watch.Stop();
            Console.WriteLine("Run Time: {0:#,#} ms", watch.ElapsedMilliseconds);
            Console.WriteLine("Correct: {0}", Check(res, 0, 0, 0, 0, 0));
            Console.WriteLine("");
            watch.Reset();

    

            Console.WriteLine("GPU Subtract");
            watch.Start();
            res = gpu.Subtract(a, a);
            watch.Stop();
            Console.WriteLine("Run Time: {0:#,#} ms", watch.ElapsedMilliseconds);
            Console.WriteLine("Correct: {0}", Check(res, 0,0,0,0,0));
            Console.WriteLine("");
            watch.Reset();


            Console.WriteLine("CPU Multiply");
            watch.Start();
            var resCpu = cpu.Multiply(a, b);
            watch.Stop();
            Console.WriteLine("Run Time: {0:#,#} ms", watch.ElapsedMilliseconds);
            Console.WriteLine("Correct: {0}", Check(res, 16, 5, 12, 15, 3));
            Console.WriteLine("");
            watch.Reset();

            Console.WriteLine("GPU Multiply");
            watch.Start();
            var resGpu = gpu.Multiply(a, b);
            watch.Stop();
            Console.WriteLine("Run Time: {0:#,#} ms", watch.ElapsedMilliseconds);
            Console.WriteLine("Correct: {0}", Check(res, 16, 5, 12, 15, 3));
            Console.WriteLine("");
            watch.Reset();

            if (!resCpu.IsEqual(resGpu)) throw new Exception("not equal");

        }
    }
}
