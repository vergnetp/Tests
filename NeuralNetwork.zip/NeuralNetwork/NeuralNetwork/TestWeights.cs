﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class TestWeights
    {

        public static void Test()
        {
            var x = new string[,]
            {
                {"18","3","0","t1"},
                {"25","2","1","t2"},
                {"4","1","0","t3"},
                {"56","1","1","t3"},
                {"34","2","0","t4"},
                {"2","3","0","t5"},
                {"2","1","1","t6"},
                {"40","3","0","t5"},
                {"18","3","0","t7"},
                {"25","2","1","t8"},
                {"4","1","0","t9"},
                {"46","1","1","t9"},
                {"36","2","1","t10"},
                {"2","3","0","t11"},
                {"1","1","1","t12"},
                {"40","3","0","t13"},
                {"18","3","0","t13"},
                {"25","2","1","t14"},
                {"4","1","0","t15"},
                {"26","1","1","t15"},
                {"34","2","0","t16"},
                {"2","2","0","t16"},
                {"120","1","1","t17"},
                {"42","3","1","t13"},
                {"18","3","0","t18"},
                {"15","2","1","t19"},
                {"4","1","0","t20"},
                {"46","1","1","t21"},
                {"36","3","1","t22"},
                {"2","3","0","t22"},
                {"1","1","1","t23"},
                {"30","3","0","t24"}
            };
            var y = new string[,]
            {
                {"0"},{"1"},{"1"},{"1"},{"0"},{"0"},{"0"},{"0"},{"0"},{"1"},{"1"},{"1"},{"0"},{"0"},{"0"},{"0"},
                {"0"},{"1"},{"1"},{"1"},{"0"},{"0"},{"0"},{"0"},{"0"},{"1"},{"1"},{"1"},{"0"},{"0"},{"0"},{"0"}
            };
            var costCalculator = new RegularizedCostCalculator(new CostCalculatorQuadratic(),RegularizationScheme.L2Norm);
            var model = new ModelNeuralNetwork(x.GetLength(1), y.GetLength(1), new int[] { 4 }, costCalculator, new ActivatorTanh());
            var solver = new SolverMomentum(model, null, null);
            var brain=new Brain(x,y,x,new[]{ColumnType.Numeric,ColumnType.Categorical,ColumnType.Binary,ColumnType.Categorical},new[]{ColumnType.Binary},solver:solver);
            brain.SetMaxIterations(1000);
            brain.SetRegularization(0.0F);
            brain.Evaluate(2);

        }

    }
}
