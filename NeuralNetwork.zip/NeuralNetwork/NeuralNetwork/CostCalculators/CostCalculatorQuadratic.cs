﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace NeuralNetwork
{
    [DataContract]
    public class CostCalculatorQuadratic : ICostCalculator
    {

        public float Cost(float[,] predictions, float[,] Y)
        {
            // todo check lengths
            // todo optimize?
            var m = Y.GetLength(0);
            var diff = predictions.Subtract(Y);
            var squaredDiff = diff.Apply(x => x * x);
            var cost = squaredDiff.Sum() / ((float)2.0F * m);
            return cost;
        }

        public float[,] CostDerivate(float[,] predictions, float[,] Y)
        {
            return predictions.Subtract(Y);
        }

    }
}
