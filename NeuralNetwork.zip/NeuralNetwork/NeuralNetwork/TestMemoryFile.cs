﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class TestMemoryFile
    {
        public static void Test()
        {
            var logger = new LoggerConsole();
            logger.LogInfo("Start");
            var array = new float[10, 10];
            array[1, 0] = 4.0F;
            array[1,1]=-3.4F;
            array[2, 0] = 20F;
            int colorSize = Marshal.SizeOf(typeof(float));
            using (var mmf = MemoryMappedFile.CreateFromFile(@"c:\temp\ExtremelyLargeImage.data", FileMode.OpenOrCreate, "test",colorSize*array.Length))
            {
                var length = colorSize*array.Length;
                var offset = 0;// length * 1;
                using (var accessor = mmf.CreateViewAccessor(offset, length))
                {


                    var index = 0;
                    for (var i = 0; i < array.GetLength(0); i++)
                    {
                        for (var j = 0; j < array.GetLength(1); j++)
                        {

                            accessor.Write(index, ref array[i, j]);
                            index += colorSize;

                        }
                    }
                }

                length = colorSize*array.GetLength(1);
                offset =  length * 1;
                using (var accessor = mmf.CreateViewAccessor(offset, length))
                {


                    var index = 0;
                   
                    var row = new float[array.GetLength(1)];
                    for (var i = 0; i < 1; i++)
                    {
                        for (var j = 0; j < array.GetLength(1); j++)
                        {
                            
                            accessor.Read(index, out row[j]);
                            index += colorSize;
                        }
                    }
                      
                        
                }
            }


            logger.LogInfo("End");
        }

    }
}
