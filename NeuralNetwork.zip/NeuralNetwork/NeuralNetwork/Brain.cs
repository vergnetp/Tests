﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{

    public enum MissingData
    {
        RemoveAllLines,
        ReplaceByAverageAndNa
    }

    public enum SolverBy
    {
        GradientDescent,
        GradientDescentAndMomemtum
    }

    public enum Model
    {
        NeuralNetwork
    }

    public static class BrainExtensions
    {

        public static void SetHiddenLayers(this Brain brain, params int[] hiddenLayerSizes)
        {
            var newModel = brain.Model as ModelNeuralNetwork;
            newModel.ModelParameters.HiddenLayerSizes = hiddenLayerSizes;
            newModel.ResetWeights(newModel.ModelParameters.NbFeatures,newModel.ModelParameters.NbClasses);
        }

        //public static void ChangeHiddenLayers(this Brain brain,int[] hiddenLayerSizes)
        //{
        //    var newModel = brain.Model as ModelNeuralNetwork;
        //    newModel.ModelParameters.HiddenLayerSizes = hiddenLayerSizes;
        //    newModel.Initialize();
        //}
    }

    public class Brain
    {
        public IMissingDataHandler MissingDataHandler;
        public ISolver Solver;
        public IModel Model;
        public IDataNormalizer DataNormalizer;
        public ILogger Logger;

        protected float[,] _XTrainInitial;
        protected float[,] _YTrainInitial;
        protected float[,] _XTestInitial;

        public Brain(string[,] xTrain, string[,] yTrain, string[,] xTest,
                    Dictionary<int,ColumnType> xColTypesDic=null,
                    Dictionary<int, ColumnType> yColTypesDic=null,
                    MinY minY = MinY.MinusOne,
                    IDataNormalizer dataNormalizer = null,
                    IMissingDataHandler missingDataHandler = null,
                    IModel model = null,
                    ISolver solver = null,
                    ILogger logger=null)
        {
            var xColTypes =  NeuralNetwork.DataNormalizer.GetColTypes(xTrain);
            var yColTypes =  NeuralNetwork.DataNormalizer.GetColTypes(yTrain);
            if (xColTypesDic != null)
            {
                foreach (var key in xColTypesDic.Keys)
                {
                    var index = key;
                    var type = xColTypesDic[key];
                    xColTypes[index] = type;
                }
            }
            if (yColTypesDic != null)
            {
                foreach (var key in yColTypesDic.Keys)
                {
                    var index = key;
                    var type = yColTypesDic[key];
                    yColTypes[index] = type;
                }
            }
            Initialize(xTrain, yTrain, xTest, xColTypes, yColTypes, minY, dataNormalizer, missingDataHandler, model, solver,logger);
        }


        public Brain(string[,] xTrain, string[,] yTrain, string[,] xTest,
                    ColumnType[] xColTypes = null,
                    ColumnType[] yColTypes = null,
                    MinY minY = MinY.MinusOne,
                    IDataNormalizer dataNormalizer = null,
                    IMissingDataHandler missingDataHandler = null,
                    IModel model = null,
                    ISolver solver = null,
                    ILogger logger = null)
        {
            Initialize(xTrain, yTrain, xTest, xColTypes, yColTypes, minY, dataNormalizer, missingDataHandler, model, solver,logger);
        }

        protected string[,] _XTrain;
        protected string[,] _YTrain;
        protected string[,] _XTest;

        protected void Initialize(string[,] xTrain,string[,] yTrain,string[,] xTest,
                                ColumnType[] xColTypes=null,
                                ColumnType[] yColTypes=null,
                                MinY minY=MinY.MinusOne,
                                IDataNormalizer dataNormalizer = null,
                                IMissingDataHandler missingDataHandler = null,
                                IModel model = null, 
                                ISolver solver = null,
                                ILogger logger = null)
        {
            _XTrain = xTrain; _YTrain = yTrain; _XTest = xTest;
            Logger = logger ?? new LoggerConsole();
            xColTypes=xColTypes??NeuralNetwork.DataNormalizer.GetColTypes(xTrain);
            yColTypes =yColTypes?? NeuralNetwork.DataNormalizer.GetColTypes(yTrain); 
            string[,] xTrainComplete, yTrainComplete, xTestComplete;
            this.MissingDataHandler = missingDataHandler ?? new MissingDataAverageAndNA();
            this.MissingDataHandler.Handle(xTrain, yTrain, xTest, xColTypes, yColTypes,out xTrainComplete,out yTrainComplete,out xTestComplete);

            this.DataNormalizer = dataNormalizer ?? new DataNormalizer(minY);
            _XTrainInitial = this.DataNormalizer.EncodeXTrain(xTrainComplete,xColTypes);            
            _YTrainInitial = this.DataNormalizer.EncodeYTrain(yTrainComplete,yColTypes);
            _XTestInitial = this.DataNormalizer.EncodeXTest(xTestComplete,xColTypes);

            var m = _XTrainInitial.GetLength(0);            
            var nbFeatures = _XTrainInitial.GetLength(1);
            var nbClasses = _YTrainInitial.GetLength(1);
                       
            IActivator activator = null;
            activator=new ActivatorTanh();
            ICostCalculator costCalculator= null;
            costCalculator = new CostCalculatorQuadratic();
            if (minY == MinY.Zero)
            {
                activator = new ActivatorSigmoid();
                costCalculator = new CostCalculatorLogistic();
            }
            this.Model = model == null ? (solver != null && solver.Model!=null ?solver.Model:
                new ModelNeuralNetwork(
                    nbFeatures,
                    nbClasses,                    
                    hiddenLayerSizes:new[]{8},
                    costCalculator:new RegularizedCostCalculator(costCalculator,RegularizationScheme.L2Norm),
                    activator: activator))
                :model;
            var maxIterations = m * nbFeatures;
            var myswitch = new Dictionary <Func<int,bool>, int>
            { 
             { x => x < 1000 ,    10000 },  
             { x => x < 5000 ,    1000 },
             { x => x < 10000 ,    400 },
             { x => x < 20000 ,  100 } ,
             { x => x < 100000000 ,  30}             
            };
            maxIterations = myswitch.First(sw => sw.Key(maxIterations)).Value;// todo momentum below
            this.Solver = solver==null?new SolverGradientDescent(Model,this.MissingDataHandler,this.DataNormalizer,maxIterations):solver;     
            this.Solver.DataNormalizer = this.Solver.DataNormalizer??this.DataNormalizer;
            this.Solver.MissingDataHandler = this.Solver.MissingDataHandler ?? this.MissingDataHandler;
            
        }

        public void Train(int reportStride=100)
        {
            Solver.EpochCompleted += (s, e) => 
            {
                var solver = s as ISolver;
                if (solver.LastIteration % reportStride == 0)
                {                   
                    Logger.LogInfo("Epoch nb. {0}", solver.LastIteration);
                    var trainPredictionsProgress = solver.Model.Predict(_XTrainInitial);
                    var lastCostProgress = solver.Model.CostCalculator.Cost(trainPredictionsProgress, _YTrainInitial, solver.Model.Weights);
                    Logger.LogInfo("Cost: {0}", lastCostProgress);
                   
                }
            };
            var converged=Solver.Fit(_XTrainInitial, _YTrainInitial);
            Logger.LogInfo("-----------------------------");
            Logger.LogInfo("Last Epoch: {0}", Solver.LastIteration);
            Logger.LogInfo("Converged: {0}", converged);
            var trainPredictions = Solver.Model.Predict(_XTrainInitial);
            var lastCost= Solver.Model.CostCalculator.Cost(trainPredictions, _YTrainInitial, Solver.Model.Weights);
            Logger.LogInfo("Last cost: {0}", lastCost);
        }

        protected float _InitialLearningRate;
        public void SetLearningRateDecay(float decayRate=0.2F,int decayStride=100,float minLearningRate=0.001F)
        {
            _InitialLearningRate = Solver.LearningRate;
            Solver.EpochCompleted += (s, e) =>
            {
                var solver = s as ISolver;
                if (solver.LastIteration == 0)
                {
                    Solver.LearningRate = _InitialLearningRate;
                    Logger.LogInfo("Initial Learning Rate: {0}", Solver.LearningRate);
                }
                if (solver.LastIteration % decayStride == 0 && solver.LastIteration>0)
                {
                    var newRate = solver.LearningRate * Math.Max((1-decayRate),minLearningRate);
                    SetLearningRate(newRate);
                    Logger.LogInfo("Learning Rate at iteration {0}: {1}", solver.LastIteration.ToString().PadLeft(6,' '),newRate);
                }
            };
        }

        public string[,] Predict()
        {
            var yTestFloat=Model.Predict(_XTestInitial);
            var result=this.DataNormalizer.DecodeY(yTestFloat);
            return result;
        }

        public void Evaluate(int nbSamples=5)
        {
            var currentSample=0;
            Solver.ResetCalled += (s, e) =>
            {
                currentSample++;
                Logger.LogInfo("Sample Nb. {0}", currentSample);                  
            };            
            var modelEvaluator = new ModelSelectorCrossValidation(nbSamples);
            var evaluation=modelEvaluator.EvaluateModels(_XTrain, _YTrain, new List<ISolver> { Solver }).First();
            Logger.LogInfo("Average Training Cost: {0}", evaluation.Statistics.TrainCost);
            Logger.LogInfo("Average Training Accuracy: {0}", evaluation.Statistics.TrainAccuracy);
            Logger.LogInfo("Average Validation Cost: {0}", evaluation.Statistics.ValCost);
            Logger.LogInfo("Average Validation Accuracy: {0}", evaluation.Statistics.ValAccuracy);
        }

        public void EvaluateRegularization(int nbSamples = 5, float[] regularizations=null)
        {
            var currentSample = 0;
            Solver.ResetCalled += (s, e) =>
            {
                currentSample++;
                var solver = s as ISolver;
                Logger.LogInfo("Sample Nb. {0} (regularization: {1})", currentSample, solver.Model.CostCalculator.RegularizationBudget);
                var trainPredictionsProgress = solver.Model.Predict(_XTrainInitial);
                var lastCostProgress = solver.Model.CostCalculator.Cost(trainPredictionsProgress, _YTrainInitial,solver.Model.Weights);
                Logger.LogInfo("Cost: {0}", lastCostProgress);
            };            
            var modelEvaluator = new ModelSelectorCrossValidation(nbSamples);
            regularizations =regularizations?? new[] {0.0F, 0.01F, 0.03F, 0.1F, 0.3F, 1F };
            var evaluations = modelEvaluator.EvaluateRegularization(_XTrain, _YTrain, Solver, regularizations);
            for (var i = 0; i < evaluations.Count; i++)
            {
                var evaluation = evaluations[i];
                var regularization=regularizations[i];
                Logger.LogInfo("-------------------------------");
                Logger.LogInfo("Regularization budget: {0}", regularization);
                Logger.LogInfo("Average Training Cost: {0}", evaluation.Statistics.TrainCost);
                Logger.LogInfo("Average Training Accuracy: {0}", evaluation.Statistics.TrainAccuracy);
                Logger.LogInfo("Average Validation Cost: {0}", evaluation.Statistics.ValCost);
                Logger.LogInfo("Average Validation Accuracy: {0}", evaluation.Statistics.ValAccuracy);
            }
        }

        public void SetRegularization(float penalty) { Model.CostCalculator.RegularizationBudget = penalty; }
        public void SetMaxIterations(int maxIterations) { Solver.MaxIterations = maxIterations; }
        public void SetLearningRate(float rate) { Solver.LearningRate = rate; }

        

    }
}
