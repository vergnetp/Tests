﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace NeuralNetwork
{

    public enum MissingData
    {
        RemoveAllLines,
        ReplaceByAverageAndNa
    }

    public enum SolverBy
    {
        GradientDescent,
        GradientDescentAndMomemtum
    }

    public enum Model
    {
        NeuralNetwork
    }

    public static class BrainExtensions
    {

        public static void SetHiddenLayers(this Brain brain, params int[] hiddenLayerSizes)
        {
            var newModel = brain.Model as ModelNeuralNetwork;
            newModel.ModelParameters.HiddenLayerSizes = hiddenLayerSizes;
            newModel.ResetWeights(newModel.ModelParameters.NbFeatures, newModel.ModelParameters.NbClasses);
        }

        //public static void ChangeHiddenLayers(this Brain brain,int[] hiddenLayerSizes)
        //{
        //    var newModel = brain.Model as ModelNeuralNetwork;
        //    newModel.ModelParameters.HiddenLayerSizes = hiddenLayerSizes;
        //    newModel.Initialize();
        //}
    }

    [DataContract]
    public class Brain
    {
        [DataMember]
        public IMissingDataHandler MissingDataHandler;
        [DataMember]
        public ISolver Solver;
        [DataMember]
        public IModel Model; // todo: already in Solver??
        [DataMember]
        public IDataNormalizer DataNormalizer;// todo: already in Solver?

        public ILogger Logger;
        public Serializer Serializer;
     
        public Brain(string[,] xTrain, string[,] yTrain, string[,] xTest,
                    Dictionary<int, ColumnType> xColTypesDic = null,
                    Dictionary<int, ColumnType> yColTypesDic = null,
                    MinY minY = MinY.MinusOne,
                    IDataNormalizer dataNormalizer = null,
                    IMissingDataHandler missingDataHandler = null,
                    IModel model = null,
                    ISolver solver = null,
                    ILogger logger = null,
                    Serializer serializer=null)
        {            
            var xColTypes = NeuralNetwork.DataNormalizer.GetColTypes(xTrain);
            var yColTypes = NeuralNetwork.DataNormalizer.GetColTypes(yTrain);
            if (xColTypesDic != null)
            {
                foreach (var key in xColTypesDic.Keys)
                {
                    var index = key;
                    var type = xColTypesDic[key];
                    xColTypes[index] = type;
                }
            }
            if (yColTypesDic != null)
            {
                foreach (var key in yColTypesDic.Keys)
                {
                    var index = key;
                    var type = yColTypesDic[key];
                    yColTypes[index] = type;
                }
            }
            Initialize(xTrain, yTrain, xTest, xColTypes, yColTypes, minY, dataNormalizer, missingDataHandler, model, solver, logger);
        }


        public Brain(string[,] xTrain, string[,] yTrain, string[,] xTest,
                    ColumnType[] xColTypes = null,
                    ColumnType[] yColTypes = null,
                    MinY minY = MinY.MinusOne,
                    IDataNormalizer dataNormalizer = null,
                    IMissingDataHandler missingDataHandler = null,
                    IModel model = null,
                    ISolver solver = null,
                    ILogger logger = null,
                    Serializer serializer = null)
        {
            Initialize(xTrain, yTrain, xTest, xColTypes, yColTypes, minY, dataNormalizer, missingDataHandler, model, solver, logger);
        }

        protected string[,] _XTrainString;
        protected string[,] _YTrainString;
        protected string[,] _XTestString;
        protected float[,] _XTrainFloat;
        protected float[,] _YTrainFloat;
        protected float[,] _XTestFloat;

        protected void Initialize(string[,] xTrain, string[,] yTrain, string[,] xTest,
                                ColumnType[] xColTypes = null,
                                ColumnType[] yColTypes = null,
                                MinY minY = MinY.MinusOne,
                                IDataNormalizer dataNormalizer = null,
                                IMissingDataHandler missingDataHandler = null,
                                IModel model = null,
                                ISolver solver = null,
                                ILogger logger = null,
                                Serializer serializer=null)
        {
            Serializer = serializer ?? new Serializer(@"C:\temp\Brain.xml");
            _XTrainString = xTrain; _YTrainString = yTrain; _XTestString = xTest;
            Logger = logger ?? new LoggerConsole();
            xColTypes = xColTypes ?? NeuralNetwork.DataNormalizer.GetColTypes(xTrain);
            yColTypes = yColTypes ?? NeuralNetwork.DataNormalizer.GetColTypes(yTrain);
            string[,] xTrainComplete, yTrainComplete, xTestComplete;
            this.MissingDataHandler = missingDataHandler ?? new MissingDataAverageAndNA();
            this.MissingDataHandler.Handle(xTrain, yTrain, xTest, xColTypes, yColTypes, out xTrainComplete, out yTrainComplete, out xTestComplete);

            this.DataNormalizer = dataNormalizer ?? new DataNormalizer(minY, xColTypes, yColTypes);
            _XTrainFloat = this.DataNormalizer.EncodeXTrain(xTrainComplete);
            _YTrainFloat = this.DataNormalizer.EncodeYTrain(yTrainComplete);
            _XTestFloat = this.DataNormalizer.EncodeXTest(xTestComplete);

            var m = _XTrainFloat.GetLength(0);
            var nbFeatures = _XTrainFloat.GetLength(1);
            var nbClasses = _YTrainFloat.GetLength(1);

            IActivator activator = null;
            activator = new ActivatorTanh();
            ICostCalculator costCalculator = null;
            costCalculator = new CostCalculatorQuadratic();
            if (minY == MinY.Zero)
            {
                activator = new ActivatorSigmoid();
                costCalculator = new CostCalculatorLogistic();
            }
            this.Model = model == null ? (solver != null && solver.Model != null ? solver.Model :
                new ModelNeuralNetwork(
                    nbFeatures,
                    nbClasses,
                    hiddenLayerSizes: new[] { 8 },
                    costCalculator: new RegularizedCostCalculator(costCalculator, RegularizationScheme.L2Norm),
                    activator: activator))
                : model;
            var maxIterations = m * nbFeatures;
            var myswitch = new Dictionary<Func<int, bool>, int>
            { 
             { x => x < 1000 ,    10000 },  
             { x => x < 5000 ,    1000 },
             { x => x < 10000 ,    400 },
             { x => x < 20000 ,  100 } ,
             { x => x < 100000000 ,  30}             
            };
            maxIterations = myswitch.First(sw => sw.Key(maxIterations)).Value;// todo momentum below
            this.Solver = solver == null ? new SolverGradientDescent(Model, this.MissingDataHandler, this.DataNormalizer, maxIterations) : solver;
            this.Solver.DataNormalizer = this.Solver.DataNormalizer ?? this.DataNormalizer;
            this.Solver.MissingDataHandler = this.Solver.MissingDataHandler ?? this.MissingDataHandler;

        }

        public void Train(int reportStride = 100)
        {
            this.Model.ResetWeights(_XTrainFloat.GetLength(1), _YTrainFloat.GetLength(1));
            var assessor = new AccuracyAssessor();
            float accuracy;
            string[,] predString;
            EventHandler epochCompleted = (s, e) =>
            {
                var solver = s as ISolver;
                if (solver.LastIteration % reportStride == 0)
                {                  
                    Logger.LogInfo("Epoch nb. {0}", solver.LastIteration);
                    var trainPredictionsProgress = solver.Model.Predict(_XTrainFloat);
                    var lastCostProgress = solver.Model.CostCalculator.Cost(trainPredictionsProgress, _YTrainFloat, solver.Model.Weights);
                    predString = this.DataNormalizer.DecodeY(trainPredictionsProgress);
                    accuracy=assessor.AssessAccuracy(predString,_YTrainString,this.DataNormalizer.YColTypes);
                    Logger.LogInfo("   Cost: {0}", lastCostProgress);
                    Logger.LogInfo("   Accuracy: {0:P}",accuracy);
                    Serializer.Serialize(this);
                }
            };
            Solver.EpochCompleted += epochCompleted;
            var converged = Solver.Fit(_XTrainFloat, _YTrainFloat);
            Logger.LogInfo("----------Training Done-------------");
            Logger.LogInfo("Last Epoch: {0}", Solver.LastIteration);
            Logger.LogInfo("Converged: {0}", converged);
            var trainPredictions = Solver.Model.Predict(_XTrainFloat);
            var lastCost = Solver.Model.CostCalculator.Cost(trainPredictions, _YTrainFloat, Solver.Model.Weights);
            Logger.LogInfo("Last cost: {0}", lastCost);
            predString = this.DataNormalizer.DecodeY(trainPredictions);
            accuracy = assessor.AssessAccuracy(predString, _YTrainString, this.DataNormalizer.YColTypes);
            Logger.LogInfo("Last Accuracy: {0:P}", accuracy);
            Logger.LogInfo("------------------------------------");
            Solver.EpochCompleted -= epochCompleted;
            Serializer.Serialize(this);
        }

        protected float _InitialLearningRate;
        public void SetLearningRateDecay(float decayRate = 0.2F, int decayStride = 100, float minLearningRate = 0.001F)
        {
            _InitialLearningRate = Solver.LearningRate;
            Solver.EpochCompleted += (s, e) =>
            {
                var solver = s as ISolver;
                if (solver.LastIteration == 0)
                {
                    Solver.LearningRate = _InitialLearningRate;
                    //Logger.LogInfo("Initial Learning Rate: {0}", Solver.LearningRate);
                }
                if (solver.LastIteration % decayStride == 0 && solver.LastIteration > 0)
                {
                    var newRate = solver.LearningRate * Math.Max((1 - decayRate), minLearningRate);
                    SetLearningRate(newRate);
                    //Logger.LogInfo("Learning Rate at iteration {0}: {1}", solver.LastIteration.ToString().PadLeft(6, ' '), newRate);
                }
            };
        }

        public string[,] Predict()
        {
            var yTestFloat = Model.Predict(_XTestFloat);
            var result = this.DataNormalizer.DecodeY(yTestFloat);
            return result;
        }

        public string[,] Predict(string[,] X)
        {
            var encodedX=this.Solver.DataNormalizer.EncodeXTest(X);
            var yTestFloat = Model.Predict(encodedX);
            var result = this.DataNormalizer.DecodeY(yTestFloat);
            return result;
        }

        public void Evaluate(int nbSamples = 5,int reportStride=100)
        {
            var currentSample = 0;
            var assessor = new AccuracyAssessor();
            EventHandler resetCalled = (s, e) =>
            {
                currentSample++;
                Logger.LogInfo("Sample Nb. {0}", currentSample);
            };
            EventHandler epochCompleted = (s, e) =>
            {
                if (Solver.LastIteration % reportStride == 0)
                {
                    var xTrainFloat = Solver.DataNormalizer.EncodeXTest(_XTrainString);// Might be different from _XTrainFloat
                    var yTrainFloat = Solver.DataNormalizer.EncodeYVal(_YTrainString);// Might be different from _YTrainFloat
                    var initialPredictions = Solver.Model.Predict(xTrainFloat);
                    var initialCost = Solver.Model.CostCalculator.Cost(initialPredictions, yTrainFloat, Solver.Model.Weights);
                    var initialPredictionsString = this.DataNormalizer.DecodeY(initialPredictions);
                    var initialAccuracy = assessor.AssessAccuracy(initialPredictionsString, _YTrainString, this.DataNormalizer.YColTypes);
                    Logger.LogInfo("Epoch nb. {0}", Solver.LastIteration);
                    Logger.LogInfo("   Total Data Cost: {0}", initialCost);
                    Logger.LogInfo("   Total Data Accuracy: {0:P}", initialAccuracy);
                    Serializer.Serialize(this);
                }
            };
            Solver.EpochCompleted+=epochCompleted;
            var modelEvaluator = new ModelSelectorCrossValidation(nbSamples);
            var evaluation = modelEvaluator.EvaluateModels(_XTrainString, _YTrainString, new List<ISolver> { Solver }).First();
            Logger.LogInfo("------------Cross Validation-------------");
            Logger.LogInfo("Average Training Cost: {0}", evaluation.Statistics.TrainCost);
            Logger.LogInfo("Average Training Accuracy: {0}", evaluation.Statistics.TrainAccuracy);
            Logger.LogInfo("Average Validation Cost: {0}", evaluation.Statistics.ValCost);
            Logger.LogInfo("Average Validation Accuracy: {0}", evaluation.Statistics.ValAccuracy);
            Logger.LogInfo("-----------------------------------");
            Solver.EpochCompleted -= epochCompleted;
            Solver.ResetCalled -= resetCalled;
            Serializer.Serialize(this);
        }

        public void EvaluateRegularization(int nbSamples = 5, float[] regularizations = null,int reportStride=100)
        {
            var currentSample = 0;
            var assessor = new AccuracyAssessor();
            
            EventHandler resetCalled = (s, e) =>
            {
                currentSample++;
                var solver = s as ISolver;
                Logger.LogInfo("Sample Nb. {0} (regularization: {1})", currentSample, solver.Model.CostCalculator.RegularizationBudget);
                var xTrainFloat = Solver.DataNormalizer.EncodeXTest(_XTrainString);// Might be different from _XTrainFloat
                var yTrainFloat = Solver.DataNormalizer.EncodeYVal(_YTrainString);// Might be different from _YTrainFloat
                var initialPredictions = Solver.Model.Predict(xTrainFloat);
                var initialCost = Solver.Model.CostCalculator.Cost(initialPredictions, yTrainFloat, Solver.Model.Weights);
                var initialPredictionsString = this.DataNormalizer.DecodeY(initialPredictions);
                var initialAccuracy = assessor.AssessAccuracy(initialPredictionsString, _YTrainString, this.DataNormalizer.YColTypes);
                Logger.LogInfo("   Total Data Cost: {0}", initialCost);
                Logger.LogInfo("   Total Data Accuracy: {0:P}", initialAccuracy);
            };
            Solver.ResetCalled +=resetCalled;            
            var modelEvaluator = new ModelSelectorCrossValidation(nbSamples);
            regularizations = regularizations ?? new[] { 0.0F, 0.01F, 0.03F, 0.1F, 0.3F, 1F };
            var evaluations = modelEvaluator.EvaluateRegularization(_XTrainString, _YTrainString, Solver, regularizations);
            for (var i = 0; i < evaluations.Count; i++)
            {
                var evaluation = evaluations[i];
                var regularization = regularizations[i];
                Logger.LogInfo("-------------------------------");
                Logger.LogInfo("Regularization budget: {0}", regularization);
                Logger.LogInfo("Average Training Cost: {0}", evaluation.Statistics.TrainCost);
                Logger.LogInfo("Average Training Accuracy: {0}", evaluation.Statistics.TrainAccuracy);
                Logger.LogInfo("Average Validation Cost: {0}", evaluation.Statistics.ValCost);
                Logger.LogInfo("Average Validation Accuracy: {0}", evaluation.Statistics.ValAccuracy);
                Serializer.Serialize(this);
            }          
            Solver.ResetCalled -= resetCalled;
        }

        public void SetRegularization(float penalty) { Model.CostCalculator.RegularizationBudget = penalty; }
        public void SetMaxIterations(int maxIterations) { Solver.MaxIterations = maxIterations; }
        public void SetLearningRate(float rate) { Solver.LearningRate = rate; }


    }
}
