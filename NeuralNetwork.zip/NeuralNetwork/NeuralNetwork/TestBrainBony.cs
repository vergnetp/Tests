﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class TestBrainBony
    {

        public static void Test()
        {
            var root = @"C:\Users\UK800386\Desktop\";
            var xTrain = Importer.ImportCsv(System.IO.Path.Combine(root, "xTrainBony.csv"));
            var yTrain = Importer.ImportCsv(System.IO.Path.Combine(root, "yTrainBony.csv"));
            var xTest = Importer.ImportCsv(System.IO.Path.Combine(root, "xTrainBony.csv"));
            var brain = new Brain(xTrain, yTrain, xTest, new Dictionary<int,ColumnType>(),               
                minY: MinY.Zero);
            brain.SetHiddenLayers(8);
            brain.SetMaxIterations(400);
            brain.SetLearningRate(0.8F);
            //brain.SetLearningRateDecay(0.01F, 100);
            brain.SetRegularization(0.00F);
            brain.Evaluate(2);
            var deb = ArrayExtensions.Time;
            var nbCpu = ArrayExtensions.nbCpu;
            var nbGpu = ArrayExtensions.nbGpu;
            brain.Train();
            var preds = brain.Predict();
            Exporter.ExportCsv(root + "\\yTest.csv", preds);
        }

    }
}
