﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class Serializer
    {
        public string Path { get; set; }
        public Serializer(string path) { Path = path; }
        public void Serialize(object ob) { Exporter.WriteObject(Path, ob); }
        public T DeSerialize<T>() { return Importer.ReadObject<T>(Path); }
    }
}
