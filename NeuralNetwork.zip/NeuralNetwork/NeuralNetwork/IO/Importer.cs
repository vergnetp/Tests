﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace NeuralNetwork
{
    public class Importer
    {
        public static T ReadObject<T>(string fileName)
        {            
            FileStream fs = new FileStream(fileName,
            FileMode.Open);
            XmlDictionaryReader reader = XmlDictionaryReader.CreateTextReader(fs, new XmlDictionaryReaderQuotas());
            NetDataContractSerializer ser = new NetDataContractSerializer();
            T ob = (T)ser.ReadObject(reader, true);
            fs.Close();
            return ob;
        }


        public static int GetCsvNbColumns(string path)
        {
            var parser = new CsvReader(new StreamReader(path));
            var header = parser.FieldHeaders;
            var nbColumns = header.Length;
            return nbColumns;
        }

        public static float[,] ImportCsvAsFloat(string path, bool hasHeader = true, long offset = 0, long size = long.MaxValue)
        {
            var headerOffset = hasHeader ? 1 : 0;
            var parser = new CsvReader(new StreamReader(path));
            var nbRows = 0L;
            using (StreamReader sr = new StreamReader(path))
            {
                while (sr.ReadLine() != null)
                    nbRows++;
            }
            nbRows -= headerOffset;

            size = Math.Min(nbRows - offset, size);

            if (nbRows <= offset + headerOffset) return null;

            parser.Read();
            var header = parser.FieldHeaders;
            var nbColumns = header.Length;
            var res = new float[size, nbColumns];

            // offset:
            while ((parser.Row - 2) != offset && parser.Read()) { }

            // populate result:
            var i = 0; string[] cells;
            if (offset == 0 && !hasHeader)
            {
                cells = header;
                for (var j = 0; j < nbColumns; j++)
                    res[i, j] = Convert.ToSingle(cells[j]);
                i++;
            }
            if (i < res.GetLength(0))
            {
                cells = parser.CurrentRecord;
                for (var j = 0; j < nbColumns; j++)
                    res[i, j] = Convert.ToSingle(cells[j]);
                i++;
            }
            while (parser.Read() && i < res.GetLength(0))
            {
                cells = parser.CurrentRecord;
                for (var j = 0; j < nbColumns; j++)
                    res[i, j] = Convert.ToSingle(cells[j]);
                i++;
            }
            return res;
        }





        /// <summary>
        /// Return the csv, or part of it, in a string[,].
        /// Exclude the header if any.
        /// Return null if no data to return.
        /// </summary>
        /// <param name="path">csv filename</param>
        /// <param name="hasHeader">does the csv has a header?</param>
        /// <param name="offset">header excluded (0 is always the first line with data)</param>
        /// <param name="size">How many rows to return</param>
        /// <returns></returns>
        public static string[,] ImportCsv(string path, bool hasHeader = true,long offset=0,long size=long.MaxValue)
        {
            var headerOffset = hasHeader ? 1 : 0;
            var parser = new CsvReader(new StreamReader(path));           
            var nbRows = 0L;
            using (StreamReader sr = new StreamReader(path))
            {
                while (sr.ReadLine()!=null)
                    nbRows++;
            }
            nbRows -= headerOffset;

            size = Math.Min(nbRows-offset, size);

            if (nbRows <= offset + headerOffset) return null;

            parser.Read(); 
            var header=parser.FieldHeaders;                
            var nbColumns = header.Length;
            var res = new string[size, nbColumns];

            // offset:
            while ((parser.Row-2) != offset && parser.Read()) { }

            // populate result:
            var i = 0;string[] cells;
            if(offset==0 && !hasHeader)
            {
                cells =header;
                for (var j = 0; j < nbColumns; j++)
                    res[i, j] = (cells[j]);
                i++;   
            }
            if (i < res.GetLength(0))
            {
                cells = parser.CurrentRecord;
                for (var j = 0; j < nbColumns; j++)
                    res[i, j] = (cells[j]);
                i++;
            }
            while (parser.Read() && i<res.GetLength(0))
            {
                cells=parser.CurrentRecord;               
                for (var j = 0; j < nbColumns; j++)
                    res[i , j] = (cells[j]);
                i++;
            }                         
            return res;
        }




        public static float[,] ImportFromMemoryFile(string path,long offset,long nbRows,long nbColumns)
        {
            var array = new float[nbRows, nbColumns];
            ImportFromMemoryFile(path, offset, ref array);
            return array;
        }

        public static void ImportFromMemoryFile(string path, long offset, ref float[,] array)
        {
            var nbRows = array.GetLength(0);var nbColumns = array.GetLength(1);
            var floatSize = sizeof(float);
            using (var mmf = MemoryMappedFile.CreateFromFile(path, FileMode.OpenOrCreate, "ReadArray", floatSize * nbRows * nbColumns))
            {
                var length = floatSize * array.Length;
                using (var accessor = mmf.CreateViewAccessor(offset, length))
                {
                    var index = 0;
                    for (var i = 0; i < nbRows; i++)
                    {
                        for (var j = 0; j < nbColumns; j++)
                        {
                            accessor.Read(index, out array[i, j]);
                            index += floatSize;
                        }
                    }
                }
            }           
        }



         public static float[,] ImportFromMemoryFile(string path,  long nbColumns)
        {          
            var floatSize = sizeof(float);
            using (var mmf = MemoryMappedFile.CreateFromFile(path, FileMode.OpenOrCreate, "ReadArray"))
            {
                using (var accessor = mmf.CreateViewAccessor(0,0,MemoryMappedFileAccess.Read))
                {
                    var nbRows = accessor.Capacity / nbColumns/floatSize;
                    var array = new float[nbRows, nbColumns];
                    var index = 0;
                    for (var i = 0; i < nbRows; i++)
                    {
                        for (var j = 0; j < nbColumns; j++)
                        {
                            accessor.Read(index, out array[i, j]);
                            index += floatSize;
                        }
                    }
                    return array;
                }                
            }            
        }

    }
}
