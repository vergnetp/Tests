﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class Importer
    {

        public static float[,] ImportCsvAsFloat(string path,bool hasHeader=true)
        {
            var offset = hasHeader ? 1 : 0;
            var lines=System.IO.File.ReadAllLines(path);
            var nbRows=lines.Length;
            var header = lines[0].Split(',');
            var nbColumns = header.Length;            
            var res = new float[nbRows-offset, nbColumns];
            Parallel.For(offset, nbRows, i =>
                {
                    var row = lines[i];
                    var cells = row.Split(',');
                    for (var j = 0; j < nbColumns;j++ )
                        res[i-1, j] = Convert.ToSingle(cells[j]);
                });
            return res;
        }

        public static string[,] ImportCsv(string path, bool hasHeader = true)
        {
            var offset = hasHeader ? 1 : 0;
            var parser = new CsvReader(new StreamReader(path));
            var lines = System.IO.File.ReadAllLines(path);
            var nbRows = lines.Length;
            parser.Read();
            var deb=parser.Row;
            var header=parser.FieldHeaders;                
            var nbColumns = header.Length;
            var res = new string[nbRows - offset, nbColumns];
            var i = 0;
            if (!hasHeader)
            {
                for (var j = 0; j < nbColumns; j++)
                    res[i, j] = (header[j]);
                i++;
            }
            var cells = parser.CurrentRecord;
            for (var j = 0; j < nbColumns; j++)
                res[i, j] = (cells[j]);
            i++;
            while (parser.Read())
            {
                cells=parser.CurrentRecord;               
                for (var j = 0; j < nbColumns; j++)
                    res[i , j] = (cells[j]);
                i++;
            }              
            return res;
        }

    }
}
