﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace NeuralNetwork
{
    public class Exporter
    {

        public static void WriteObject(string fileName, object ob)
        {          
            FileStream fs = new FileStream(fileName, FileMode.Create);
            XmlDictionaryWriter writer = XmlDictionaryWriter.CreateTextWriter(fs);
            NetDataContractSerializer ser = new NetDataContractSerializer();
            ser.WriteObject(writer, ob);
            writer.Close();
        }
       
        public static void ExportCsv(string path,float[,] data)
        {
            var nbRows = data.GetLength(0);
            var nbColumns = data.GetLength(1);
            var sb=new StringBuilder();
            for (var i = 0; i < nbRows; i++)
                {
                    for (var j = 0; j < nbColumns; j++)
                    {
                        sb.Append(data[i, j]);
                        if (j < nbColumns - 1)
                        { sb.Append(","); }
                        else { sb.Append("\n"); }
                    }
                }
            System.IO.File.WriteAllText(path,sb.ToString()); 
        }

        public static void ExportCsv(string path, long offset,float[,] data)
        {
            var nbRows = data.GetLength(0);
            var nbColumns = data.GetLength(1);
            var sb = new StringBuilder();
            for (var i = 0; i < nbRows; i++)
            {
                for (var j = 0; j < nbColumns; j++)
                {
                    sb.Append(data[i, j]);
                    if (j < nbColumns - 1)
                    { sb.Append(","); }
                    else { sb.Append("\n"); }
                }
            }
            System.IO.File.AppendAllText(path, sb.ToString());            
        }


        public static void ExportCsv(string path, string[,] data)
        {
            var nbRows = data.GetLength(0);
            var nbColumns = data.GetLength(1);
            var sb = new StringBuilder();
            for (var i = 0; i < nbRows; i++)
            {
                for (var j = 0; j < nbColumns; j++)
                {
                    sb.Append(data[i, j]);
                    if (j < nbColumns - 1)
                    { sb.Append(","); }
                    else { sb.Append("\n"); }
                }
            }            
            System.IO.File.AppendAllText(path, sb.ToString());
        }

        public static void ExportToMemoryFile(string path, long offset, float[,] data)
        {
            var nbRows = data.GetLength(0);
            var nbColumns = data.GetLength(1);
            var floatSize = sizeof(float);
            var capacity = floatSize * nbRows * nbColumns;
            if (capacity>0)
            {
                using (var mmf = MemoryMappedFile.CreateFromFile(path, FileMode.OpenOrCreate, "ReadArray", capacity))
                {
                    var length = floatSize * data.Length;
                    using (var accessor = mmf.CreateViewAccessor(offset, length,MemoryMappedFileAccess.Write))
                    {
                        var index = 0;
                        for (var i = 0; i < nbRows; i++)
                        {
                            for (var j = 0; j < nbColumns; j++)
                            {
                                accessor.Write(index, ref data[i, j]);
                                index += floatSize;
                            }
                        }
                    }
                }
            }           
        }

    }
}
