﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class Brain2
    {

        public Brain2()
        {
            Solver.Logger = Logger;
            Solver.Model = new ModelNeuralNetwork();
            Solver.MaxIterations = 10;
        }

        public Solver Solver=new SolverGradientDescent();
        public DataGateway DataGateway=new DataGateway(null,null);
        public ILogger Logger=new LoggerConsole();
        protected string ROOT = @"C:\temp";
        protected int KFOLD = 2;

        public bool Train(string csvPath,int[] outputColumns,MinY minY=MinY.MinusOne)
        {
            DataGateway.PrepareTrain(csvPath, outputColumns,root: ROOT, minY:minY);
            var xTrainPath = Path.Combine(ROOT, "X.csv");
            var yTrainPath = Path.Combine(ROOT, "Y.csv");         
            var converged=Solver.Fit(xTrainPath, yTrainPath, 0, long.MaxValue);
            return converged;
        }

        public void Predict(string csvPath, int[] outputColumns, MinY minY = MinY.MinusOne)
        {
            DataGateway.PrepareTest(csvPath, outputColumns, root: ROOT, minY: minY);
            var xTestPath = Path.Combine(ROOT, "XTest.csv");
            var yPredPath = Path.Combine(ROOT, "YPred.csv");
            Solver.Predict(xTestPath, yPredPath, 0, long.MaxValue);    
        }

        public void CrossValidate(string csvPath, int[] outputColumns, MinY minY = MinY.MinusOne)
        {
            // todo: more than 2 KFOLD
            // todo: prevent <=1 KFOLD
            var nbRows = Importer.GetCsvNbRows(csvPath, true);
            var nbRowsInValData = nbRows / KFOLD;
            var nbRowsInTrainData = nbRows - nbRowsInValData;
            var totalCost = 0F;
            var totalAccuracy = 0F;
            for (var k = 0; k < KFOLD; k++)
            {
                Logger.LogInfo("Sample Nb. {0}:", k);
                DataGateway.PrepareTrain(csvPath, outputColumns, offset: k* nbRowsInTrainData, size: nbRowsInTrainData, root: ROOT, xFileName:"XTrain.csv",yFileName:"yTrain.csv",minY: minY);
                var xTrainPath = Path.Combine(ROOT, "XTrain.csv");
                var yTrainPath = Path.Combine(ROOT, "YTrain.csv");
                var converged = Solver.Fit(xTrainPath, yTrainPath, 0, long.MaxValue);
                var valOffset = (k) * nbRowsInTrainData;
                if (valOffset > nbRows - 1) valOffset = 0;
                DataGateway.PrepareTest(csvPath, outputColumns, offset: valOffset, root: ROOT, xFileName: "XTest.csv", yFileName: "yTest.csv",minY: minY);
                var xTestPath = Path.Combine(ROOT, "XTest.csv");
                var yTestPath = Path.Combine(ROOT, "YTest.csv");
                var yPredPath = Path.Combine(ROOT, "YPred.csv");
                Solver.Predict(xTestPath, yPredPath, 0,long.MaxValue);    
                var cost = 0; // todo
                var accuracy = 0; // todo
                totalCost += cost;
                totalAccuracy += accuracy;
                Logger.LogInfo("Cost: {0}", cost);
                Logger.LogInfo("Accuracy: {0:P}", accuracy);
            }
            var averageCost = totalCost / KFOLD;
            var averageAccuracy = totalAccuracy / KFOLD;
            Logger.LogInfo("Average cost: {0}", averageCost);
            Logger.LogInfo("Average accuracy: {0:P}", averageAccuracy);
        }




    }
}
