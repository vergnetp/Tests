﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class SolvableModel
    {
        public IModel Model { get; set; }
        public ISolver Solver { get; set; }
    }


    
}
