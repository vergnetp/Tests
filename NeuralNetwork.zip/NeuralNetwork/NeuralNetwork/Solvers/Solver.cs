﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace NeuralNetwork
{
    [DataContract]
    public abstract class Solver : ISolver
    {

        #region Members

        [DataMember]
        public IModel Model { get; set; }
        [DataMember]
        public IMissingDataHandler MissingDataHandler { get; set; }
        [DataMember]
        public IDataNormalizer DataNormalizer { get; set; }

        [DataMember]
        public float LearningRate { get; set; }

        [DataMember]
        public int MaxIterations { get; set; }

        [DataMember]
        public float ConvergenceThreshold { get; set; }

        protected int _CurrentIteration;
        [DataMember]
        public int LastIteration
        {
            get { return _CurrentIteration; }
            protected set { _CurrentIteration = value; }
        }

        public ILogger Logger;

        public event EventHandler EpochCompleted;

        public event EventHandler ResetCalled;

        #endregion

        #region Ctor

        protected Solver() { }

        public Solver(IModel model=null, IMissingDataHandler missingDataHandler=null,
        IDataNormalizer dataNormalizer=null, int maxIterations = 1000, float convergenceThreashold = 0.01F, float learningRate = 0.5F,MinY minY=MinY.MinusOne,ILogger logger=null)
        {
            Logger = logger ?? new LoggerConsole();
            Model = model ?? new ModelNeuralNetwork(); 
            MaxIterations = maxIterations;
            ConvergenceThreshold = convergenceThreashold;
            Model = model;           
            if (minY == MinY.MinusOne && this.Model.GetType() == typeof(ModelNeuralNetwork) && ((ModelNeuralNetwork)this.Model).Activator.GetType() ==typeof(ActivatorSigmoid))
            {
                ((ModelNeuralNetwork)this.Model).Activator = new ActivatorTanh();
                Logger.LogInfo("The Neural Network Transfer function has been replaced by Tanh one to be able to reach negative values in the predictions.");
            }
            if (missingDataHandler==null) Logger.LogInfo("Missing Data will be replaced by the average of the existing numerical values, and by 'NA' for categorical columns.");
            MissingDataHandler = missingDataHandler?? new MissingDataAverageAndNA();
            DataNormalizer = dataNormalizer??new DataNormalizer(minY:minY);
            LearningRate = learningRate;
        }

        #endregion

        #region Solve

        public bool Fit(string[,] XTrain, string[,] YTrain)
        {
            string[,] xTrainComplete=null;
            string[,] xTestComplete = null;
            string[,] yTrainComplete = null;
            
            this.MissingDataHandler.Handle(XTrain,YTrain,null, this.DataNormalizer.XColTypes,this.DataNormalizer.YColTypes,out xTrainComplete,out yTrainComplete,out xTestComplete);            
            var xTrainFloat = this.DataNormalizer.EncodeXTrain(xTrainComplete);
            var yTrainFloat = this.DataNormalizer.EncodeYTrain(yTrainComplete);
            var converged = Fit(xTrainFloat, yTrainFloat);
            return converged;
        }

        public bool Fit(string xStringFilename,string yStringFilename,long ooffset, long osize)
        {
            // Handle missing data and create new csv, x and y. Get column types as well
            var xCompleteStringFilename = "";
            var yCompleteStringFilename = "";
            ColumnType[] xColTypes = null;
            ColumnType[] yColTypes = null;

            var offset = 0;
            var nbRows = 1000;
            var xTrainString = Importer.ImportCsv(xCompleteStringFilename, true, offset, nbRows);
            var yTrainString = Importer.ImportCsv(yCompleteStringFilename, true, offset, nbRows);
            // update distinct values
            while (xTrainString != null)
            {
                offset += nbRows;
                xTrainString = Importer.ImportCsv(xCompleteStringFilename, true, offset, nbRows);
                yTrainString = Importer.ImportCsv(yCompleteStringFilename, true, offset, nbRows);
                // update distinct values
            }
            // if null, get col types, x and y

            offset = 0;
            nbRows = 1000;
            xTrainString = Importer.ImportCsv(xCompleteStringFilename, true, offset, nbRows);
            yTrainString = Importer.ImportCsv(yCompleteStringFilename, true, offset, nbRows);
            // encode x and y:
            float[,] xTrainFloat=null;
            float[,] yTrainFloat=null;
            // append to memory mapped file:
            var xTrainFloatFilename = "";
            var yTrainFloatFilename = "";
            Exporter.ExportToMemoryFile(xTrainFloatFilename, offset, xTrainFloat);
            Exporter.ExportToMemoryFile(yTrainFloatFilename, offset, yTrainFloat);
            while (xTrainString != null)
            {
                offset += nbRows;
                xTrainString = Importer.ImportCsv(xCompleteStringFilename, true, offset, nbRows);
                yTrainString = Importer.ImportCsv(yCompleteStringFilename, true, offset, nbRows);
                // encode x and y:

                // append to memory mapped file:
                Exporter.ExportToMemoryFile(xTrainFloatFilename, offset, xTrainFloat);
                Exporter.ExportToMemoryFile(yTrainFloatFilename, offset, yTrainFloat);
            }
            var converged = true;// Fit(xTrainFloatFilename, yTrainFloatFilename);
            return converged;
        }

        public bool Fit(float[,] XTrain, float[,] YTrain)
        {
            var m = XTrain.GetLength(0);
            var nbFeatures = XTrain.GetLength(1);
            var nbClasses = YTrain.GetLength(1);
            var nbRowsInMiniBatch = 1000 * 100 / nbFeatures;
            var nbMiniBatch = (int)Math.Ceiling((float)m / nbRowsInMiniBatch);
            Logger.LogInfo("Stochastic learning: {0} mini batches will be run per epoch.", nbMiniBatch);
            if (nbClasses!=this.Model.Parameters.NbClasses)
            {
                Logger.LogInfo("The model will be reset to be able to deal with a diferrent number of classes ({0} instead of {1} previously)", nbClasses, this.Model.Parameters.NbClasses);
                this.Model.ResetWeights(nbFeatures, nbClasses);
                _CurrentIteration = 0;
            }
            if (nbFeatures != this.Model.Parameters.NbFeatures)
            {
                Logger.LogInfo("The model will be reset to be able to deal with a diferrent number of features ({0} instead of {1} previously)", nbFeatures, this.Model.Parameters.NbFeatures);
                this.Model.ResetWeights(nbFeatures, nbClasses);
                _CurrentIteration = 0;
            }
            var counter = 0;
            var converged = false;
            while (counter < MaxIterations && !converged)
            {
                var oldWeights = Model.Weights;
                var partition = MatrixUtility.KPartition(XTrain, YTrain, nbMiniBatch);
                foreach (var part in partition)
                {
                    var subX = part.Item1;
                    var subY = part.Item2;
                    UpdateModelWeights(subX, subY);
                }
                // Check convergence 
                var newWeights = Model.Weights;
                if (newWeights.Length == oldWeights.Length)
                {
                    var distance = newWeights.Distance(oldWeights);
                    converged = distance < this.ConvergenceThreshold;
                }
                // Raise EpochEvent
                if (this.EpochCompleted != null)
                {
                    EpochCompleted(this, EventArgs.Empty);
                }
                counter++;
                _CurrentIteration++;
            }
            Logger.LogInfo("Training stopped after {0} epochs (Total epochs since model reset: {1}).", counter,_CurrentIteration);
            Logger.LogInfo("Converged: {0} (weights are still {1:0.000} apart)");
            return converged;
        }

        public async Task<bool> FitAsync(float[,] XTrain, float[,] YTrain)
        {
            var res = await Task<bool>.Run(() => this.Fit(XTrain, YTrain));
            return res;
        }

        public float[] Solution
        {
            get { return Model.Weights; }
        }

        public abstract void UpdateModelWeights(float[,] XTrain, float[,] YTrain);

        #endregion

        #region Tools

        public ISolver Clone()
        {
            var solver = Activator.CreateInstance(this.GetType()) as ISolver;
            solver.Model = this.Model.Clone();
            solver.MissingDataHandler = this.MissingDataHandler;
            solver.DataNormalizer = this.DataNormalizer;
            solver.MaxIterations = this.MaxIterations;
            solver.LearningRate = this.LearningRate;
            solver.ConvergenceThreshold = this.ConvergenceThreshold;
            solver.ResetCalled += this.ResetCalled;
            solver.EpochCompleted += this.EpochCompleted;
            return solver;
        }

        public void Reset()
        {
            // todo: do we reset model as well?
            LastIteration = 0;
            // Raise event
            if (this.ResetCalled != null)
            {
                ResetCalled(this, EventArgs.Empty);
            }
        }

        #endregion

        #region Checks

        public bool CheckGradient(float[,] XTrain, float[,] YTrain)
        {
            var XExtract = Accord.Math.Matrix.Submatrix(XTrain, new int[] { 0, 1, 2, 3, 4 });
            var YExtract = Accord.Math.Matrix.Submatrix(YTrain, new int[] { 0, 1, 2, 3, 4 });
            var tolerance = 0.01F;
            var distance = 0.0F;
            var normPlus = 0.0F;
            var normMinus = 0.0F;
            var backupWeights = new float[Model.Weights.Length];
            backupWeights.CopyInto(Model.Weights);
            //Array.Clear(Model.Weights, 0, Model.Weights.Length);
            var gradientsCalc = Model.GetGradients(XExtract, YExtract);
            var gradientsNum = GetNumGradient(XExtract, YExtract);
            Model.Weights.CopyInto(backupWeights);
            for (var i = 0; i < gradientsCalc.GetLength(0); i++)
            {
                var gradNum = gradientsNum[i];
                var gradCalc = gradientsCalc[i];
                normMinus += (gradNum - gradCalc) * (gradNum - gradCalc);
                normPlus += (gradNum + gradCalc) * (gradNum + gradCalc);
            }
            normMinus = (float)Math.Pow(normMinus, 0.5);
            normPlus = (float)Math.Pow(normPlus, 0.5);
            distance = normMinus / normPlus;
            return distance < tolerance;
        }

        public float[] GetNumGradient(float[,] X, float[,] Y)
        {
            var res = new float[Model.Weights.Length];
            var epsilon = 0.0001F;
            for (var i = 0; i < res.Length; i++)
            {
                Model.Weights[i] += epsilon;
                var predictionsPlus = Model.Predict(X);
                var bumpPlus = Model.CostCalculator.Cost(predictionsPlus, Y, Model.Weights);
                Model.Weights[i] -= 2.0F * epsilon;
                var predictionsMinus = Model.Predict(X);
                var bumpMinus = Model.CostCalculator.Cost(predictionsMinus, Y, Model.Weights);
                Model.Weights[i] += epsilon;
                var deb = predictionsPlus.ValueEquals(predictionsMinus);
                res[i] = (bumpPlus - bumpMinus) / (2.0F * epsilon);
            }
            return res;
        }

        #endregion

    }
}

