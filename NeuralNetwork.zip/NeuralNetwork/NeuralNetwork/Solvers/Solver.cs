﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace NeuralNetwork
{
    [DataContract]
    public abstract class Solver : ISolver
    {

        #region Members

        [DataMember]
        public IModel Model { get; set; }
        [DataMember]
        public IMissingDataHandler MissingDataHandler { get; set; }
        [DataMember]
        public IDataNormalizer DataNormalizer { get; set; }

        [DataMember]
        public float LearningRate { get; set; }

        [DataMember]
        public int MaxIterations { get; set; }

        [DataMember]
        public float ConvergenceThreshold { get; set; }

        protected int _CurrentIteration;
        [DataMember]
        public int LastIteration
        {
            get { return _CurrentIteration; }
            protected set { _CurrentIteration = value; }
        }

        public event EventHandler EpochCompleted;

        public event EventHandler ResetCalled;

        #endregion

        #region Ctor

        protected Solver() { }

        public Solver(IModel model, IMissingDataHandler missingDataHandler,
        IDataNormalizer datNormalizer, int maxIterations = 1000, float convergenceThreashold = 0.01F, float learningRate = 0.5F)
        {
            MaxIterations = maxIterations;
            ConvergenceThreshold = convergenceThreashold;
            Model = model;
            MissingDataHandler = missingDataHandler;
            DataNormalizer = datNormalizer;
            LearningRate = learningRate;
        }

        #endregion

        #region Solve

        public bool Fit(float[,] XTrain, float[,] YTrain)
        {
            var nbMiniBatch = 1; // todo: revert to 10
            if (XTrain.GetLength(0) < 100) nbMiniBatch = 1;
            if (XTrain.GetLength(0) > 10000) nbMiniBatch = 20;
            var counter = 0;
            var converged = false;
            while (counter < MaxIterations && !converged)
            {
                var oldWeights = Model.Weights;
                var partition = MatrixUtility.KPartition(XTrain, YTrain, nbMiniBatch);
                foreach (var part in partition)
                {
                    var subX = part.Item1;
                    var subY = part.Item2;
                    UpdateModelWeights(subX, subY);
                }
                // Check convergence 
                var newWeights = Model.Weights;
                if (newWeights.Length == oldWeights.Length)
                {
                    var distance = newWeights.Distance(oldWeights);
                    converged = distance < this.ConvergenceThreshold;
                }
                // Raise EpochEvent
                if (this.EpochCompleted != null)
                {
                    EpochCompleted(this, EventArgs.Empty);
                }
                counter++;
                _CurrentIteration++;
            }
            return converged;
        }

        public async Task<bool> FitAsync(float[,] XTrain, float[,] YTrain)
        {
            var res = await Task<bool>.Run(() => this.Fit(XTrain, YTrain));
            return res;
        }

        public float[] Solution
        {
            get { return Model.Weights; }
        }

        public abstract void UpdateModelWeights(float[,] XTrain, float[,] YTrain);

        #endregion

        #region Tools

        public ISolver Clone()
        {
            var solver = Activator.CreateInstance(this.GetType()) as ISolver;
            solver.Model = this.Model.Clone();
            solver.MissingDataHandler = this.MissingDataHandler;
            solver.DataNormalizer = this.DataNormalizer;
            solver.MaxIterations = this.MaxIterations;
            solver.LearningRate = this.LearningRate;
            solver.ConvergenceThreshold = this.ConvergenceThreshold;
            solver.ResetCalled += this.ResetCalled;
            solver.EpochCompleted += this.EpochCompleted;
            return solver;
        }

        public void Reset()
        {
            // todo: do we reset model as well?
            LastIteration = 0;
            // Raise event
            if (this.ResetCalled != null)
            {
                ResetCalled(this, EventArgs.Empty);
            }
        }

        #endregion

        #region Checks

        public bool CheckGradient(float[,] XTrain, float[,] YTrain)
        {
            var XExtract = Accord.Math.Matrix.Submatrix(XTrain, new int[] { 0, 1, 2, 3, 4 });
            var YExtract = Accord.Math.Matrix.Submatrix(YTrain, new int[] { 0, 1, 2, 3, 4 });
            var tolerance = 0.01F;
            var distance = 0.0F;
            var normPlus = 0.0F;
            var normMinus = 0.0F;
            var backupWeights = new float[Model.Weights.Length];
            backupWeights.CopyInto(Model.Weights);
            //Array.Clear(Model.Weights, 0, Model.Weights.Length);
            var gradientsCalc = Model.GetGradients(XExtract, YExtract);
            var gradientsNum = GetNumGradient(XExtract, YExtract);
            Model.Weights.CopyInto(backupWeights);
            for (var i = 0; i < gradientsCalc.GetLength(0); i++)
            {
                var gradNum = gradientsNum[i];
                var gradCalc = gradientsCalc[i];
                normMinus += (gradNum - gradCalc) * (gradNum - gradCalc);
                normPlus += (gradNum + gradCalc) * (gradNum + gradCalc);
            }
            normMinus = (float)Math.Pow(normMinus, 0.5);
            normPlus = (float)Math.Pow(normPlus, 0.5);
            distance = normMinus / normPlus;
            return distance < tolerance;
        }

        public float[] GetNumGradient(float[,] X, float[,] Y)
        {
            var res = new float[Model.Weights.Length];
            var epsilon = 0.0001F;
            for (var i = 0; i < res.Length; i++)
            {
                Model.Weights[i] += epsilon;
                var predictionsPlus = Model.Predict(X);
                var bumpPlus = Model.CostCalculator.Cost(predictionsPlus, Y, Model.Weights);
                Model.Weights[i] -= 2.0F * epsilon;
                var predictionsMinus = Model.Predict(X);
                var bumpMinus = Model.CostCalculator.Cost(predictionsMinus, Y, Model.Weights);
                Model.Weights[i] += epsilon;
                var deb = predictionsPlus.ValueEquals(predictionsMinus);
                res[i] = (bumpPlus - bumpMinus) / (2.0F * epsilon);
            }
            return res;
        }

        #endregion

    }
}

