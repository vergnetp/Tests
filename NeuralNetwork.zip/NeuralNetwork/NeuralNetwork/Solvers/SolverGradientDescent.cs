﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class SolverGradientDescent:Solver
    {

        public SolverGradientDescent() { }

        public SolverGradientDescent(IModel model,IMissingDataHandler missingDataHandler,IDataNormalizer dataNormalizer, int maxIterations = 1000, float convergenceThreashold = 0.0001F, float learningRate = 0.5F)
            : base(model,missingDataHandler,dataNormalizer, maxIterations, convergenceThreashold, learningRate)
        {
        }             

        public override void UpdateModelWeights(float[,] XTrain,float[,] YTrain)
        {
            var gradient = Model.GetGradients(XTrain, YTrain);
            Model.Weights = Model.Weights.Select((value, index) => value - gradient[index] * LearningRate).ToArray();
       }
       
    }
}
