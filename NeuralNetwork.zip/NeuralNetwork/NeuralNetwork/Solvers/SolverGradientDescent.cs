﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace NeuralNetwork
{
    [DataContract]
    public class SolverGradientDescent : Solver
    {

        public SolverGradientDescent() { }

        public SolverGradientDescent(IModel model = null, IMissingDataHandler missingDataHandler = null,
        IDataNormalizer dataNormalizer = null, int maxIterations = 1000, float convergenceThreashold = 0.01F, float learningRate = 0.5F, MinY minY = MinY.MinusOne, ILogger logger = null)        
            : base(model, missingDataHandler, dataNormalizer, maxIterations, convergenceThreashold, learningRate,minY,logger)
        {
        }

        public override void UpdateModelWeights(float[,] XTrain, float[,] YTrain)
        {
            var gradient = Model.GetGradients(XTrain, YTrain);
            Model.Weights = Model.Weights.Select((value, index) => value - gradient[index] * LearningRate).ToArray();
        }

    }
}
