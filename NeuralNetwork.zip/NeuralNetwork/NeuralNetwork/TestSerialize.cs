﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.IO;
using System.Xml;

namespace NeuralNetwork
{
    public static class TestSerialize
    {
        [DataContract]
        private class House
        {
            [DataMember]
            public string Name { get; set; }
        }

        private interface IPlayer
        {
            int Decibel { get; set; }
        }

        [DataContract]
        private class Player : IPlayer
        {
            [DataMember]
            public int Decibel { get; set; }
        }

        [DataContract]
        private class Person
        {
            public Person()
            {
                _Weights = new float[2] { 1, 2 } ;
                _Persons = new Dictionary<int, House>();
                _Persons[10] = new House() { Name = "Bob" };
                _Persons[20] = new House() { Name = "Phil" } ;
                _Player = new Player() { Decibel = 120 };
            }
            public void Age() { _Age++; }
            public string Name { get; set; }
            [DataMember]
            private int _Age;
            [DataMember]
            private float[] _Weights;
            [DataMember]
            private Dictionary<int,House> _Persons;
            [DataMember]
            private IPlayer _Player;
        }
        public static void Test()
        {
            var p = new Person();
            p.Age();p.Age();p.Age();
            WriteObject(@"C:\Users\UK800386\Desktop\Person.xml", p);
            var retP = ReadObject<Person>(@"C:\Users\UK800386\Desktop\Person.xml");
            var nw = new ModelNeuralNetwork(3, 1, new[] { 4 }, new RegularizedCostCalculator(new CostCalculatorQuadratic()), new ActivatorSigmoid());
            WriteObject(@"C:\Users\UK800386\Desktop\Network.xml", nw);
            var retNw = ReadObject<ModelNeuralNetwork>(@"C:\Users\UK800386\Desktop\Network.xml");
        }

        public static void WriteObject(string fileName,object ob)
        {
            Console.WriteLine("Creating a Person object and serializing it.");
            FileStream fs = new FileStream(fileName, FileMode.Create);
            XmlDictionaryWriter writer = XmlDictionaryWriter.CreateTextWriter(fs);
            NetDataContractSerializer ser =new NetDataContractSerializer();
            ser.WriteObject(writer, ob);
            writer.Close();
        }

        public static T ReadObject<T>(string fileName)
        {
            Console.WriteLine("Deserializing an instance of the object.");
            FileStream fs = new FileStream(fileName,
            FileMode.Open);
            XmlDictionaryReader reader =  XmlDictionaryReader.CreateTextReader(fs, new XmlDictionaryReaderQuotas());
            NetDataContractSerializer ser = new NetDataContractSerializer();       
            T ob =(T)ser.ReadObject(reader, true);
            fs.Close();
            return ob;           
        }
    }
}
