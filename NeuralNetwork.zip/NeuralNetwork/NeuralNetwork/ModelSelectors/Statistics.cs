﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class Statistics
    {
        /*
        AIC = (n)log(SSE/n)+2p

        BIC = (n)log(SSE/n)+(p)log(n)
         */
        public Statistics(float valCost, float? trainCost = null, float? valAccuracy = null, float? trainAccuracy = null)
        {
            TrainCost = trainCost;
            TrainAccuracy = trainAccuracy;
            ValCost = valCost;
            ValAccuracy = valAccuracy;
        }
        public float? TrainCost;
        public float? TrainAccuracy;
        public float ValCost;
        public float? ValAccuracy;
    }
}
