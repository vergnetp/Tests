﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class LoggerConsole:ILogger
    {
        public void LogInfo(string msg,params object[] args)
        {            
            Console.WriteLine("{0}: {1}",DateTime.UtcNow,string.Format(msg,args));
        }

        public void LogWarning(string msg, params object[] args)
        {
            Console.WriteLine("{0}: {1}", DateTime.UtcNow, string.Format(msg, args));
        }

        public void LogError(string msg, params object[] args)
        {
            Console.WriteLine("{0}: {1}", DateTime.UtcNow, string.Format(msg, args));
        }

        public void LogError(Exception ex)
        {
            Console.WriteLine("{0}: {1}", DateTime.UtcNow, ex.ToString());
        }
    }
}
