﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    class API
    {

        public class DataPreparator
        {
            public List<string>[] DistinctValues;
            public ColumnType[] ColumnTypes;
            public float[] XMeans; public float[] XStdDevs; public float[] XMins; public float[] XMaxs;
            public float[] YMeans; public float[] YStdDevs; public float[] YMins; public float[] YMaxs;

            public string OutputFile;

            /// <summary>
            /// Call that before using training or test data.
            /// This should be called on the training data.
            /// Populate DistinctValues and Coltypes.
            /// Populate the stats (means etc.)
            /// Generate OutputFile, a copy of the targeted subset inputFile except for lines where all value of the dependent variables are null or empty.
            /// </summary>
            /// <param name="outputFile">The complete file name of the output.</param>
            /// <param name="trainingFile">The complete file name of the input. Must be a csv with header.</param>
            /// <param name="dependentColumns">Zero based indices of the dependent variables. Null if none (f.e. on Kaggle test set)</param>
            /// <param name="offset">Zero based start of the subset.</param>
            /// <param name="size">Number of rows in the subset.</param>
            public void Prepare(string outputFile, string trainingFile, int[] dependentColumns, long offset, long size) { OutputFile = outputFile; }
        }

        public abstract class MissingDataHandler
        {

            public string TEMP_FOLDER = @"C:\temp";

            public DataPreparator DataPreparator;

            /// <summary>
            /// Call that before using training data.
            /// Populate DistinctValues and Coltypes.
            /// Generate a copy of inputFile except for lines where all value of the dependent variables are null or empty, and replace partially missing values with relevant values.
            /// </summary>
            /// <param name="outputFile">The complete file name of the output.</param>
            /// <param name="trainingFile">The complete file name of the input. Must be a csv with header.</param>
            /// <param name="dependentColumns">Zero based indices of the dependent variables. Null if none (f.e. on Kaggle test set)</param>
            /// <param name="offset">Zero based start of the subset.</param>
            /// <param name="size">Number of rows in the subset.</param>
            public void HandleTrain(string outputFile, string preparedFile, string trainingFile, int[] dependentColumns, long offset, long size)
            {              
                DataPreparator.Prepare(preparedFile, trainingFile, dependentColumns, offset, size);
                HandleMissingTrain(outputFile, preparedFile, dependentColumns, 0, long.MaxValue);           
            }


            public void HandleTest(string outputFile, string preparedFile, string testFile, int[] dependentColumns, long offset, long size)
            {
               if (DataPreparator.ColumnTypes == null) throw new Exception("Data not prepared. You need to call HandleTrain first");
               HandleMissingTest(outputFile, preparedFile, dependentColumns, offset, size);              
            }

            /// <summary>
            /// Call that before using training data.
            /// Will replace partially missing values with relevant values.
            /// </summary>
            /// <param name="outputFile">The complete file name of the output.</param>
            /// <param name="trainingFile">The complete file name of the input. Must be a csv with header.</param>
            /// <param name="dependentColumns">Zero based indices of the dependent variables. Null if none (f.e. on Kaggle test set)</param>
            /// <param name="offset">Zero based start of the subset.</param>
            /// <param name="size">Number of rows in the subset.</param>
            public abstract void HandleMissingTrain(string outputFile, string trainingFile, int[] dependentColumns, long offset, long size);
            public abstract void HandleMissingTest(string outputFile, string traingFile, int[] dependentColumns, long offset, long size);

        }

        public class MissingDataAverageAndNA : MissingDataHandler
        {
            public MissingDataAverageAndNA(DataPreparator dataPreparator) { DataPreparator = dataPreparator; }
            public override void HandleMissingTest(string outputFile, string traingFile, int[] dependentColumns, long offset, long size) { if (DataPreparator.XMeans == null) throw new Exception("Statistics like means need to be populated before Handling missing data in the training set."); }
            public override void HandleMissingTrain(string outputFile, string trainingFile, int[] dependentColumns, long offset, long size) { if (DataPreparator.ColumnTypes == null) throw new Exception("Columptypes need to be populated before Handling missing data in training set."); }
        }

        public class Encoder
        {
            public string TEMP_FOLDER = @"C:\temp";

            protected MissingDataHandler _MissingDataHandler;
            public Encoder(MissingDataHandler missingDataHandler) { _MissingDataHandler = missingDataHandler; _MissingDataHandler.TEMP_FOLDER = TEMP_FOLDER; }

            public void SetFolder(string rootFolder) { TEMP_FOLDER = rootFolder; }


            public string PreparedTrainDataFile { get { return Path.Combine(TEMP_FOLDER, "PreparedTrainData.csv"); } }//
            public string PreparedTestDataFile { get { return Path.Combine(TEMP_FOLDER, "PreparedTestData.csv"); } }
            public string CompleteTrainDataFile { get { return Path.Combine(TEMP_FOLDER, "CompleteTrainData.csv"); } }//
            public string CompleteTestDataFile { get { return Path.Combine(TEMP_FOLDER, "CompleteTestData.csv"); } }
            public string EncodedXTrainFile;
            public string EncodedYTrainFile;
            public string EncodedXTestFile;            
            public string EncodedYTestFile;
            public string DecodedXTrainFile;
            public string DecodedYTrainFile;
            public string DecodedXTestFile;
            public string DecodedYTestFile;

            public void DeleteTempFiles()
            {
                var files = new[] { PreparedTrainDataFile, CompleteTrainDataFile, CompleteTestDataFile };
                foreach (var f in files) if (File.Exists(f)) File.Delete(f);
            }
            public void DeleteFiles()
            {
                DeleteTempFiles();
                var files = new[] { EncodedXTrainFile, EncodedXTestFile, EncodedYTrainFile, EncodedYTestFile, DecodedXTrainFile, DecodedYTrainFile, DecodedXTestFile, DecodedYTestFile };
                foreach (var f in files) if (File.Exists(f)) File.Delete(f);
            }

            protected void Encode(string encodedXFile, string encodedYFile,string completeFile,string preparedFile, string trainingFile, int[] dependentColumns, long offset, long size)
            {
                _MissingDataHandler.HandleTrain(completeFile, preparedFile, trainingFile, dependentColumns, offset, size);
                var lastRow = offset + size;
                var firstRow = Importer.ImportCsv(trainingFile, false, 0, 1);
                var n = (long)firstRow.GetLength(1);
                var maxSize = 1000 * 1000 / n; // We allow a 64MB array max
                var subSize = Math.Min(size, maxSize);
                var subData = Importer.ImportCsv(trainingFile, false, 0, subSize);
                do
                {
                    float[,] X; float[,] Y;
                    // todo: needs to sets of stats: for X AND Y
                    DataNormalizer.Encode(subData, dependentColumns, _MissingDataHandler.DataPreparator.DistinctValues, _MissingDataHandler.DataPreparator.ColumnTypes, _MissingDataHandler.DataPreparator.XMeans, _MissingDataHandler.DataPreparator.XStdDevs, _MissingDataHandler.DataPreparator.XMaxs, _MissingDataHandler.DataPreparator.XMins, minY, out X, out Y);
                    Exporter.ExportCsv(encodedXFile, offset, X);
                    Exporter.ExportCsv(encodedYFile, offset, Y);
                    offset += subSize;
                    subSize = Math.Min(subSize, lastRow );
                    subData = Importer.ImportCsv(trainingFile, false, 0, subSize);
                } while (subData != null);
            }
            public void EncodeTrain(string encodedXFile, string encodedYFile, string trainingFile, int[] dependentColumns, long offset, long size)
            {
                Encode( encodedXFile,  encodedYFile,  CompleteTrainDataFile,  PreparedTrainDataFile, trainingFile,  dependentColumns, offset, size);
            }
            public void EncodeTest(string encodedXFile, string encodedYFile, string testFile, int[] dependentColumns, long offset, long size)
            {
                Encode( encodedXFile, encodedYFile, CompleteTrainDataFile, PreparedTestDataFile,  testFile, dependentColumns,  offset, size);
            }


            public void DecodeXTrain(string outputFile, string xTrainingFile, long offset, long size)
            {
                var lastRow = offset + size;
                var firstRow = Importer.ImportCsv(xTrainingFile, false, 0, 1);
                var n = (long)firstRow.GetLength(1);
                var maxSize = 1000 * 1000 / n; // We allow a 64MB array max
                var subSize = Math.Min(size, maxSize);
                var subData = Importer.ImportCsvAsFloat(xTrainingFile, false, offset, subSize);
                do
                {
                    var X = DataNormalizer.DecodeX(subData, _MissingDataHandler.DataPreparator.DistinctValues, _MissingDataHandler.DataPreparator.ColumnTypes, _MissingDataHandler.DataPreparator.XMeans, _MissingDataHandler.DataPreparator.XStdDevs);
                    Exporter.ExportCsv(outputFile, X);
                    offset += subSize;
                    subSize = Math.Min(subSize, lastRow - offset);
                    subData = Importer.ImportCsvAsFloat(xTrainingFile, false, offset, subSize);
                } while (subData != null);
            }
            public void DecodeYTrain(string outputFile, string yTrainingFile, long offset, long size) { }
            public void DecodeXTest(string outputFile, string xTestFile, long offset, long size) { }
            public void DecodeYTest(string outputFile, string yTestFile, long offset, long size) { }
            public void DecodeYPred(string outputFile, string yPredFile, long offset, long size) { DecodeYTest(outputFile, yPredFile, offset, size); }
            
        }

        public class Solver
        {
            public void Predict(string encodedPredFile, string encodedXFile,  long offset = 0, long size = long.MaxValue) { }  
            public bool Fit(string encodedXTrainFile, string encodedYTrainFile, long offset, long size) { return true; }
        }

        public class Brain:IDisposable
        {
            Encoder _Encoder;Solver _Solver;

            public Brain(Encoder encoder=null, Solver solver=null)
            {
                _Encoder = encoder??new Encoder(new MissingDataAverageAndNA(new DataPreparator())); _Solver = solver??new SolverGradientDescent();
            }

            public string TEMP_FOLDER = @"C:\temp";
            public void SetFolder(string rootFolder) { TEMP_FOLDER = rootFolder; }

            public string PreparedTrainDataFile { get { return Path.Combine(TEMP_FOLDER, "PreparedTrainData.csv"); } }
            public string PreparedTestDataFile { get { return Path.Combine(TEMP_FOLDER, "PreparedTestData.csv"); } }
            public string CompleteTrainDataFile { get { return Path.Combine(TEMP_FOLDER, "CompleteTrainData.csv"); } }
            public string CompleteTestDataFile { get { return Path.Combine(TEMP_FOLDER, "CompleteTestData.csv"); } }
            public string EncodedXTrainFile { get { return Path.Combine(TEMP_FOLDER, "EncodedXTrainData.csv"); } } //
            public string EncodedYTrainFile { get { return Path.Combine(TEMP_FOLDER, "EncodedYTrainData.csv"); } } //
            public string EncodedXTestFile { get { return Path.Combine(TEMP_FOLDER, "EncodedXTestData.csv"); } } //
            public string EncodedYTestFile { get { return Path.Combine(TEMP_FOLDER, "EncodedYTestData.csv"); } } // null
            public string EncodedYPredFile { get { return Path.Combine(TEMP_FOLDER, "EncodedYPredData.csv"); } } //
            public string DecodedYTrainFile { get { return Path.Combine(TEMP_FOLDER, "DecodedYTrainData.csv"); } } // for training accuracy
            public string DecodedYTestFile { get { return Path.Combine(TEMP_FOLDER, "DecodedYTestData.csv"); } } // for validation accuracy

            public void Predict( string decodedPredFile, string testFile, int[] dependentColumns, long offset = 0, long size = long.MaxValue) {  _Encoder.EncodeTest(EncodedXTestFile,null, testFile, dependentColumns, offset, size); _Solver.Predict(EncodedYPredFile, EncodedXTestFile,0,long.MaxValue); _Encoder.DecodeYPred(decodedPredFile, EncodedYPredFile, 0,long.MaxValue); }
            public bool Fit(string trainingFile, int[] dependentColumns, long offset, long size) {_Encoder.EncodeTrain(EncodedXTrainFile, EncodedYTrainFile, trainingFile,dependentColumns,offset,size); return _Solver.Fit(EncodedXTrainFile, EncodedYTrainFile, 0,long.MaxValue); }

            public void Dispose()
            {
                _Encoder.DeleteFiles();
            }
            ~Brain() { Dispose(); }
        }
    }
}
