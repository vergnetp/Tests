﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class Exporter
    {
        public static void ExportCsv(string path,float[,] data)
        {
            var nbRows = data.GetLength(0);
            var nbColumns = data.GetLength(1);
            var sb=new StringBuilder();
            for (var i = 0; i < nbRows; i++)
                {
                    for (var j = 0; j < nbColumns; j++)
                    {
                        sb.Append(data[i, j]);
                        if (j < nbColumns - 1)
                        { sb.Append(","); }
                        else { sb.Append("\n"); }
                    }
                }
            System.IO.File.WriteAllText(path,sb.ToString());
            

        }

    }
}
