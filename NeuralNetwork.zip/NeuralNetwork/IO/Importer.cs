﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class Importer
    {

        public static float[,] ImportCsvAsFloat(string path)
        {           
            var lines=System.IO.File.ReadAllLines(path);
            var nbRows=lines.Length;
            var header = lines[0].Split(',');
            var nbColumns = header.Length;
            var res = new float[nbRows-1, nbColumns];
            Parallel.For(1, nbRows, i =>
                {
                    var row = lines[i];
                    var cells = row.Split(',');
                    for (var j = 0; j < nbColumns;j++ )
                        res[i-1, j] = Convert.ToSingle(cells[j]);
                });
            return res;
        }

        public static string[,] ImportCsv(string path)
        {
            var lines = System.IO.File.ReadAllLines(path);
            var nbRows = lines.Length;
            var header = lines[0].Split(',');
            var nbColumns = header.Length;
            var res = new string[nbRows - 1, nbColumns];
            Parallel.For(1, nbRows, i =>
            {
                var row = lines[i];
                var cells = row.Split(',');
                for (var j = 0; j < nbColumns; j++)
                    res[i - 1, j] = (cells[j]);
            });
            return res;
        }

    }
}
