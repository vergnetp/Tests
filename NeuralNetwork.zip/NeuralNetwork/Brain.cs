﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{

    public enum MissingData
    {
        RemoveAllLines,
        ReplaceByAverageAndNa
    }

    public enum SolverBy
    {
        GradientDescent,
        GradientDescentAndMomemtum
    }

    public enum Model
    {
        NeuralNetwork
    }

    public class Brain
    {
        public IMissingDataHandler MissingDataHandler;
        public ISolver Solver;
        public IModel Model;
        public IDataNormalizer DataNormalizer;

        protected float[,] _XTrainInitial;
        protected float[,] _YTrainInitial;
        protected float[,] _XTestInitial;

        public Brain(string[,] xTrain,string[,] yTrain,string[,] xTest,
            ColumnType[] xColTypes=null,
            ColumnType[] yColTypes=null,
            MinY minY=MinY.MinusOne,
            IDataNormalizer dataNormalizer = null,
            IMissingDataHandler missingDataHandler = null,
            IModel model = null, 
            ISolver solver = null)
        {
            xColTypes=xColTypes??NeuralNetwork.DataNormalizer.GetColTypes(xTrain);
            yColTypes =yColTypes?? NeuralNetwork.DataNormalizer.GetColTypes(yTrain);            
            string[,] xTrainComplete, yTrainComplete, xTestComplete;
            this.MissingDataHandler = missingDataHandler ?? new MissingDataAverageAndNA();
            this.MissingDataHandler.Handle(xTrain, yTrain, xTest, xColTypes, yColTypes,out xTrainComplete,out yTrainComplete,out xTestComplete);

            this.DataNormalizer = dataNormalizer ?? new DataNormalizer(minY);
            _XTrainInitial = this.DataNormalizer.EncodeXTrain(xTrainComplete);            
            _YTrainInitial = this.DataNormalizer.EncodeYTrain(yTrainComplete);
            _XTestInitial = this.DataNormalizer.EncodeXTest(xTestComplete);

            var m = _XTrainInitial.GetLength(0);            
            var nbFeatures = _XTrainInitial.GetLength(1);
            var nbClasses = _YTrainInitial.GetLength(1);
                       
            IActivator activator = null;
            activator=new ActivatorTanh();
            ICostCalculator costCalculator= null;
            costCalculator = new CostCalculatorQuadratic();
            if (minY == MinY.Zero)
            {
                activator = new ActivatorSigmoid();
                costCalculator = new CostCalculatorLogistic();
            }
              this.Model = model==null?
                new ModelNeuralNetwork(
                    nbFeatures,
                    nbClasses,                    
                    hiddenLayerSizes:new[]{8},
                    costCalculator:new RegularizedCostCalculator(costCalculator,RegularizationScheme.L2Norm),
                    activator: activator)
                :model;
            var maxIterations = m * nbFeatures;
            var myswitch = new Dictionary <Func<int,bool>, int>
            { 
             { x => x < 1000 ,    10000 },  
             { x => x < 5000 ,    1000 },
             { x => x < 10000 ,    400 },
             { x => x < 20000 ,  100 } ,
             { x => x < 100000000 ,  30}             
            };
            maxIterations = myswitch.First(sw => sw.Key(maxIterations)).Value;
            this.Solver = solver==null?new SolverGradientDescent(Model,maxIterations):solver;     
        }

        public void Train(int reportStride=100)
        {
            Solver.EpochCompleted += (s, e) => 
            {
                var solver = s as ISolver;
                if (solver.LastIteration % reportStride == 0)
                {
                    Console.WriteLine("Epoch nb. {0}", solver.LastIteration);
                    var trainPredictionsProgress = solver.Model.Predict(_XTrainInitial);
                    var lastCostProgress = solver.Model.CostCalculator.Cost(trainPredictionsProgress, _YTrainInitial, solver.Model.Weights);
                    Console.WriteLine("Cost: {0}", lastCostProgress);                    
                }
            };
            var converged=Solver.Fit(_XTrainInitial, _YTrainInitial);
            Console.WriteLine("-----------------------------");
            Console.WriteLine("Last Epoch: {0}", Solver.LastIteration);
            Console.WriteLine("Converged: {0}", converged);
            var trainPredictions = Solver.Model.Predict(_XTrainInitial);
            var lastCost= Solver.Model.CostCalculator.Cost(trainPredictions, _YTrainInitial, Solver.Model.Weights);
            Console.WriteLine("Last cost: {0}", lastCost);
        }

        public string[,] Predict()
        {
            var yTestFloat=Model.Predict(_XTestInitial);
            var result=this.DataNormalizer.DecodeY(yTestFloat);
            return result;
        }

        public void Evaluate(int nbSamples=5)
        {
            var currentSample=0;
            Solver.ResetCalled += (s, e) =>
            {
                currentSample++;
                Console.WriteLine("Sample Nb. {0}", currentSample);
                var trainPredictionsProgress = Solver.Model.Predict(_XTrainInitial);
                var lastCostProgress = Solver.Model.CostCalculator.Cost(trainPredictionsProgress, _YTrainInitial, Solver.Model.Weights);
                Console.WriteLine("Cost: {0}", lastCostProgress);   
            };           
            var modelEvaluator = new ModelSelectorCrossValidation(nbSamples);
            var evaluation=modelEvaluator.EvaluateModels(_XTrainInitial, _YTrainInitial, new List<ISolver> { Solver }, DataNormalizer).First();
            Console.WriteLine("Average Training Cost: {0}",evaluation.Statistics.TrainCost);
            Console.WriteLine("Average Training Accuracy: {0}", evaluation.Statistics.TrainAccuracy);
            Console.WriteLine("Average Validation Cost: {0}", evaluation.Statistics.ValCost);
            Console.WriteLine("Average Validation Accuracy: {0}", evaluation.Statistics.ValAccuracy);
        }

        public void EvaluateRegularization(int nbSamples = 5, float[] regularizations=null)
        {
            var currentSample = 0;
            Solver.ResetCalled += (s, e) =>
            {
                currentSample++;
                var solver = s as ISolver;
                Console.WriteLine("Sample Nb. {0} (regularization: {1})", currentSample, solver.Model.CostCalculator.RegularizationBudget);
                var trainPredictionsProgress = solver.Model.Predict(_XTrainInitial);
                var lastCostProgress = solver.Model.CostCalculator.Cost(trainPredictionsProgress, _YTrainInitial,solver.Model.Weights);
                Console.WriteLine("Cost: {0}", lastCostProgress);
            };            
            var modelEvaluator = new ModelSelectorCrossValidation(nbSamples);
            regularizations =regularizations?? new[] {0.0F, 0.01F, 0.03F, 0.1F, 0.3F, 1F };
            var evaluations = modelEvaluator.EvaluateRegularization(_XTrainInitial, _YTrainInitial, Solver, DataNormalizer, regularizations);
            for (var i = 0; i < evaluations.Count; i++)
            {
                var evaluation = evaluations[i];
                var regularization=regularizations[i];
                Console.WriteLine("-------------------------------");
                Console.WriteLine("Regularization budget: {0}", regularization);
                Console.WriteLine("Average Training Cost: {0}", evaluation.Statistics.TrainCost);
                Console.WriteLine("Average Training Accuracy: {0}", evaluation.Statistics.TrainAccuracy);
                Console.WriteLine("Average Validation Cost: {0}", evaluation.Statistics.ValCost);
                Console.WriteLine("Average Validation Accuracy: {0}", evaluation.Statistics.ValAccuracy);
            }
        }

        public void ChangeRegularization(float penalty) { Model.CostCalculator.RegularizationBudget = penalty; }
        public void ChangeMaxIterations(int maxIterations) { Solver.MaxIterations = maxIterations; }
        public void ChangeLearningRate(float rate) { Solver.LearningRate = rate; }


    }
}
