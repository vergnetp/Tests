﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace NeuralNetwork
{
    [DataContract]
    public class CostCalculatorLogistic:ICostCalculator
    {
        public float Cost(float[,] predictions, float[,] Y)
        {
            // todo check length
            // todo pointers
            var m = Y.GetLength(0);
            var n = Y.GetLength(1);
            var tmp = new float[m, n];
            Parallel.For(0, m, i =>
            {
                for (var j = 0; j < n; j++)
                {
                    tmp[i, j] = -Y[i, j] * (float)Math.Log(predictions[i, j]) - (1.0F - Y[i, j]) * (float)Math.Log(1.0F - predictions[i, j]);
                }
            });
            var cost = tmp.Sum() / ((float)m);
            return cost;
        }        

        public float[,] CostDerivate(float[,] predictions, float[,] Y)
        {
            // todo check length
            // todo real function
            return predictions.Apply(Y,(x,y)=>y/x+(1-x)/(1-y));
        }
    
    }
}
