﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace NeuralNetwork
{
    [DataContract]
    public class RegularizedCostCalculator : IRegularizedCostCalculator
    {
        public RegularizedCostCalculator(ICostCalculator costCalculator, RegularizationScheme regularizationScheme = RegularizationScheme.None, float regularizationBudget = 0.0F)
        {
            CostCalculator = costCalculator;
            RegularizationScheme = regularizationScheme;
            RegularizationBudget=regularizationBudget;
        }

        [DataMember]
        public ICostCalculator CostCalculator { get; set; }

        [DataMember]
        public RegularizationScheme RegularizationScheme { get; set; }

        [DataMember]
        public float RegularizationBudget { get; set; }

        public float RegularizationPenalty(float[] weights,int nbSamples)
        {
            switch (RegularizationScheme)
            {
                case global::NeuralNetwork.RegularizationScheme.L1Norm:
                    return weights.Apply(x => Math.Abs(x)).Sum() / nbSamples * RegularizationBudget;
                case global::NeuralNetwork.RegularizationScheme.L2Norm:
                    return weights.Apply(x => (float)Math.Pow(x, 2.0)).Sum() / (2 * nbSamples) * RegularizationBudget;
                default:
                    return 0.0F;
            }
        }

        public float Cost(float[,] predictions, float[,] Y, float[] weights)
        {
            var cost = CostCalculator.Cost(predictions, Y);
            var regularization=RegularizationPenalty(weights,Y.GetLength(0));
            return cost + regularization;
        }

        public IRegularizedCostCalculator Clone()
        {   
            var costCalculator = System.Activator.CreateInstance(this.GetType(),this.CostCalculator,this.RegularizationScheme,this.RegularizationBudget) as IRegularizedCostCalculator;
            return costCalculator;
        }
    }
}
