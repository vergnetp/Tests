﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{    

    public interface ICostCalculator
    {
        float Cost(float[,] predictions, float[,] Y);              

        float[,] CostDerivate(float[,] predictions, float[,] Y);
    }
   
}
