﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace NeuralNetwork
{
    [DataContract]
    public class SolverMomentum:SolverGradientDescent
    {

        [DataMember]
        public float Momentum { get; set; }

        [DataMember]
        protected float[] _PreviousUpdates;

        public  SolverMomentum(IModel model,IMissingDataHandler missingDataHandler,IDataNormalizer dataNormalizer,int maxIterations=1000,float convergenceThreashold=0.0001F,float learningRate=0.5F,float momentum=0.2F):base(model,missingDataHandler,dataNormalizer,maxIterations,convergenceThreashold,learningRate)
        {
            Momentum = momentum;
        }

        public override void UpdateModelWeights(float[,] XTrain, float[,] YTrain)
        {            
            var gradient = Model.GetGradients(XTrain, YTrain);
            if (_PreviousUpdates == null || !Model.Weights.Length.Equals(_PreviousUpdates.Length)) _PreviousUpdates = new float[Model.Weights.Length];
            var oldWeights = Model.Weights;
            Model.Weights = Model.Weights.Select((value, index) => value - gradient[index] * LearningRate-_PreviousUpdates[index]*Momentum).ToArray();
            _PreviousUpdates = Model.Weights.Subtract(oldWeights);    
        }
    }
}
