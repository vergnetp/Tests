﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public interface IAccuracyAssessor
    {

        float AssessAccuracy(string[,] predictions, string[,] Y, ColumnType[] colTypes);
        BitArray[] AssessSuccess(string[,] predictions, string[,] Y, ColumnType[] colTypes);

    }
}
