﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class AccuracyAssessor:IAccuracyAssessor
    {

        public static void Test()
        {
            var Y = new[,] { { "male", "urban", "27" }, { "male", "rural", "59.5" }, { "female", "mid", "15" } };
            var pred = new[,] { { "male", "urban", "30" }, { "male", "rural", "64" }, { "female", "rural", "12" } };
            var accuracy = new AccuracyAssessor().AssessAccuracy(pred, Y, new[] {ColumnType.Binary,ColumnType.Categorical,ColumnType.Numeric });
            Console.WriteLine("Accuracy: {0:P}", accuracy);
        }

        /// <summary>
        /// Require Y and predictions to have been decoded back.
        /// If there are several columnTypes, then  return the average accuracy.
        /// For numerical columns, standardize Y and the precictions (using Y stddev) and return 1-euclidian distance (limited to 0)
        /// </summary>
        /// <param name="predictions"></param>
        /// <param name="Y"></param>
        /// <param name="colTypes"></param>
        /// <param name="minY"></param>
        /// <returns></returns>
        public float AssessAccuracy(string[,] predictions, string[,] Y,ColumnType[] colTypes)
        {
            var m=Y.GetLength(0);
            var o=Y.GetLength(1);
            var accuracies = new float[o];
            for (var j = 0; j < o; j++)
            {
                if (colTypes[j] != ColumnType.Numeric)
                {
                    var nbSuccess = 0.0F;
                    for (var i = 0; i < m; i++)
                    {
                        if (Y[i,j].Equals(predictions[i,j])) { nbSuccess++; }                        
                    }
                    accuracies[j] = nbSuccess / (float)m;
                }
                else
                {
                    var y = 0.0F; var pred=0.0F;
                    var average = 0.0F; var stddev = 0.0F;
                    for (var i = 0; i < m; i++)
                    {
                        y=Convert.ToSingle(Y[i,j]);
                        pred = Convert.ToSingle(predictions[i, j]);
                        average += y;
                    }
                    average /= m;
                    for (var i = 0; i < m; i++)
                    {
                        stddev+=(y - average) * (y - average);
                    }
                    stddev /= (m- 1);
                    stddev = (float)Math.Sqrt(stddev);                    
                    var distance = 0.0F;
                    var scalor = 1.0F / stddev;                   
                    for (var i=0;i<m;i++)
                    {
                        distance += (float)Math.Pow((pred-y)*scalor, 2);                        
                    }                    
                    distance = (float)Math.Sqrt(distance);                   
                    accuracies[j] = Math.Max(0.0F,1.0F - distance);
                }
                
            }
            return accuracies.Average();
        }
    
        
        public BitArray[] AssessSuccess(string[,] predictions, string[,] Y,ColumnType[] colTypes)
        {
            var m=Y.GetLength(0);
            var o=Y.GetLength(1);
            var result=new BitArray[o];
            for (var j = 0; j < o; j++)
            {
                result[j] = new BitArray(m);
                if (colTypes[j] != ColumnType.Numeric)
                {
                    for (var i = 0; i < m; i++)
                    {
                        if (Y[i, j].Equals(predictions[i, j])) { result[j][i] = true; }
                    }
                }
            }
            return result;
        }

    }
}
