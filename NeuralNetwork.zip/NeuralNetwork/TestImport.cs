﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class TestImport
    {
        public static void Test()
        {
            var csvPath = @"C:\Users\philippe\Desktop\";

            // Data preparation:
            var XTrain = Importer.ImportCsvAsFloat(csvPath+@"XTrainTitanic.csv");
            var YTrain = Importer.ImportCsvAsFloat(csvPath + @"YTrainTitanic.csv");
            var XTest = Importer.ImportCsvAsFloat(csvPath + @"XTestTitanic.csv");

            float[,] XVal; float[,] YVal;
            MatrixUtility.ValidationPartition(XTrain, YTrain, 0.99, out XTrain, out YTrain, out XVal, out YVal);
            

            //var normalizer = new DataNormalizerZScore();
            var normalizedXTrain = XTrain;// normalizer.NormalizeXTrain(XTrain);
            var normalizedXVal = XVal;// normalizer.NormalizeXTest(XVal);
            var normalizedXTest = XTest;// normalizer.NormalizeXTest(XTest);

            // Model settings:
            //var accuracyAssessor = new AccuracyAssessorClassification();
            var activator = new ActivatorSigmoid();
            var costCalculator = new CostCalculatorLogistic();
            var regularizedCostCalculator = new RegularizedCostCalculator(costCalculator, RegularizationScheme.L2Norm, 0.01F);
            var network = new ModelNeuralNetwork(normalizedXTrain.GetLength(1), YTrain.GetLength(1), new int[2] {6,3}, regularizedCostCalculator, activator);
            var solver = new SolverMomentum(network, 1000, 0.00001F,0.8F,0.6F);
            solver.EpochCompleted += (o, e) => 
            { 
                var s = o as Solver; 
                if (s.LastIteration % 100 == 0) 
                { Console.WriteLine("Epoch nb {0}:", s.LastIteration);
                var trainPredictionsProgress = solver.Model.Predict(normalizedXTrain);
                var lastCostProgress = solver.Model.CostCalculator.Cost(trainPredictionsProgress, YTrain, solver.Model.Weights);
                Console.WriteLine("Last cost: {0}", lastCostProgress);
                var trainVal = solver.Model.Predict(normalizedXVal);
                var lastCostVal = solver.Model.CostCalculator.Cost(trainVal, YVal, solver.Model.Weights);
                Console.WriteLine("Last Validation cost: {0}", lastCostVal);
                //var valAccuracy = accuracyAssessor.AssessAccuracy(trainVal, YVal);
                //Console.WriteLine("Validation Accuracy: {0:P}", valAccuracy);
                } 
            };

            // Solve:
            var isOk = solver.Fit(normalizedXTrain, YTrain);
            Console.WriteLine("Solver converged: {0}", isOk);

            // Predict:
            var valPredictions = solver.Model.Predict(normalizedXTest);
            Exporter.ExportCsv(csvPath+@"YTestTitanic4.csv",valPredictions);
            var trainPredictions = solver.Model.Predict(normalizedXTrain);

            // Report:
            //var accuracy = accuracyAssessor.AssessAccuracy(trainPredictions, YTrain);
            var lastCost = solver.Model.CostCalculator.Cost(trainPredictions, YTrain, solver.Model.Weights);
            var lastIteration = solver.LastIteration;
            Console.WriteLine("Last iteration: {0}", lastIteration);
            Console.WriteLine("Last cost: {0}", lastCost);
            //Console.WriteLine("Last accuracy: {0:P}", accuracy);            

        }
    }
}
