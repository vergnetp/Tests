﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace NeuralNetwork
{

    /// <summary>
    /// Remove all rows with at least one missing data
    /// </summary>
    [DataContract]
    public class MissingDataRemover
    {

        /// <summary>
        /// Remove all rows with at least one missing data
        /// </summary>
        /// <param name="XTrain"></param>
        /// <param name="YTrain"></param>
        /// <param name="XTest"></param>
        /// <param name="xColTypes">unused</param>
        /// <param name="yColTypes">unused</param>
        /// <param name="XTrainComplete"></param>
        /// <param name="YTrainComplete"></param>
        /// <param name="XTestComplete"></param>
        public void Handle(string[,] XTrain, string[,] YTrain, string[,] XTest, ColumnType[] xColTypes, ColumnType[] yColTypes, out string[,] XTrainComplete, out string[,] YTrainComplete, out string[,] XTestComplete)
        {
            var m = XTrain.GetLength(0);
            var n = XTrain.GetLength(1);
            var o = YTrain.GetLength(1);
            var mt = XTest.GetLength(0);
            var missingIndices = new List<int>();
            for (var i = 0; i < m; i++)
            {
                var isYMissing = false;
                for (var j = 0; j < o; j++)
                {
                    if (string.IsNullOrEmpty(YTrain[i, j]))
                    {
                        missingIndices.Add(i);
                        isYMissing = true;
                        break;
                    }
                }
                if (!isYMissing)
                {
                    for (var j = 0; j < n; j++)
                    {
                        if (string.IsNullOrEmpty(XTrain[i, j]))
                        {
                            missingIndices.Add(i);
                            break;
                        }
                    }
                }
            }
            XTrainComplete = new string[m - missingIndices.Count, n];
            YTrainComplete = new string[m - missingIndices.Count, o];
            int k = 0;
            for (var i = 0; i < m; i++)
            {
                if (!missingIndices.Contains(i))
                {
                    for (var j = 0; j < n; j++)
                        XTrainComplete[k, j] = XTrain[i, j];
                    for (var j = 0; j < o; j++)
                        YTrainComplete[k, j] = YTrain[i, j];
                    k++;
                }

            }
            missingIndices.Clear();
            for (var i = 0; i < mt; i++)
            {
                for (var j = 0; j < n; j++)
                {
                    if (string.IsNullOrEmpty(XTest[i, j]))
                    {
                        missingIndices.Add(i);
                        break;
                    }
                }
            }
            XTestComplete = new string[mt - missingIndices.Count, n];
            k = 0;
            for (var i = 0; i < mt; i++)
            {
                if (!missingIndices.Contains(i))
                {
                    for (var j = 0; j < n; j++)
                        XTestComplete[k, j] = XTest[i, j];
                    k++;
                }

            }
        }
   
    }
}
