﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public interface IMissingDataHandler
    {
        void Handle(string[,] XTrain, string[,] YTrain, string[,] XTest, ColumnType[] xCOlTypes,ColumnType[] yColType,out string[,] XTrainComplete, out string[,] YTrainComplete, out string[,] XTestComplete);
    }
}
