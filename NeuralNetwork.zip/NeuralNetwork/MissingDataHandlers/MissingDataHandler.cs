﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace NeuralNetwork
{

    /// <summary>
    /// Remove all rows with at least one missing data in YTrain.
    /// Remove all empty rows. 
    /// Special logic to handle rows with only a few missing entries in XTrain or XTest is to be implemented in derived class.
    /// </summary>
    [DataContract]
    public abstract class MissingDataHandler:IMissingDataHandler
    {
        public abstract void HandlePartial(string[,] XTrain, string[,] XTest, ColumnType[] xColTypes);

        /// <summary>
        /// Remove all rows with at least one missing data in YTrain.
        /// Remove all empty rows. 
        /// Special logic to handle rows with only a few missing entries in XTrain or XTest is to be implemented in derived class.
        /// </summary>
        public void Handle(string[,] XTrain, string[,] YTrain, string[,] XTest,ColumnType[] xColTypes,ColumnType[] yColTypes, out string[,] XTrainComplete, out string[,] YTrainComplete, out string[,] XTestComplete)
        {
            var m = XTrain.GetLength(0);
            var n = XTrain.GetLength(1);
            var o = YTrain.GetLength(1);
            var mt = XTest.GetLength(0);
            var missingIndices = new List<int>();
            for (var i=0;i<m;i++)
            {
                var isYMissing = false;
                for (var j=0;j<o;j++)
                {
                    if (string.IsNullOrEmpty(YTrain[i,j]))
                    {
                        missingIndices.Add(i);
                        isYMissing = true;
                        break;
                    }
                }
                if (!isYMissing)
                {
                    for (var j = 0; j < n; j++)
                    {
                        var isFullLineMissing = true;
                        if (!string.IsNullOrEmpty(XTrain[i, j]))
                        {
                            isFullLineMissing = false;
                            break;
                        }
                        if (isFullLineMissing) missingIndices.Add(i);
                    }
                }
            }
            XTrainComplete = new string[m - missingIndices.Count, n];
            YTrainComplete = new string[m - missingIndices.Count, o];
            int k = 0;
            for (var i = 0; i < m;i++ )
            {
                if (!missingIndices.Contains(i))
                {
                    for (var j = 0; j < n;j++ )
                        XTrainComplete[k, j] = XTrain[i, j];
                    for (var j = 0; j < o; j++)
                        YTrainComplete[k, j] = YTrain[i, j];
                    k++;
                }

            }           
            missingIndices.Clear();
            for (var i = 0; i < mt; i++)
            {
                var isFullLineMissing = true;
                for (var j = 0; j < n&&isFullLineMissing; j++)
                {                    
                    if (!string.IsNullOrEmpty(XTest[i, j]))
                    {
                        isFullLineMissing = false;                        
                    }                   
                }
                if (isFullLineMissing) missingIndices.Add(i);
            }
            XTestComplete = new string[mt - missingIndices.Count, n];
            k = 0;
            for (var i = 0; i < mt; i++)
            {
                if (!missingIndices.Contains(i))
                {
                    for (var j = 0; j < n; j++)
                        XTestComplete[k, j] = XTest[i, j];
                    k++;
                }

            }
            HandlePartial(XTrainComplete, XTestComplete, xColTypes);
        }
    
    }
}
