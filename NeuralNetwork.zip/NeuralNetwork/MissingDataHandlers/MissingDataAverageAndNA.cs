﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{

    /// <summary>
    /// Remove all rows with at least one missing data in YTrain.
    /// Remove all empty rows.
    /// Replace missing binary or categorical entries with "NA" (which becomes a new category).
    /// Replace missing numeric entries with the average of the column.
    /// </summary>
    public class MissingDataAverageAndNA:MissingDataHandler
    {

        /// <summary>
        /// Remove all rows with at least one missing data in YTrain.
        /// Remove all empty rows.
        /// Replace missing binary or categorical entries with "NA" (which becomes a new category).
        /// Replace missing numeric entries with the average of the column.
        /// </summary>
        public override void HandlePartial(string[,] XTrain, string[,] XTest, ColumnType[] xColTypes)
        {
            var m = XTrain.GetLength(0);
            var n = XTrain.GetLength(1);           
            var mt = XTest.GetLength(0);
            var averages = new float[n];
            for (var j = 0; j < n; j++)
            {
                if (xColTypes[j] == ColumnType.Numeric)
                {
                    var nbValidCells =m;
                    for (var i = 0; i < m; i++)
                    {
                        float value;
                        var converted = float.TryParse(XTrain[i, j],out value);
                        if (!converted) nbValidCells--;
                        averages[j] += value;
                    }
                    averages[j] /= nbValidCells;
                }
            }
            for (var i = 0; i < m; i++)
            {
                for (var j = 0; j < n; j++)
                {                    
                    if(string.IsNullOrEmpty(XTrain[i,j]))
                    {
                        if (xColTypes[j]!=ColumnType.Numeric)
                        {                            
                            XTrain[i, j] = "NA";
                            if (xColTypes[j] == ColumnType.Binary) xColTypes[j] = ColumnType.Categorical;
                        }
                        else
                        {                            
                            XTrain[i, j] = averages[j].ToString();
                        }
                    }
                }
            }
            for (var i = 0; i < mt; i++)
            {
                for (var j = 0; j < n; j++)
                {                   
                    if (string.IsNullOrEmpty(XTest[i, j]))
                    {
                        if (xColTypes[j] != ColumnType.Numeric)
                        {
                             XTest[i, j] = "NA";
                        }
                        else
                        {                           
                            XTest[i, j] = averages[j].ToString();
                        }
                    }
                }
            }

        }

    }
}
