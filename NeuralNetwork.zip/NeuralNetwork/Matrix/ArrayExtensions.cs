﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Accord.Math;

namespace NeuralNetwork
{
    public static class ArrayExtensions
    {     
        public static float[,] ToFloat(this double[,] a)
        {
            var res = a.Apply(x => (float)x);
            return res;
        }
       
        public static float[] ToFloat(this double[] a)
        {
            var res = a.Apply(x => (float)x);
            return res;
        }

        public static void Randomize(this float[,] v)
        {
            var rnd = new Random();
            var epsilon = Math.Sqrt(6) * Math.Pow(v.GetLength(0) + v.GetLength(1), -0.5); ;
            for (var i = 0; i < v.GetLength(0); i++)
            {
                for (var j = 0; j < v.GetLength(1); j++)
                {
                    v[i, j] = (float)(rnd.NextDouble() * 2 * epsilon - epsilon);
                }
            }
        }

        public static void Randomize(this float[] v)
        {
            var rnd = new Random();
            var epsilon = Math.Pow(6, 0.5) * Math.Pow(v.GetLength(0) + 1, -0.5); ;
            for (var i = 0; i < v.GetLength(0); i++)
            {
                v[i] = (float)(rnd.NextDouble() * 2 * epsilon - epsilon);
            }
        }

        public static void Roll(this float[,] matrix,float[] vector,int startIndex=0)
        {
            var m = matrix.GetLength(0);
            var n = matrix.GetLength(1);            
            for (var i = 0; i < m; i++)
            {
                for (var j=0;j<n;j++)
                {
                    vector[startIndex+i*n+j]=matrix[i,j];
                }
            }            
        }

        public static void UnRoll(this float[,] matrix,float[] vector,int startIndex=0)
        {
            var m = matrix.GetLength(0);
            var n = matrix.GetLength(1);
          
            for (var i = 0; i < m; i++)
            {
                for (var j = 0; j < n; j++)
                {
                    matrix[i, j] = vector[startIndex+i*n + j];
                }
            }           
        }

        public static void CopyInto(this float[] destination, float[] source, int destinationStartIndex = 0)
        {           
            for (var i = 0; i < source.Length; i++)
            {                
                destination[destinationStartIndex + i ] = source[i];                
            }
        }
      
        public static void CopyFrom(this float[] source, float[] destination, int sourceStartIndex = 0)
        {
            for (var i = 0; i < destination.Length; i++)
            {
                destination[ i] = source[sourceStartIndex+i];
            }
        }

        public static float[,] Subtract(this float[,] a, float[,] b)
        {
            var m = a.GetLength(0);
            var n = a.GetLength(1);
            var res = new float[m, n];
            for (var j = 0; j < n; j++)
            {
                for (var i = 0; i < m; i++)
                {
                    res[i, j] = a[i, j] - b[i,j];
                }
            }
            return res;
        }
       
        public static float[] Subtract(this float[] a, float[] b)
        {
            var m = a.GetLength(0);            
            var res = new float[m];
            for (var i = 0; i < m; i++)
            {
                res[i] = a[i] - b[i];
            }
            return res;
        }
        
        public static float[,] Subtract(this int a, float[,] b)
        {
            var m = b.GetLength(0);
            var n = b.GetLength(1);
            var res = new float[m, n];
            for (var j = 0; j < n; j++)
            {
                for (var i = 0; i < m; i++)
                {
                    res[i, j] = a-b[i,j];
                }
            }
            return res;
        }
        
        public static float[,] ElementwiseMultiply(this float[,] a, float[,] b)
        {
            if (!a.GetLength(0).Equals(b.GetLength(0))) throw new Exception("ElementwiseMultiply: nb rows in a must equal nb rows in b.");
            if (!a.GetLength(1).Equals(b.GetLength(1))) throw new Exception("ElementwiseMultiply: nb Columns in a must equal nb columns in b.");
            var m = a.GetLength(0);
            var n = a.GetLength(1);
            var res = new float[m, n];
            for (var j = 0; j < n; j++)
            {
                for (var i = 0; i < m; i++)
                {
                    res[i, j] = a[i, j] * b[i,j];
                }
            }
            return res;
        }

        public static float[,] Add(this float[,] a, float[,] b)
        {
            var m = a.GetLength(0);
            var n = a.GetLength(1);
            var res = new float[m, n];
            for (var j = 0; j < n; j++)
            {
                for (var i = 0; i < m; i++)
                {
                    res[i, j] = a[i, j] + b[i,j];
                }
            }
            return res;
        }

        public static float[] Add(this float[] a, float[] b)
        {
            var m = a.GetLength(0);           
            var res = new float[m];           
            for (var i = 0; i < m; i++)
            {
                res[i]= a[i]+= b[i];
            }            
            return res;
        }

        public static float[,] Add(this float[,] a, float[] b, int dim)
        {
            var m = a.GetLength(0);
            var n = a.GetLength(1);
            var res = new float[m, n];
            for (var j=0;j<n;j++)
            {
                for (var i=0;i<m;i++)
                {
                    res[i, j] = a[i,j]+b[j];
                }
            }
            return res;
        }

        public static float[,] Multiply(this float[,] a, float b)
        {
            var m = a.GetLength(0);
            var n = a.GetLength(1);
            var res = new float[m, n];
            for (var j = 0; j < n; j++)
            {
                for (var i = 0; i < m; i++)
                {
                    res[i, j] = a[i, j] *b;
                }
            }
            return res;
        }

        public static float[,] Apply(this float[,] a,Func<float,float> f)
        {
            var res = a.ToDouble().Apply(z => (float)f((float)z));
            return res;//.ToFloat();
        }

        public static float[] Apply(this float[] a, Func<float, float> f)
        {
            var res = a.Select(z => (float)f((float)z)).ToArray();
            return res;
        }

        public static float[,] Apply(this float[,] a,float[,] b, Func<float,float, float> f)
        {
            var m = a.GetLength(0);
            var n = a.GetLength(1);
            var res = new float[m,n];
            Parallel.For(0, m, i =>
                {
                    for (var j=0;j<n;j++)
                    {
                        res[i,j]=f(a[i,j],b[i,j]);
                    }
                });
            return res;
        }

        public static float[,] ApplySigmoid(this float[,] a)
        {
            var res = a.ToDouble().Apply(z => 1.0 / (1.0 + Math.Exp(-z)));
            return res.ToFloat();
        }

        public static float Sum(this float[,] a)
        {
            var tmp= a.ToDouble();
            var tmp2=tmp.Sum().Sum();
            return (float)tmp2;
        }

        public static float Sum(this float[,] a,int dimension)
        {
            return a.Sum(dimension);
        }

        public static float Distance(this float[] a,float[] b)
        {
            var sum = 0.0F;
            for (var i=0;i<a.Length;i++)
            {
                sum += (a[i] - b[i]) * (a[i] - b[i]);
            }
            return (float)Math.Sqrt(sum);
        }

        public static float[,] Normalize(this float[,] a)
        {
            var res = Accord.Statistics.Tools.ZScores(a.ToDouble()).ToFloat();
            return res;
        }
    
        public static bool ValueEquals(this float[] a,float[] b)
        {
            var equals = true;
            for (var i = 0; i < a.Length;i++ )
            {
                equals = equals && a[i].Equals(b[i]);
            }
            return equals;
        }

        public static bool ValueEquals(this float[,] a, float[,] b)
        {
            var equals = true;
            for (var i = 0; i < a.GetLength(0); i++)
            {
                for (var j = 0; j < a.GetLength(1); j++)
                {
                    equals = equals && a[i,j].Equals(b[i,j]);
                }
            }
            return equals;
        }

        public static float[,] MultiplyBy(this float[,] a, float[,] b)
        {            
            if (a.GetLength(1) != b.GetLength(0))
               throw new ArgumentException("Matrix dimensions must match");

            int n = a.GetLength(1);
            int m = a.GetLength(0); //a.GetLength(0);
            int p = b.GetLength(1); //b.GetLength(1);
            var result = new float[m, p];
            unsafe
            {
                var Bcolj = new float[n];
                Parallel.For(0, p, j =>
                {
                    fixed (float* ptrA = a)
                    {
                        for (int k = 0; k < Bcolj.Length; k++)
                            Bcolj[k] = b[k, j];

                        float* Arowi = ptrA;
                        for (int i = 0; i < m; i++)
                        {
                            float s = 0.0F;
                            for (int k = 0; k < Bcolj.Length; k++)
                                s += *(Arowi++) * Bcolj[k];
                            result[i, j] = s;
                        }
                    }
                });
            }
            return result;
        }

        public static float[,] MultiplyByTranspose(this float[,] a, float[,] b)
        {
            if (a.GetLength(1) != b.GetLength(1))
                throw new ArgumentException("Matrix dimensions must match");

            int n = a.GetLength(1);
            int m = a.GetLength(0); //a.GetLength(0);
            int p = b.GetLength(0); //b.GetLength(1);
            var result = new float[m, p];
            unsafe
            {
                var Bcolj = new float[n];
                //Parallel.For(0, p, j =>
                for (var j = 0; j < p;j++ )
                {
                    fixed (float* ptrA = a)
                    {
                        for (int k = 0; k < Bcolj.Length; k++)
                            Bcolj[k] = b[j, k];

                        float* Arowi = ptrA;
                        for (int i = 0; i < m; i++)
                        {
                            float s = 0.0F;
                            for (int k = 0; k < Bcolj.Length; k++)
                                s += *(Arowi++) * Bcolj[k];
                            result[i, j] = s;
                        }
                    }
                }
                //);
            }
            return result;
        }

        public static float[,] TransposeAndMultiply(this float[,] a, float[,] b)
        {
            if (a.GetLength(0) != b.GetLength(0))
                throw new ArgumentException("Matrix dimensions must match");

           
            int n = a.GetLength(0);
            int m = a.GetLength(1); //a.GetLength(0);
            var aT=new float[m,n];
            Parallel.For(0, n, i =>
                {
                    for (var j=0;j<m;j++)
                    {

                        aT[j, i] = a[i, j];
                    }
                });            
            return aT.MultiplyBy(b);
        }      
    }
}
