﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{
    public class TestCoursera
    {

        public static void Test()
        {
            //var accuracyAssessor = new AccuracyAssessorClassification();
            var activator = new ActivatorSigmoid();
            var costCalculator = new CostCalculatorLogistic();
            var regularizedCostCalculator = new RegularizedCostCalculator(costCalculator,RegularizationScheme.L2Norm,1.0F);
                        
            var XCoursera = TestData.GenerateCourseraX();
            var YCoursera = TestData.GenerateCourseraY();
            var thetas = new List<float[,]>()
            {
                TestData.GenerateCourseraTheta1(),TestData.GenerateCourseraTheta2()
            };
            var biaises = new List<float[]>()
            {
                TestData.GenerateCourseraBiais1(),TestData.GenerateCourseraBiais2()
            };            
            var ntw = new ModelNeuralNetwork(XCoursera.GetLength(1), YCoursera.GetLength(1), new int[1] { 5 },regularizedCostCalculator,activator);
            var weights = ntw.Roll(thetas, biaises);
            ntw.Weights = weights;
            var s = new SolverGradientDescent(ntw,null,null, 100000, 0.01F, 0.8F);
            s.CheckGradient(XCoursera, YCoursera);
            var isFitted=s.Fit(XCoursera, YCoursera);
            var deb=s.LastIteration;
            Console.WriteLine("Nb Epoch: {0}", deb);
            var costCoursera=s.Model.CostCalculator.Cost(s.Model.Predict(XCoursera), YCoursera, weights);
            Console.WriteLine("cost: {0}", costCoursera);
            //var accCoursera=accuracyAssessor.AssessAccuracy(s.Model.Predict(XCoursera), YCoursera);
            //Console.WriteLine("accuracy: {0:P}", accCoursera);
        }
    }
}
