﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{

    public class TrainValidationData
    {
        public float[,] XTrain;
        public float[,] YTrain;
        public float[,] XVal;
        public float[,] YVal;
    }


    public class ModelSelectorCrossValidation : IModelSelector
    {
        protected int _NbSamples;

        public ModelSelectorCrossValidation(int nbSamples) { _NbSamples = nbSamples; }
        
        public void TestCV()
        {
            var X = new float[10, 2];
            for (var i = 0; i < X.GetLength(0); i++)
            {
                X[i, 0] = i;
            }
            var Y = new float[10, 1];
            for (var i = 0; i < Y.GetLength(0); i++)
            {
                Y[i, 0] = i * 100;
            }            
            var cv = PrepareSamples(X, Y,3);
            System.Diagnostics.Debug.Assert(cv.Count == 4);
            var sum = 0.0F;
            Accord.Math.Matrix.Apply(cv.First().XTrain, x => sum += x);
            Accord.Math.Matrix.Apply(cv.First().XVal, x => sum += x);
            System.Diagnostics.Debug.Assert(sum == 45);
            System.Diagnostics.Debug.Assert(cv.First().XTrain.GetLength(0) == 7);
            System.Diagnostics.Debug.Assert(cv.First().XTrain.GetLength(1) == 2);
            System.Diagnostics.Debug.Assert(cv.First().XVal.GetLength(0) == 3);
            System.Diagnostics.Debug.Assert(cv.First().XVal.GetLength(1) == 2);
            System.Diagnostics.Debug.Assert(cv.First().YTrain.GetLength(0) == 7);
            System.Diagnostics.Debug.Assert(cv.First().YTrain.GetLength(1) == 1);
            System.Diagnostics.Debug.Assert(cv.First().YVal.GetLength(0) == 3);
            System.Diagnostics.Debug.Assert(cv.First().YVal.GetLength(1) == 1);
            System.Diagnostics.Debug.Assert(cv.Last().YTrain.GetLength(0) == 9);
            System.Diagnostics.Debug.Assert(cv.Last().YTrain.GetLength(1) == 1);
            System.Diagnostics.Debug.Assert(cv.Last().YVal.GetLength(0) == 1);
            System.Diagnostics.Debug.Assert(cv.Last().YVal.GetLength(1) == 1);
            var exception = false;
            try
            {              
                cv = PrepareSamples(X, Y,11);
            }
            catch (Exception)
            {
                exception = true;
            }
            System.Diagnostics.Debug.Assert(exception);
        }

        public static List<TrainValidationData> PrepareSamples(float[,] X, float[,] Y,int nbSamples)
        {
            if (X.GetLength(0) != Y.GetLength(0)) throw new ArgumentException();
            if (nbSamples > Y.GetLength(0)) throw new ArgumentException();
            var nbItemsPerSample = (int)X.GetLength(0) / nbSamples;
            var res = new List<TrainValidationData>();
            var indices = Accord.Math.Matrix.Indices(X.GetLength(0));
            Accord.Statistics.Tools.Shuffle(indices);
            var slots = Accord.Math.Matrix.Split(indices, nbItemsPerSample).ToList();
            if (slots.Count * nbItemsPerSample < indices.Length)
            {
                var lastSlot = Accord.Math.Matrix.Submatrix(indices, slots.Count * nbItemsPerSample-1, indices.Length-1);
                slots.Add(lastSlot);
            }
            for (var k = 0; k < slots.Count; k++)
            {
                var XVal = Accord.Math.Matrix.Submatrix(X, slots[k]);
                var YVal = Accord.Math.Matrix.Submatrix(Y, slots[k]);
                var trainIndices = new int[0];
                for (var i = 0; i < slots.Count; i++)
                {
                    if (i != k) trainIndices = trainIndices.Concat(slots[i]).ToArray();
                }
                var XTrain = Accord.Math.Matrix.Submatrix(X, trainIndices);
                var YTrain = Accord.Math.Matrix.Submatrix(Y, trainIndices);
                res.Add(new TrainValidationData() { XTrain = XTrain, YTrain = YTrain, XVal = XVal, YVal = YVal });
            }
            return res;
        }

        public List<EvaluatedModel> EvaluateModelsByValCost(float[,] X, float[,] Y, List<ISolver> models)
        {
            var subSamples = PrepareSamples(X, Y, _NbSamples);
            var result = new List<EvaluatedModel>();
            var m = X.GetLength(0);
            foreach (var model in models)
            {
                float valCost = 0.0F;
                foreach (var subSample in subSamples)
                {
                    var mVal = subSample.YVal.GetLength(0);
                    model.Model.ResetWeights();
                    model.Fit(subSample.XTrain, subSample.YTrain);
                    var valPred = model.Model.Predict(subSample.XVal);
                    valCost += model.Model.CostCalculator.Cost(valPred, subSample.YVal, model.Model.Weights) * mVal / m;                    
                    model.Reset();
                }
                var statistics = new Statistics(valCost);
                result.Add(new EvaluatedModel() { Statistics = statistics, Model = model });
            }
            var orderedResult = result.OrderBy(evaluatedModel => evaluatedModel.Statistics.ValCost).ToList();
            return orderedResult;
        }

        public List<EvaluatedModel> EvaluateModelsByCost(float[,] X, float[,] Y, List<ISolver> models)
        {
            var subSamples = PrepareSamples(X, Y, _NbSamples);
            var result = new List<EvaluatedModel>();
            var m = X.GetLength(0);
            foreach (var model in models)
            {
                float valCost = 0.0F, trainCost = 0.0F;
                foreach (var subSample in subSamples)
                {
                    var mVal = subSample.YVal.GetLength(0);
                    model.Model.ResetWeights();
                    model.Fit(subSample.XTrain, subSample.YTrain);
                    var trainPred = model.Model.Predict(subSample.XTrain);
                    trainCost += model.Model.CostCalculator.Cost(trainPred, subSample.YTrain, model.Model.Weights) * mVal / m;
                    var valPred = model.Model.Predict(subSample.XVal);
                    valCost += model.Model.CostCalculator.Cost(valPred, subSample.YVal, model.Model.Weights) * mVal / m;                    
                    model.Reset();
                }
                var statistics = new Statistics(valCost, trainCost);
                result.Add(new EvaluatedModel() { Statistics = statistics, Model = model });
            }
            var orderedResult = result.OrderBy(evaluatedModel => evaluatedModel.Statistics.ValCost).ToList();
            return orderedResult;
        }

        public List<EvaluatedModel> EvaluateModels(float[,] X, float[,] Y, List<ISolver> models,IDataNormalizer dataNormalizer)
        {
            var subSamples = PrepareSamples(X, Y, _NbSamples);
            var result = new List<EvaluatedModel>();
            var m = X.GetLength(0);
            foreach (var model in models)
            {
                float valCost = 0.0F, trainCost = 0.0F, valAccuracy = 0.0F, trainAccuracy = 0.0F;                
                foreach (var subSample in subSamples)
                {
                    var mVal = subSample.YVal.GetLength(0);
                    model.Model.ResetWeights();
                    model.Fit(subSample.XTrain, subSample.YTrain);
                    var trainPred = model.Model.Predict(subSample.XTrain);
                    trainCost += model.Model.CostCalculator.Cost(trainPred, subSample.YTrain, model.Model.Weights)*mVal/m;
                    var valPred = model.Model.Predict(subSample.XVal);
                    valCost += model.Model.CostCalculator.Cost(valPred, subSample.YVal, model.Model.Weights) * mVal / m;
                    var valPredString = dataNormalizer.DecodeY(valPred);
                    var trainPredString = dataNormalizer.DecodeY(trainPred);
                    var yTrainString = dataNormalizer.DecodeY(subSample.YTrain);
                    var yValString = dataNormalizer.DecodeY(subSample.YVal);                    
                    var accuracyAssessor = new AccuracyAssessor();
                    valAccuracy += accuracyAssessor.AssessAccuracy(valPredString, yValString, dataNormalizer.YColTypes) * mVal / m;
                    trainAccuracy += accuracyAssessor.AssessAccuracy(trainPredString, yTrainString, dataNormalizer.YColTypes) * mVal / m;
                    model.Reset();
                }
                var statistics = new Statistics(valCost , trainCost , valAccuracy , trainAccuracy );                    
                result.Add(new EvaluatedModel() { Statistics = statistics, Model = model });
            }
            var orderedResult = result.OrderBy(evaluatedModel => evaluatedModel.Statistics.ValCost).ToList();
            return orderedResult;
        }
   
        public List<EvaluatedModel> EvaluateRegularization(float[,] X, float[,] Y, ISolver model,IDataNormalizer dataNormalizer,float[] regularizations)
        {
            var models = new List<ISolver>();
            foreach(var budget in regularizations)
            {
                var newModel = model.Clone();
                newModel.Model.CostCalculator.RegularizationBudget = budget;
                models.Add(newModel);
            }
            var result = EvaluateModels(X, Y, models, dataNormalizer);
            return result;
        }

    
    }
}
