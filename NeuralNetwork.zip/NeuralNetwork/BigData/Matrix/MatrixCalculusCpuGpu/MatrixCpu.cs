﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigData
{
    public class CpuMatrix
    {
        public float[,] Multiply(float[,] a, float[,] b)
        {
            var m = a.GetLength(0);
            var n = a.GetLength(1);
            var o = b.GetLength(1);
            var res = new float[m, o];
            unsafe
            {
                Parallel.For(0, o, j =>
                {
                    var bColj = new float[n];
                    fixed (float* ptrA = a)
                    {
                        for (var k = 0; k < n; k++) bColj[k] = b[k, j];
                        float* Arowi = ptrA;
                        for (var i = 0; i < m; i++)
                        {
                            var s = 0F;
                            for (var k = 0; k < n; k++) s += *(Arowi++) * bColj[k];
                            res[i, j] = s;
                        }
                    }
                });
            }
            return res;
        }

        public float[,] Multiply(float[,] a, float b)
        {
            var m = a.GetLength(0);
            var n = a.GetLength(1);
            var res = new float[m, n];
            unsafe
            {
                Parallel.For(0, m, i =>
                {
                    fixed (float* ptrA = &a[i, 0])
                    {
                        fixed (float* ptrRes = &res[i, 0])
                        {
                            float* Arowi = ptrA; float* resRowi = ptrRes;
                            for (var j = 0; j < n; j++)
                            {
                                *(resRowi++) = *(Arowi++) * b;
                            }
                        }
                    }
                });
            }
            return res;
        }

        public float[,] ElementwiseMultiply(float[,] a, float[,] b)
        {
            var m = a.GetLength(0);
            var n = a.GetLength(1);
            var res = new float[m, n];
            unsafe
            {
                Parallel.For(0, m, i =>
                {
                    fixed (float* ptrA = &a[i, 0])
                    {
                        fixed (float* ptrB = &b[i, 0])
                        {
                            fixed (float* ptrRes = &res[i, 0])
                            {
                                float* Arowi = ptrA; float* Browi = ptrB; float* resRowi = ptrRes;
                                for (var j = 0; j < n; j++)
                                {
                                    *(resRowi++) = *(Arowi++) * *(Browi++);
                                }
                            }
                        }
                    }
                });
            }
            return res;
        }

        public float[,] Add(float[,] a, float[,] b)
        {
            var m = a.GetLength(0);
            var n = a.GetLength(1);
            var res = new float[m, n];
            unsafe
            {
                Parallel.For(0, m, i =>
                {
                    fixed (float* ptrA = &a[i, 0])
                    {
                        fixed (float* ptrB = &b[i, 0])
                        {
                            fixed (float* ptrRes = &res[i, 0])
                            {
                                float* Arowi = ptrA; float* Browi = ptrB; float* resRowi = ptrRes;
                                for (var j = 0; j < n; j++)
                                {
                                    *(resRowi++) = *(Arowi++) + *(Browi++);
                                }
                            }
                        }
                    }
                });
            }
            return res;
        }

        public float[,] Subtract(float[,] a, float[,] b)
        {
            var m = a.GetLength(0);
            var n = a.GetLength(1);
            var res = new float[m, n];
            unsafe
            {
                Parallel.For(0, m, i =>
                {
                    fixed (float* ptrA = &a[i, 0])
                    {
                        fixed (float* ptrB = &b[i, 0])
                        {
                            fixed (float* ptrRes = &res[i, 0])
                            {
                                float* Arowi = ptrA; float* Browi = ptrB; float* resRowi = ptrRes;
                                for (var j = 0; j < n; j++)
                                {
                                    *(resRowi++) = *(Arowi++) - *(Browi++);
                                }
                            }
                        }
                    }
                });
            }
            return res;
        }

        public float[,] Subtract(float a, float[,] b)
        {
            var m = b.GetLength(0);
            var n = b.GetLength(1);
            var res = new float[m, n];
            unsafe
            {
                Parallel.For(0, m, i =>
                {
                    fixed (float* ptrB = &b[i, 0])
                    {
                        fixed (float* ptrRes = &res[i, 0])
                        {
                            float* Browi = ptrB; float* resRowi = ptrRes;
                            for (var j = 0; j < n; j++)
                            {
                                *(resRowi++) = a - *(Browi++);
                            }
                        }
                    }
                });
            }
            return res;
        }

        public float[,] Transpose(float[,] a)
        {
            var m = a.GetLength(0);
            var n = a.GetLength(1);
            var res = new float[n, m];
            unsafe
            {
                Parallel.For(0, m, i =>
                {
                    fixed (float* ptrA = &a[i, 0])
                    {
                        float* Arowi = ptrA;
                        for (var j = 0; j < n; j++)
                        {
                            res[j, i] = *(Arowi++);
                        }
                    }
                });
            }
            return res;
        }

    }
}
