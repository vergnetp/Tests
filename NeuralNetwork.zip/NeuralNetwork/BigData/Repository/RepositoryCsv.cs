﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigData
{
    public class RepositoryCsv:IRepository
    {

        #region Import

        protected string _Folder;

        public void Initialize(string address,string user=null,string pwd=null)
        {
            _Folder = address;
        }

        public string[] Header(string table)
        {
            var path = Path.Combine(_Folder, string.Format("{0}.csv", table));
            var sr = new StreamReader(path);
            var parser = new CsvReader(sr);
            parser.Read();
            return parser.FieldHeaders;
        }

        public long GetNbRows(string table)
        {
            var path = Path.Combine(_Folder, string.Format("{0}.csv", table));
            var headerOffset = 1;
            var nbRows = 0L;
            using (StreamReader sr = new StreamReader(path))
            {
                while (sr.ReadLine() != null)
                    nbRows++;
            }
            nbRows -= headerOffset;
            return nbRows;
        }

        public int GetNbColumns(string table)
        {
            var path = Path.Combine(_Folder, string.Format("{0}.csv", table));
            var sr = new StreamReader(path);
            var parser = new CsvReader(sr);
            parser.Read();
            var header = parser.FieldHeaders;
            var nbColumns = header.Length;
            sr.Close();
            sr.Dispose();
            parser.Dispose();
            return nbColumns;
        }

        public float[,] ImportAsFloat(string table, long offset = 0, long size = long.MaxValue)
        {
            var path = Path.Combine(_Folder, string.Format("{0}.csv", table));
            var headerOffset = 1;
            var sr = new StreamReader(path);
            var parser = new CsvReader(sr);
            var nbRows = 0L;
            using (StreamReader sr2 = new StreamReader(path))
            {
                while (sr2.ReadLine() != null)
                    nbRows++;
            }
            nbRows -= headerOffset;

            size = Math.Min(nbRows - offset, size);

            if (nbRows <= offset || size == 0)
            {
                parser.Dispose();
                return null;
            }

            parser.Read();
            var header = parser.FieldHeaders;
            var nbColumns = header.Length;
            var res = new float[size, nbColumns];

            // offset:
            if (offset != 0)
            {
                while ((parser.Row - 1) != offset && parser.Read()) { }
            }

            // populate result:
            var i = 0; string[] cells;
            if (offset == 0 && !true)
            {
                cells = header;
                for (var j = 0; j < nbColumns; j++)
                    res[i, j] = Convert.ToSingle(cells[j]);
                i++;
            }
            if (i < res.GetLength(0))
            {
                cells = parser.CurrentRecord;
                for (var j = 0; j < nbColumns; j++)
                    res[i, j] = Convert.ToSingle(cells[j]);
                i++;
            }
            try
            {
                while (parser.Read() && i < res.GetLength(0))
                {
                    cells = parser.CurrentRecord;
                    for (var j = 0; j < nbColumns; j++)
                        res[i, j] = Convert.ToSingle(cells[j]);
                    i++;
                }
            }
            catch { }
            parser.Dispose();
            return res;
        }





        /// <summary>
        /// Return the csv, or part of it, in a string[,].
        /// Exclude the header if any.
        /// Return null if no data to return.
        /// </summary>
        /// <param name="path">csv filename</param>
        /// <param name="hasHeader">does the csv has a header?</param>
        /// <param name="offset">header excluded (0 is always the first line with data)</param>
        /// <param name="size">How many rows to return</param>
        /// <returns></returns>
        public string[,] Import(string table, long offset = 0, long size = long.MaxValue)
        {
            var path = Path.Combine(_Folder, string.Format("{0}.csv", table));
            var headerOffset = 1;
            var sr = new StreamReader(path);
            var parser = new CsvReader(sr);
            var nbRows = 0L;
            using (StreamReader sr2 = new StreamReader(path))
            {
                while (sr2.ReadLine() != null)
                    nbRows++;
            }
            nbRows -= headerOffset;

            size = Math.Min(nbRows - offset, size);

            if (nbRows <= offset || size == 0)
            {
                parser.Dispose();
                return null;
            }

            parser.Read();
            var header = parser.FieldHeaders;
            var nbColumns = header.Length;
            var res = new string[size, nbColumns];

            // offset:
            if (offset != 0)
            {
                while ((parser.Row - 1) != offset && parser.Read()) { }
            }

            // populate result:
            var i = 0; string[] cells;
            if (offset == 0 && !true)
            {
                cells = header;
                for (var j = 0; j < nbColumns; j++)
                    res[i, j] = (cells[j]);
                i++;
            }
            if (i < res.GetLength(0))
            {
                cells = parser.CurrentRecord;
                for (var j = 0; j < nbColumns; j++)
                    res[i, j] = (cells[j]);
                i++;
            }
            try
            {
                while (parser.Read() && i < res.GetLength(0))
                {
                    cells = parser.CurrentRecord;
                    for (var j = 0; j < nbColumns; j++)
                        res[i, j] = (cells[j]);
                    i++;
                }
            }
            catch { }
            parser.Dispose();
            return res;
        }

        #endregion

        #region Export

        public void InsertData(string table, float[,] data)
        {
            var path = Path.Combine(_Folder, string.Format("{0}.csv", table));
            var nbRows = data.GetLength(0);
            var nbColumns = data.GetLength(1);
            var sb = new StringBuilder();
            for (var j = 0; j < nbColumns; j++)
            {
                sb.Append(string.Format("Columns{0}",j));
                if (j < nbColumns - 1)
                { sb.Append(","); }
                else { sb.Append("\n"); }
            }
            for (var i = 0; i < nbRows; i++)
            {
                for (var j = 0; j < nbColumns; j++)
                {
                    sb.Append(data[i, j]);
                    if (j < nbColumns - 1)
                    { sb.Append(","); }
                    else { sb.Append("\n"); }
                }
            }
            File.AppendAllText(path, sb.ToString());
        }      


        public void Export(string table, string[,] data,bool hasHeader)
        {
            var path = Path.Combine(_Folder, string.Format("{0}.csv", table));
            var nbRows = data.GetLength(0);
            var nbColumns = data.GetLength(1);
            var sb = new StringBuilder();
            if (!hasHeader)
            {
                for (var j = 0; j < nbColumns; j++)
                {
                    sb.Append(string.Format("Columns{0}", j));
                    if (j < nbColumns - 1)
                    { sb.Append(","); }
                    else { sb.Append("\n"); }
                }
            }
            for (var i = 0; i < nbRows; i++)
            {
                for (var j = 0; j < nbColumns; j++)
                {
                    sb.Append(data[i, j]);
                    if (j < nbColumns - 1)
                    { sb.Append(","); }
                    else { sb.Append("\n"); }
                }
            }
            File.WriteAllText(path, sb.ToString());
        }

        public void InsertData(string table, string[,] data,bool hasHeader)
        {
            var path = Path.Combine(_Folder, string.Format("{0}.csv", table));
            var nbRows = data.GetLength(0);
            var nbColumns = data.GetLength(1);
            var sb = new StringBuilder();
            var headerOffset = hasHeader ? 1 : 0;
            for (var i = headerOffset; i < nbRows; i++)
            {
                for (var j = 0; j < nbColumns; j++)
                {
                    sb.Append(data[i, j]);
                    if (j < nbColumns - 1)
                    { sb.Append(","); }
                    else { sb.Append("\n"); }
                }
            }
            File.AppendAllText(path, sb.ToString());
        }


        public void Export(string table, string[] data)
        {
            var path = Path.Combine(_Folder, string.Format("{0}.csv", table));
            
            var nbColumns = data.Length;
            var sb = new StringBuilder();            
            for (var j = 0; j < nbColumns; j++)
            {
                sb.Append(data[j]);
                if (j < nbColumns - 1)
                { sb.Append(","); }
                else { sb.Append("\n"); }
            }            
            File.WriteAllText(path, sb.ToString());
        }

        public void InsertRow(string table, string[] data)
        {
            var path = Path.Combine(_Folder, string.Format("{0}.csv", table));

            var nbColumns = data.Length;
            var sb = new StringBuilder();
            for (var j = 0; j < nbColumns; j++)
            {
                sb.Append(data[j]);
                if (j < nbColumns - 1)
                { sb.Append(","); }
                else { sb.Append("\n"); }
            }
            File.AppendAllText(path, sb.ToString());
        }

        #endregion

        public void Delete(string table)
        {
            var path = Path.Combine(_Folder, string.Format("{0}.csv", table));
            if (File.Exists(path))File.Delete(path);
        }

        public void Clear(string table)
        {
            var path = Path.Combine(_Folder, string.Format("{0}.csv", table));
            if (File.Exists(path)) File.Delete(path);
            File.WriteAllText(path, string.Empty);
        }

    }
}
