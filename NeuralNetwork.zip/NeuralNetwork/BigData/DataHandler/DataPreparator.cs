﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigData
{

    public enum ColumnType
    {
        Unknown,
        Ignore,
        Id,
        Numeric,
        Binary,
        Categorical
    }

    public class DataPreparator
    {
        public List<string>[] DistinctValues;
        public ColumnType[] ColumnTypes;
        public float[] XMeans; public float[] XStdDevs; public float[] XMins; public float[] XMaxs;
        public float[] YMeans; public float[] YStdDevs; public float[] YMins; public float[] YMaxs;

        public string OutputFile;

        protected IRepository _Repo;
        public DataPreparator(IRepository repo) { _Repo= repo; }

        public static bool IsNumeric(object Expression)
        {
            float retNum;
            if (string.IsNullOrEmpty(Convert.ToString(Expression))) { return true; }
            bool isNum = float.TryParse(Convert.ToString(Expression), System.Globalization.NumberStyles.Any, System.Globalization.NumberFormatInfo.InvariantInfo, out retNum);
            return isNum;
        }
        
        /// <summary>
        /// Call that before using training or test data.
        /// This should be called on the training data.
        /// Populate DistinctValues and ColumnTypes.
        /// Populate the stats (means etc.)
        /// Generate Output, a copy of the targeted subset input except for rows where all value of the dependent variables are null or empty.
        /// </summary>
        /// <param name="outputName">The output name.</param>
        /// <param name="trainingName">The input name.</param>
        /// <param name="dependentColumns">Zero based indices of the dependent variables. Null if none (f.e. on Kaggle test set)</param>
        /// <param name="offset">Zero based start of the subset.</param>
        /// <param name="size">Number of rows in the subset.</param>
        public void Prepare(string outputName, string trainingName, int[] dependentColumns, long offset, long size)
        {
            OutputFile = outputName;
            // todo: if the full column is empty then it should be deemed categorical   
            _Repo.Clear(outputName);            
            ColumnType[] ColTypes;
            var lastRow = offset + size;
            var firstRow = _Repo.Header(trainingName);
            _Repo.Export(trainingName, firstRow);
            var n = (long)firstRow.GetLength(1);
            var maxSize = 1000 * 1000 / n; // We allow a 64MB array max
            var subSize = Math.Min(size, maxSize);
            var subData = _Repo.Import(trainingName, offset, subSize);            
            DistinctValues = new List<string>[subData.GetLength(1)];
            ColTypes = new ColumnType[subData.GetLength(1)];
            do
            {
                var missingIndices = new List<int>();
                for (var j = 0; j < subData.GetLength(1); j++)
                //Parallel.For (0, subData.GetLength(1), j =>
                {
                    ColTypes[j] = ColumnType.Numeric;
                    if (DistinctValues[j] == null)
                    {
                        DistinctValues[j] = new List<string>();
                    }
                    var dico = new SortedDictionary<string, bool>();
                    for (var i = 0; i < subData.GetLength(0); i++)
                    {
                        if (dependentColumns != null && (string.IsNullOrEmpty(subData[i, j]) && dependentColumns.Contains(j)))
                        {
                            if (!missingIndices.Contains(i)) missingIndices.Add(i);
                        }
                        else
                        {
                            if (!DistinctValues[j].Contains(subData[i, j])) DistinctValues[j].Add(subData[i, j]);
                            if (!IsNumeric(subData[i, j])) ColTypes[j] = ColumnType.Categorical;
                        }
                    }
                }//);              
                subData = subData.RemoveRowsAndShuffle<string>(missingIndices.ToArray());
                _Repo.InsertData(outputName, subData,false);
                offset += subSize;
                subSize = Math.Min(subSize, lastRow - offset);
                subData = _Repo.Import(trainingName, offset, subSize);
            } while (subData != null);
            // Add "NA" to be able to handle unseen data
            for (var j = 0; j < DistinctValues.Length; j++)
            {
                if ((ColTypes[j] == ColumnType.Categorical || ColTypes[j] == ColumnType.Binary) && !DistinctValues[j].Contains("NA"))
                {
                    DistinctValues[j].Add("NA");
                    ColTypes[j] = ColumnType.Categorical;
                }
            }           

        }
    }
}
