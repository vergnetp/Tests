﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigData
{
    public abstract class MissingDataHandler
    {             

        public DataPreparator DataPreparator;

        /// <summary>
        /// Call that before using training data.
        /// Populate DistinctValues and Coltypes.
        /// Generate a copy of inputFile except for lines where all value of the dependent variables are null or empty, and replace partially missing values with relevant values.
        /// </summary>
        /// <param name="outputName">The output name.</param>
        /// <param name="preparedName">The intermediary prepared data table name.</param>
        /// <param name="trainingName">The input name.</param>
        /// <param name="dependentColumns">Zero based indices of the dependent variables. Null if none (f.e. on Kaggle test set)</param>
        /// <param name="offset">Zero based start of the subset.</param>
        /// <param name="size">Number of rows in the subset.</param>
        public void HandleTrain(string outputName, string preparedName, string trainingName, int[] dependentColumns, long offset, long size)
        {
            DataPreparator.Prepare(preparedName, trainingName, dependentColumns, offset, size);
            HandleMissingTrain(outputName, preparedName, dependentColumns, 0, long.MaxValue);
        }

        /// <summary>
        /// Call that before using test data.
        /// HandleTrain must have been called before on the training data.
        /// Populate DistinctValues and Coltypes.
        /// Generate a copy of inputFile except for lines where all value of the dependent variables are null or empty, and replace partially missing values with relevant values.
        /// </summary>
        /// <param name="outputName">The output name.</param>
        /// <param name="preparedName">The intermediary prepared data table name.</param>
        /// <param name="testName">The input name.</param>
        /// <param name="dependentColumns">Zero based indices of the dependent variables. Null if none (f.e. on Kaggle test set)</param>
        /// <param name="offset">Zero based start of the subset.</param>
        /// <param name="size">Number of rows in the subset.</param>
        public void HandleTest(string outputName, string preparedName, string testName, int[] dependentColumns, long offset, long size)
        {
            if (DataPreparator.ColumnTypes == null) throw new Exception("Data not prepared. You need to call HandleTrain first");
            HandleMissingTest(outputName, preparedName, dependentColumns, offset, size);
        }

        /// <summary>
        /// Call that before using training data.
        /// Will replace partially missing values with relevant values.
        /// </summary>
        /// <param name="outputName">The complete file name of the output.</param>
        /// <param name="trainingName">The complete file name of the input. Must be a csv with header.</param>
        /// <param name="dependentColumns">Zero based indices of the dependent variables. Null if none (f.e. on Kaggle test set)</param>
        /// <param name="offset">Zero based start of the subset.</param>
        /// <param name="size">Number of rows in the subset.</param>
        public abstract void HandleMissingTrain(string outputName, string trainingName, int[] dependentColumns, long offset, long size);
        public abstract void HandleMissingTest(string outputName, string trainingName, int[] dependentColumns, long offset, long size);

    }
}
