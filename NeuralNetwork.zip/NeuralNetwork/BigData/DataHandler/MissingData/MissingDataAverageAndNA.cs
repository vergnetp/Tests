﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BigData
{
    public class MissingDataAverageAndNA : MissingDataHandler
    {
        public MissingDataAverageAndNA(DataPreparator dataPreparator) { DataPreparator = dataPreparator; }

        public override void HandleMissingTest(string outputName, string traingName, int[] dependentColumns, long offset, long size)
        {
            if (DataPreparator.XMeans == null) throw new Exception("Statistics like means need to be populated before Handling missing data in the training set.");
        }

        public override void HandleMissingTrain(string outputName, string trainingName, int[] dependentColumns, long offset, long size)
        {
            if (DataPreparator.ColumnTypes == null) throw new Exception("Columptypes need to be populated before Handling missing data in training set.");

            _Repo.Clear(outputName);           
            var lastRow = offset + size;
            var firstRow = _Repo.Header(trainingName);
            _Repo.Export(trainingName, firstRow);
            var n = (long)firstRow.GetLength(1);
            var maxSize = 1000 * 1000 / n; // We allow a 64MB array max
            var subSize = Math.Min(size, maxSize);
            var subData = _Repo.Import(trainingName, offset, subSize);          
            do
            {
                Deal(subData, dependentColumns);
                _Repo.InsertData(outputName, subData, false);
                offset += subSize;
                subSize = Math.Min(subSize, lastRow - offset);
                subData = _Repo.Import(trainingName, offset, subSize);
            } while (subData != null); 
        }

        protected void Deal(string[,] data, int[] dependentColumns)
        {
            var m = data.GetLength(0);
            var n = data.GetLength(1);
            for (var i = 0; i < m; i++)
            {
                for (var j = 0; j < n; j++)
                {
                    if (string.IsNullOrEmpty(data[i, j]))
                    {
                        if (DataPreparator.ColumnTypes[j] != ColumnType.Numeric)
                        {
                            data[i, j] = "NA";
                            if (DataPreparator.ColumnTypes[j] == ColumnType.Binary) DataPreparator.ColumnTypes[j] = ColumnType.Categorical;
                        }
                        else
                        {
                            if (dependentColumns.Contains(j))
                            {
                                data[i, j] = DataPreparator.YMeans[j].ToString();
                            }
                            else
                            {
                                data[i, j] = DataPreparator.XMeans[j].ToString();
                            }
                        }
                    }
                }
            }
        }

    }
}
