﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace NeuralNetwork
{
    [DataContract]
    public class ActivatorSigmoid:IActivator
    {
        public float Activate(float z)
        {
            return 1.0F / (1.0F + (float)Math.Exp(-z));
        }

        public float ActivateDerivate(float z)
        {
            return Activate(z) * (1.0F - Activate(z));
        }
    }
}
