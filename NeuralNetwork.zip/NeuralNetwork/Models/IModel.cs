﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuralNetwork
{

    public interface IModel
    {        
        float[] Weights { get; set; }
        Parameters Parameters { get; set; }
        IRegularizedCostCalculator CostCalculator { get; set; }

        float[,] Predict(float[,] X);
        float[] GetGradients(float[,] X, float[,] Y);

        void ResetWeights(int nbFeatures,int nbClasses);         
        IModel Clone();        
    }      

}
