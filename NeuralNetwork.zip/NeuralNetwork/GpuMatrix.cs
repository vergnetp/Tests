﻿#define unsafe

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Accord.Math;
using Cudafy;
using Cudafy.Translator;
using Cudafy.Host;
using NeuralNetwork;

namespace oNeuralNetwork
{
    public static class GpuMatrix
    {
        public static GPGPU _Gpu;

        public static GPGPU Gpu()
        {
            if (_Gpu == null)
            {
                CudafyModes.Target = eGPUType.OpenCL;
                CudafyModes.DeviceId = 0;
                CudafyTranslator.Language = CudafyModes.Target == eGPUType.OpenCL ? eLanguage.OpenCL : eLanguage.Cuda;
                GPGPU gpu = CudafyHost.GetDevice(CudafyModes.Target, 0);
                eArchitecture arch = gpu.GetArchitecture();
                CudafyModule km = CudafyTranslator.Cudafy(arch);

                var code = @"


#define BLOCK_SIZE 8

";

                km.SourceCode = code + km.SourceCode;
                gpu.LoadModule(km);
                _Gpu = gpu;
            }
            return _Gpu;
        }

        public static float[,] MultiplyGpuNaive(this float[,] a, float[,] b)
        {
            var gpu = Gpu();
            var blockSize = 4.0;
            // allocate the memory on the GPU
            var dev_a = gpu.Allocate<float>(a);
            var dev_b = gpu.Allocate<float>(b);
            gpu.CopyToDevice(a, dev_a);
            gpu.CopyToDevice(b, dev_b);
            var c = new float[a.GetLength(0), b.GetLength(1)];
            var dev_c = gpu.Allocate<float>(c);
            gpu.Launch(new dim3((int)Math.Ceiling(a.GetLength(0) / blockSize), (int)Math.Ceiling(b.GetLength(1) / blockSize)), new dim3((int)blockSize, (int)blockSize), "Dev_MultiplyGpu", dev_a, dev_b, dev_c);

            // copy the array 'c' back from the GPU to the CPU
            gpu.CopyFromDevice(dev_c, c);
            gpu.FreeAll();
            return c;
        }

        [Cudafy]
        public static void pp(GThread thread, float[,] a,float[,] b,float[,] c) 
        {
            GThread.InsertCode(@"    //Identification of this workgroup
    int i = get_group_id(0);
    int j = get_group_id(1);
    //Identification of work-item
    int idX = get_local_id(0);
    int idY = get_local_id(1);
    //matrixes dimensions
    int p = aLen0;
    int r = bLen1;
    int qq = aLen1;
    //Number of submatrixes to be processed by each worker (Q dimension)
    int numSubMat = (float)qq/(float)BLOCK_SIZE+0.5;
    float4 resp = (float4)(0,0,0,0);
    __local float A[BLOCK_SIZE][BLOCK_SIZE];
    __local float B[BLOCK_SIZE][BLOCK_SIZE];
    for (int k=0; k<numSubMat; k++)
    {
        //Copy submatrixes to local memory. Each worker copies one element
        //Notice that A[i,k] accesses elements starting from M[BLOCK_SIZE*i, BLOCK_SIZE*j]
        //if((BLOCK_SIZE*i + idX)<p && (BLOCK_SIZE*k+idY)<qq)
        {
        A[idX][idY] = a[(BLOCK_SIZE*i + idX)*qq + (BLOCK_SIZE*k+idY)];
        }
        //if((BLOCK_SIZE*k + idX)<p && (BLOCK_SIZE*j+idY)<qq)
        {
        B[idX][idY] = b[(BLOCK_SIZE*k + idX )*r+ (BLOCK_SIZE*j+idY)];
        }   
        barrier(CLK_LOCAL_MEM_FENCE);
        for (int k2 = 0; k2 < BLOCK_SIZE; k2+=4)
        {
            float4 temp1=(float4)(A[idX][k2],A[idX][k2+1],A[idX][k2+2],A[idX][k2+3]);
            float4 temp2=(float4)(B[k2][idY],B[k2+1][idY],B[k2+2][idY],B[k2+3][idY]);
            resp += temp1 * temp2;
        }
        barrier(CLK_LOCAL_MEM_FENCE);
    }
    c[(BLOCK_SIZE*i + idX)*r + (BLOCK_SIZE*j+idY)] =resp.x+resp.y+resp.z+resp.w;");
        }

//[Cudafy]
        public static void Dev_MultiplyGpuNaive(GThread thread, float[,] a, float[,] b, float[,] c)
        {
            int n = a.GetLength(0);
            int m = b.GetLength(0);
            int p = b.GetLength(1);
            int i = thread.blockIdx.x * thread.get_local_size(0)+ thread.threadIdx.x;
            int j = thread.blockIdx.y * thread.get_local_size(1) + thread.threadIdx.y;
            if (i >= n || j >= p) return;
            float s = 0;
            for (int k = 0; k < m; k++)
                s += a[i, k] * b[k, j];
                c[i, j] = s;
            
        }
        public static float[,] MultiplyGpu(this float[,] a, float[,] b)
        {
            var gpu = Gpu();
            var blockSize = 8;
            // allocate the memory on the GPU
            var dev_a = gpu.Allocate<float>(a);
            var dev_b = gpu.Allocate<float>(b);
            gpu.CopyToDevice(a, dev_a);
            gpu.CopyToDevice(b, dev_b);
            var c = new float[a.GetLength(0), b.GetLength(1)];
            var dev_c = gpu.Allocate<float>(c);
            gpu.Launch(new dim3((int)Math.Ceiling(a.GetLength(0) / (double)blockSize), (int)Math.Ceiling(b.GetLength(1) / (double)blockSize)), new dim3(blockSize, blockSize), "pp", dev_a, dev_b, dev_c);

            // copy the array 'c' back from the GPU to the CPU
            gpu.CopyFromDevice(dev_c, c);
            gpu.FreeAll();
            return c;
        }

        [Cudafy]
        public static void Dev_MultiplyGpu(GThread thread, float[,] a, float[,] b, float[,] c)
        {
            int i = thread.blockIdx.x * thread.blockDim.x + thread.threadIdx.x;
            int j = thread.blockIdx.y * thread.blockDim.y + thread.threadIdx.y;
            if (i >= a.GetLength(0) || j >= b.GetLength(1)) return;            
            int m = a.GetLength(1);            
            //var Bcolj = thread.AllocateShared<float>("Bcolj", 3000);
            //for (int k = 0; k < 3000; k++)
            //    Bcolj[k] = a[i, k];
            
                float s = 0;
                for (int k = 0; k < m; k++)
                    s += a[i,k]*b[k, j] ;
                c[i, j] = s;
               
        }

        public static double[,] MultiplyMultithreaded(this double[,] a, double[,] b)
        {
            double[,] r = new double[a.GetLength(0), b.GetLength(1)];
            MultiplyMultithreaded(a, b, r);
            return r;
        }
        public static void MultiplyMultithreaded(this double[,] a, double[,] b, double[,] result)
        {
            // TODO: enable argument checking
            // if (a.GetLength(1) != b.GetLength(0))
            //     throw new ArgumentException("Matrix dimensions must match");

            int n = a.GetLength(1);
            int m = result.GetLength(0); //a.GetLength(0);
            int p = result.GetLength(1); //b.GetLength(1);

            unsafe
            {
                double[] Bcolj = new double[n];
                Parallel.For(0, p, j =>
                {
                    fixed (double* ptrA = a)
                    {
                        for (int k = 0; k < Bcolj.Length; k++)
                            Bcolj[k] = b[k, j];

                        double* Arowi = ptrA;
                        for (int i = 0; i < m; i++)
                        {
                            double s = 0;
                            for (int k = 0; k < Bcolj.Length; k++)
                                s += *(Arowi++) * Bcolj[k];
                            result[i, j] = s;
                        }
                    }
                });
            }
        }      

        public static double[,] Multiply(this double[,] a, double[,] b)
        {
            double[,] r = new double[a.GetLength(0), b.GetLength(1)];
            Multiply(a, b, r);
            return r;
        }
        public static void Multiply(this double[,] a, double[,] b, double[,] result)
        {
            // TODO: enable argument checking
            // if (a.GetLength(1) != b.GetLength(0))
            //     throw new ArgumentException("Matrix dimensions must match");

            int n = a.GetLength(1);
            int m = result.GetLength(0); //a.GetLength(0);
            int p = result.GetLength(1); //b.GetLength(1);

            unsafe
            {
                fixed (double* ptrA = a)
                {
                    double[] Bcolj = new double[n];
                    for (int j = 0; j < p; j++)
                    {
                        for (int k = 0; k < Bcolj.Length; k++)
                            Bcolj[k] = b[k, j];

                        double* Arowi = ptrA;
                        for (int i = 0; i < m; i++)
                        {
                            double s = 0;
                            for (int k = 0; k < Bcolj.Length; k++)
                                s += *(Arowi++) * Bcolj[k];
                            result[i, j] = s;
                        }
                    }
                }
            }
        }




       

        public static float[,] MultiplyBy(this float[,] a, float[,] b)
        {
            if (!a.GetLength(1).Equals(b.GetLength(0))) throw new Exception("MultiplyBy: nb Columns in a must equal nb rows in b.");
            double[,] res = a.ToDouble().Multiply(b.ToDouble());
            return res.ToFloat();
        }

        public static float[,] MultiplyByTranspose(this float[,] a, float[,] b)
        {
            var res = a.ToDouble().MultiplyByTranspose(b.ToDouble());
            return res.ToFloat();
        }

        public static float[,] TransposeAndMultiply(this float[,] a, float[,] b)
        {
            var res = a.ToDouble().TransposeAndMultiply(b.ToDouble());
            return res.ToFloat();
        }
       
       
        
        
      
        public static bool Equal(this List<float[,]> a, List<float[,]> b)
        {
            var res = true;
            for (var l = 0; l < a.Count; l++)
            {
                res = res && a[l].Equal(b[l]);
                if (!a[l].Equal(b[l])) { throw new Exception("Not eq"); }
            }
            return res;
        }
        public static bool Equal(this float[,] a,float[,] b)
        {
            var res = true;
            for (var i=0;i<a.GetLength(0);i++)
            {
                for (var j=0;j<a.GetLength(1);j++)
                {
                    res = res && a[i, j].Equals(b[i, j]);
                    //if (!a[i,j].Equals(b[i,j])) {throw new Exception("Not eq");}
                }
            }
            return res;
        }

    }
}
