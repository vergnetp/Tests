﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace NeuralNetwork
{
    public class TestBrain
    {

        public static void Test()
        {
            var root = @"C:\Users\philippe\Desktop\Data";
            var xTrain = Importer.ImportCsv(System.IO.Path.Combine(root, "xTrainTitanic.csv"));
            var yTrain = Importer.ImportCsv(System.IO.Path.Combine(root, "yTrainTitanic.csv"));
            var xTest = Importer.ImportCsv(System.IO.Path.Combine(root, "xTestTitanic.csv"));
            var brain = new Brain(xTrain, yTrain, xTest, minY: MinY.Zero);//xColTypes:new []{ColumnType.Categorical}
            brain.EvaluateRegularization();
            brain.Evaluate();
            brain.Train();
            var preds=brain.Predict();
        }

    }
}
